package yash;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Objects;
import java.util.Scanner;


//provides menu driven user interface. We can select account, deposit, withdraw funds and apply interest rates on savings account

class AccountNotFound extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7262048962713173859L;

	AccountNotFound(String s){
		super();
	}
}
public class AccountDriver extends BankAccount {
    
    public static void main(String [] args) throws ClassNotFoundException {

        Scanner keyboard = new Scanner(System.in);
        
        // Create array of Accounts
        //ArrayList<Account> accounts = new ArrayList<>();
        Account accounts [] = new Account[10];
        int numAccounts = 0; 

        int choice;

        do {
            choice = menu(keyboard);
            System.out.println();
            if(choice == 1) {
            	accounts[numAccounts++] = createAccount(keyboard);
            } else if(choice == 2) {
                doDeposit(accounts, numAccounts, keyboard);
            } else if(choice == 3) {
                doWithdraw(accounts, numAccounts, keyboard);
            } else if(choice == 4) {
                applyInterest(accounts, numAccounts, keyboard);
            } else {
                System.out.println("End of application");
            }
            System.out.println();
          }while(choice != 5);
    }
    

    /**
     * Account choice
     * @param keyboard 
     * @return choice
     */
    public static int accountMenu(Scanner keyboard) {
        System.out.println("Select Account Type");
        System.out.println("1. Checking Account");
        System.out.println("2. Savings Account");

        int choice;
        do {
            System.out.print("Enter choice: ");
            choice = keyboard.nextInt();
        }while(choice < 1 || choice > 2);
        
        return choice;
    } 

    public static int searchAccount(Account accounts [], int count, int accountNumber) {

        for(int i=0; i<count; i++) {
            if(accounts[i].getAccountNumber() == accountNumber) {
                return i;
            }
        }
        try{
        	if(accountNumber<0)
        	{
        		throw new AccountNotFound("Account no. invalid");
        	}
        	else {
        		System.out.println("Account valid");
        	}
        }
        catch(AccountNotFound e) {
        	e.printStackTrace();
        }
        return -1;
    }


    /**
     * Function to perform Deposit on a selected account
     */
    public static void doDeposit(Account accounts[], int count, Scanner keyboard) {
        // Get the account number
    	System.out.print("\nPlease enter account number");
    	
     
    	int accountNumber= keyboard.nextInt();

	
        // search for account
       
        try {
    		String url
			= "jdbc:mysql://localhost:3306/bank"; //mysql url
    		String user = "root";	 //mysql username
    		String pass = "root"; //mysql passcode
			Connection con=DriverManager.getConnection(url, user, pass);
    		//creating query
    		String q="insert into account(accountNumber) values(?)";
    		PreparedStatement ps=con.prepareStatement(q);
    		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    		System.out.println("Enter account Number:");
    		int id = Integer.parseInt(br.readLine());
    		System.out.println("Enter customer name:");
    		String name=br.readLine();
    		/*System.out.println("Enter amount to store balance:");
    		int id2 = Integer.parseInt(br.readLine());
    		System.out.println("Enter customer name:");
    		String name=br.readLine();*/
    		
    		//setting the values
    		ps.setInt(1,id);
    		//ps.setInt(2,id2);
    		ps.setString(2,name);
    		ps.executeUpdate();
    		System.out.println("inserted Successfully");
    		con.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
        int index = searchAccount(accounts, count, accountNumber);
        if(index >= 0) {
            // Amount
            System.out.print("Please enter Deposit Amount: ");
            double amount = keyboard.nextDouble();

            accounts[index].deposit(amount);
        } else {
            System.out.println("No account exist with AccountNumber: " + accountNumber);
        }
     	
    }
    public static void doWithdraw(Account accounts [], int count, Scanner keyboard) {
        // Get the account number
        System.out.print("\nPlease enter account number: ");
        int accountNumber = keyboard.nextInt();

        // search for account
        int index = searchAccount(accounts, count, accountNumber);

        if(index >= 0) {
            // Amount
            System.out.print("Please enter Withdraw Amount: ");
            double amount = keyboard.nextDouble();
            accounts[index].withdraw(amount);
        } else {
            System.out.println("No account exist with AccountNumber: " + accountNumber);
        }
    }

    public static void applyInterest(Account accounts [], int count, Scanner keyboard) {
        // Get the account number
    	
        System.out.print("\nPlease enter account number: ");
        int accountNumber = keyboard.nextInt();

        // search for account
        int index = searchAccount(accounts, count, accountNumber);

        if(index >= 0) {
            
            // must be instance of savings account
            if(accounts[index] instanceof SavingsAccount) {
                ((SavingsAccount)accounts[index]).applyInterest();
            }
        } else {
            System.out.println("No account exist with AccountNumber: " + accountNumber);
        }
    }

    /**
     * Function to create a new Account
     */
    public static Account createAccount(Scanner keyboard) {

        Account account = null; 
        int choice = accountMenu(keyboard);

        int accountNumber;
        System.out.print("Enter Account Number: ");
        accountNumber = keyboard.nextInt();

        if(choice == 1)  { // chekcing account
            System.out.print("Enter Transaction Fee: ");
            double fee = keyboard.nextDouble();
            account = new CheckingAccount(accountNumber, fee);
        } else { // Savings account
            
            //System.out.print("Please enter Interest Rate: ");
            //double ir = keyboard.nextDouble();
            account = new SavingsAccount(accountNumber);
        }
        return account;
    }

    /**
     * Menu to display options and get the user's selection
     * 
     * @param keyboard
     * @return choice
     */
    public static int menu(Scanner keyboard) {
        System.out.println("Bank Account Menu");
        System.out.println("1. Create New Account");
        System.out.println("2. Deposit Funds");
        System.out.println("3. Withdraw Funds");
        System.out.println("4. Apply Interest");
        System.out.println("5. Quit");

        int choice;

        do {
            System.out.print("Enter choice: ");
            choice = keyboard.nextInt();
        } while(choice < 1 || choice > 5);

        return choice;
    }
}


/*try
	{
		//load the driver
		Class.forName("com.mysql.jdbc.Driver");
		//creating connection
		String url="jdbc:mysql://localhost:3306/bank";
		String user="root";
		String pass="root";
		Connection con=DriverManager.getConnection(url, user, pass);
		//creating query
		String q="insert into account(accountNumber,balance,actCustomer) values(?,?,?)";
		PreparedStatement ps=con.prepareStatement(q);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter account Number:");
		int id = Integer.parseInt(br.readLine());
		System.out.println("Enter amount to store balance:");
		int id2 = Integer.parseInt(br.readLine());
		System.out.println("Enter customer name:");
		String name=br.readLine();
		
		//setting the values
		ps.setInt(1,id);
		ps.setInt(2,id2);
		ps.setString(3,name);
		ps.executeUpdate();
		System.out.println("inserted Successfully");
		con.close();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
   }*/
