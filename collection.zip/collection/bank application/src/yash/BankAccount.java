package yash;
import com.yash.tech.dao.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Objects;

public class BankAccount extends Customer {
	private int accountNumber;
	private int balance;
	Customer customerName;
	public BankAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankAccount(int accountNumber, int balance, Customer actCustomer) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.customerName = actCustomer;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getBalance() {
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//creating connection
			String url="jdbc:mysql://localhost:3306/bank";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url, user, pass);
			//creating query
			String q="insert into account(balance) values(?)";
			PreparedStatement ps=con.prepareStatement(q);
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter amount to store balance:");
			int id2 = Integer.parseInt(br.readLine());
			
			//setting the values
			ps.setInt(2,id2);
			ps.executeUpdate();
			System.out.println("inserted Successfully");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Customer getActCustomer() {
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//creating connection
			String url="jdbc:mysql://localhost:3306/bank";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url, user, pass);
			//creating query
			String q="insert into account(actCustomer) values(?)";
			PreparedStatement ps=con.prepareStatement(q);
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter customer name:");
			String name=br.readLine();
			
			//setting the values
			ps.setString(3,name);
			ps.executeUpdate();
			System.out.println("inserted Successfully");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return customerName;
	}
	public void setActCustomer(Customer actCustomer) {
		this.customerName = actCustomer;
	}
	@Override
	public int hashCode() {
		return Objects.hash(balance);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankAccount other = (BankAccount) obj;
		return balance == other.balance;
	}
	

}
