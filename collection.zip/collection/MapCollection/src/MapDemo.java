import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.util.*;

public class MapDemo {
	public static void main(String[] args) {
		/*Map map=new HashMap();
		map.put(10, "yash");
		map.put(11, "Technologies");
		map.put(20, "jaynam");
		Set s = map.entrySet();
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();//value seperation
			System.out.println("key:"+entry.getKey()+"Value:"+entry.getValue());
		}*/
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(10, "yash");
		map.put(11, "Technologies");
		map.put(20, "jaynam");//keySet() containing all the keys()
		for(Map.Entry m:map.entrySet())//it returns the set containing all the keys and values
			System.out.println("key:"+m.getKey()+"Value:"+m.getValue());
	}

}
