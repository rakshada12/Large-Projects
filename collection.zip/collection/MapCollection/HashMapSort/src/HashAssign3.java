

public class HashAssign3 {

	public static void main(String[] args) {
		ContactList contactsList = new ContactList();
		
		contactsList.addContact("Rakshada", 98310983);
		contactsList.addContact("Riya", 100);
		contactsList.addContact("Amit", 98765432);
				
		System.out.println("Rakshada " + contactsList.NameExist("Riya"));
		System.out.println("98765432: " + contactsList.NumberExist(98765432));
		
		System.out.println();
		contactsList.listAllContacts();
	}

}
