import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class HashAssign1 {
	public static void main(String[] args) {
		Map<String, String> mp = new HashMap<>();
		mp.put("Week", "Seven Days");
		mp.put("Weekday", "Tuesday");
		mp.put("Weekend", "Saturday");
		
		Set<Entry<String, String>> set = mp.entrySet();
		Iterator<Entry<String, String>> it = set.iterator();
		//to check if a key exist
		while(it.hasNext()) {
			Map.Entry<String, String> m = it.next();
			if(m.getKey().equals("Weekend")) {
				System.out.println("Weekend exists");
				break;
			}
		}
		set = mp.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, String> m = it.next();
			
			if (m.getValue().equals("Saturday")) {//to check if a particular value exists or not
				System.out.println("Saturday exists");
				break;
			}
		}
		set = mp.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, String> m = it.next();//iterator to loop through the map keys
			System.out.println("Key: " + m.getKey() + ", Value: " + m.getValue());
		}
		
	}

}
