import java.util.PriorityQueue;
import java.util.Queue;
public class CollectionsDemo {
	public 

}
