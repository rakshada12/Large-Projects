package com.yash.otbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtbsApplication.class, args);
	}

}
