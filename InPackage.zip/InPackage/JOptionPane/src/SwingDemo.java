import javax.swing.*;
public class SwingDemo{
	public static void main(String args[]) {
		JMenu menu;
		JMenuItem a1,a2;
		JFrame a = new JFrame("example");
		JButton b = new JButton("Click");
		b.setBounds(90,90,85,70);
		a.add(b);
		a.setSize(300,300);
		a.setLayout(null);
		a.setVisible(true);
		JTextField b1 = new JTextField("Hello sdnwei"
				+ "ewefewecnnewefkdwwnwsnw");
		b1.setBounds(50,100,200,30);
		a.add(b1);
		a.setSize(300,300);
		a.setLayout(null);
		a.setVisible(true);
		JScrollBar b2 = new JScrollBar();
		b2.setBounds(100, 150, 180, 200);
		a.add(b);
		a.setSize(300,300);
		a.setLayout(null);
		a.setVisible(true);
		menu = new JMenu("options");
		JMenuBar m1 = new JMenuBar();
		a1 = new JMenuItem("Rakshada");
		a2 = new JMenuItem("Pant");
		menu.add(a1);
		menu.add(a2);
		m1.add(menu);
		a.setJMenuBar(m1);
		a.setSize(400,400);
		a.setLayout(null);
		a.setVisible(true);
		String courses[] = { "core java","advance java", "java servlet"};
		JComboBox c = new JComboBox(courses);
		c.setBounds(40,40,90,20);
		a.add(c);
		a.setSize(400,400);
		a.setLayout(null);
		a.setVisible(true);
		//JFrame f = f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}


