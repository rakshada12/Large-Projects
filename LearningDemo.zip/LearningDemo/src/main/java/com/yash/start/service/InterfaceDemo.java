package com.yash.start.service;

public interface InterfaceDemo {

	public double result(double a, double b, String c);
}
