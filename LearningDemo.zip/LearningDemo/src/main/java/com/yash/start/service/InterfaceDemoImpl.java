package com.yash.start.service;

import org.springframework.stereotype.Service;

@Service
public class InterfaceDemoImpl implements InterfaceDemo{

	@Override
	public double result(double a, double b, String c) {
		// TODO Auto-generated method stub
		double res=0;
		switch(c) {
		case "+": res= a+b;
		break;
		case "-": res= a-b;
		break;
		case "*": res= a*b;
		break;
		case "/": res= a/b;
		break;
		default: System.out.print("Enter values");
		}
		return res;
	}

	
}
