package com.yash.start.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.start.entity.EntityDemo;
import com.yash.start.service.InterfaceDemo;

@RestController
public class ControllerDemo {

	@Autowired
	public InterfaceDemo interfaceDemo;
	
	@PostMapping("/calculator")
	public String calculation(@RequestBody EntityDemo entityDemo) {
		
		double a= entityDemo.getNo1();
		double b= entityDemo.getNo2();
		String c= entityDemo.getSymbol();
		
		return "Successful"+c;
				
		
	}
	
}
