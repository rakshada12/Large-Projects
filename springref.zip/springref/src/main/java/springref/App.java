package springref;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
public static void main(String[] args) {
	
	System.out.println("hellod");
	
	
	ApplicationContext context = new  ClassPathXmlApplicationContext("applicationcontext.xml");
	A e=(A)context.getBean("refa");
	System.out.println(e.getX());
	System.out.println(e.getB().getY());
}
}
