package com.yash.productrating.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;


import com.yash.productrating.model.ProductRating;

import com.yash.productrating.service.ProductRatingServiceImpl;


@Controller
@RequestMapping("/rating")
public class ProductRatingController {
	@Autowired
	private ProductRatingServiceImpl productService;
	
	@PostMapping("/createProductRating")
	public void createProductRating(@RequestBody ProductRating productRating) {
		productService.createProductRating(productRating);
	}
	
	@GetMapping("/getAllRatings")
	public ResponseEntity<?> getList(){
		List<ProductRating> comps= productService.getAllProductRatingDetails();
		return new ResponseEntity<List<ProductRating>>(comps,HttpStatus.OK);
	}
	
	@GetMapping("/rating/{id}")
	public ProductRating getProductRatingById(@PathVariable Long id) {
		return productService.getProductRatingById(id);
	}

}
