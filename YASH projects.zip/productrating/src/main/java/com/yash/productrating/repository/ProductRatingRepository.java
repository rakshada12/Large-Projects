package com.yash.productrating.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.productrating.model.ProductRating;

public interface ProductRatingRepository extends JpaRepository<ProductRating,Long> {

}
