package com.yash.productrating.service;

import java.util.List;


import com.yash.productrating.model.ProductRating;

public interface ProductRatingService {
	public ProductRating createProductRating(ProductRating productRating);
	public ProductRating getProductRatingById(Long id);
	public List<ProductRating> getAllProductRatingDetails();

}
