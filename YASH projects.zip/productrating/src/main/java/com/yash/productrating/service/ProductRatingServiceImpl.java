package com.yash.productrating.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.productrating.model.ProductRating;
import com.yash.productrating.repository.ProductRatingRepository;

@Service
public class ProductRatingServiceImpl implements ProductRatingService {
	@Autowired
	private ProductRatingRepository prodRepo;

//	@Override
//	public List<ProductRating> getList() {
//		// TODO Auto-generated method stub
//		return prodRepo.findAll();
//	}

	@Override
	public ProductRating getProductRatingById(Long id) {
		// TODO Auto-generated method stub
		Optional<ProductRating> productRating = prodRepo.findById(id);
		return productRating.orElse(null);
	}

	public ProductRating createProductRating(ProductRating productRating) {
		// TODO Auto-generated method stub
		return prodRepo.save(productRating);
		
	}

	public List<ProductRating> getAllProductRatingDetails() {
		// TODO Auto-generated method stub
		return prodRepo.findAll();
	}

}
