package com.yash.productrating.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ProductRating {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int productId;
	private double rating;
	public ProductRating(double rating) {
		super();
		this.rating = rating;
	}
	
	

}
