package com.yash.beanfactorydemo.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class MySpringApp {
	public static void main (String[] args) {
		Resource resource = new FileSystemResource("beans.xml");
		BeanFactory beanFactory = new XmlBeanFactory(resource);
		//ApplicationContext ctx = new ClassPathXmlApplicationContext("resource/beans.xml");
	}

}
