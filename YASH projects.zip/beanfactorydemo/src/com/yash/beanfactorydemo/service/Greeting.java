package com.yash.beanfactorydemo.service;

public interface Greeting {
	public String greet(String uname);

}
