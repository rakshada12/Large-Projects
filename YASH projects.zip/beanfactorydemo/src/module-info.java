module beanfactorydemo {
	requires spring.context;
	requires spring.beans;
	requires spring.core;
}