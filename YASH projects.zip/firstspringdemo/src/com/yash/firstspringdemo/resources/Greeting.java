package com.yash.firstspringdemo.resources;

public interface Greeting {
	public String greet(String uname);

}
