package com.yash.firstspringdemo.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.yash.firstspringdemo.util.EveningGreeting;
import com.yash.firstspringdemo.util.MorningGreeting;
import com.yash.firstspringdemo.util.MyGreeting;

public class DemoTestWithSpring {

	
	public static void main(String[] args) {
//		Resource resource = new FileSystemResource("resource/beans.xml");
//		BeanFactory beanFactory = new XmlBeanFactory(resource);
//		MyGreeting mygreeting1;
//		mygreeting1 = (MyGreeting) beanFactory.getBean("greeting");
//		mygreeting1.greet("Yash Tech");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("resource/beans.xml");
		MyGreeting mygreeting;
		mygreeting = (MyGreeting) ctx.getBean("greeting");
		System.out.println(mygreeting.greet("Rakshada"));
		System.out.println(mygreeting.hashCode());
		EveningGreeting evening = (EveningGreeting) ctx.getBean("evengreeting");
		System.out.println(evening.greet(" Rakshada"));
		System.out.println(evening.hashCode());
		MorningGreeting morning = (MorningGreeting) ctx.getBean("morngreeting");
		System.out.println(morning.greet(" Rakshada"));
		System.out.println(morning.hashCode());

	}

}
