package com.yash.firstspringdemo.util;

import com.yash.firstspringdemo.resources.Greeting;

public class MyGreeting implements Greeting {

	@Override
	public String greet(String uname) {
		// TODO Auto-generated method stub
		
		return "Hi Welcome" + uname;
	}

}
