package com.yash.tddexample;

import com.yash.tddexample.exceptions.NegativeInputException;

public class StringCalculator {

	

	public int calculate(String input) throws NegativeInputException {
		// TODO Auto-generated method stub
		String[] number = input.split(",");
		if(isEmpty(input)) {
		return 0;
		}
		if(input.length()==1) {
			return StringToInt(input);
		}
		if(Integer.parseInt(input)<0) {
			throw new NegativeInputException("Please enter a positive number.");
		}
		return Integer.parseInt(number[0])+Integer.parseInt(number[1]);
	}
	
	public int calculateDelimitedLine(String input) throws NegativeInputException {
		// TODO Auto-generated method stub
		String[] number = input.split("\n");
		if(isEmpty(input)) {
		return 0;
		}
		if(input.length()==1) {
			return StringToInt(input);
		}
		if(Integer.parseInt(input)<0) {
			throw new NegativeInputException("Please enter a positive number.");
		}
		return Integer.parseInt(number[0])+Integer.parseInt(number[1]);
	}
	
	public int calculateDelimitedEither(String input) throws NegativeInputException {
		// TODO Auto-generated method stub
		String regex = "[,\\n]";
		String[] number = input.split(regex);
		if(isEmpty(input)) {
		return 0;
		}
		if(input.length()==1) {
			return StringToInt(input);
		}
		if(Integer.parseInt(input)<0) {
			throw new NegativeInputException("Please enter a positive number.");
		}
		return Integer.parseInt(number[0])+Integer.parseInt(number[1])+Integer.parseInt(number[2]);
	}

	private boolean isEmpty(String input) {
		// TODO Auto-generated method stub
		return input.isEmpty();
	}

	private int StringToInt(String input) {
		// TODO Auto-generated method stub
		return Integer.parseInt(input);
	}

	public Object calculate(int i, int j) {
		// TODO Auto-generated method stub
		return i+j;
	}


}
