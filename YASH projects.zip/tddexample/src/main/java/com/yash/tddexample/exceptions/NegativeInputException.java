package com.yash.tddexample.exceptions;




public class NegativeInputException extends RuntimeException {
	public NegativeInputException(String message) {
		super(message);
	}

}
