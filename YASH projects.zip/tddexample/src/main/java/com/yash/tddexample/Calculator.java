package com.yash.tddexample;

public class Calculator {
	public int add(int a,int b) {
		return 12;
	}

}
