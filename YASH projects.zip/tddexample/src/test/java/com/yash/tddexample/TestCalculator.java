package com.yash.tddexample;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

public class TestCalculator {
	@Before
	public void setUp() {
		System.out.println("SetUp method called");
	}
	
	@Test
	public void test_GivenAdd_ShouldReturn_AdditionalResult_AsInteger() {
		Calculator c = new Calculator();
		int result = c.add(10, 8);
		System.out.println(result);
		assertEquals(result,12);
		
	}
	
	@After
	public void methodEnd() {
		System.out.println("Last task execution");
	}
	
	@AfterClass
	public static void afterClass() {
		System.out.println("After class called");
	}

}
