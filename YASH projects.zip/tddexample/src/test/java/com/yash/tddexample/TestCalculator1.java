package com.yash.tddexample;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestCalculator1 {
	StringCalculator c = new StringCalculator();
	
	@Test
	public void test_StringCalculator_GivenEmptyString_ReturnZero() {
		
		assertEquals(c.calculate(""), 0);
	}
	
	@Test
	public void test_StringCalculator_GivenSingleString_ReturnStringValue() {
		assertEquals(c.calculate("5"), 5);
	}
	
	@Test
	public void test_StringCalculator_GivenTwoValuesDelimitedByComma_ReturnSum() {
		assertEquals(c.calculate(5,10), 15);
	}
	
	@Test
	public void test_StringCalculator_GivenTwoValuesDelimitedByLine_ReturnSum() {
		assertEquals(c.calculateDelimitedLine("20\n10"), 30);
	}
	
	@Test
	public void test_StringCalculator_GivenThreeValuesDelimitedByEither_ReturnSum() {
		assertEquals(c.calculateDelimitedEither("20\n10,5"), 35);
	}
	
//	@Test
//	public void test_StringCalculator_NegativeNumbers_Exception() {
//		assertEquals(c.calculate("-5"), );
//	}

}
