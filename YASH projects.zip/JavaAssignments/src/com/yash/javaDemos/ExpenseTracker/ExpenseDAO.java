package com.yash.javaDemos.ExpenseTracker;

public interface ExpenseDAO {
	void save(Expense expense);
	Expense[] findAll();
	void remove(Expense expense);
	void update(Expense expense);
	

}
