package com.yash.javaDemos.ExpenseTracker;

import java.util.Date;
import java.text.SimpleDateFormat;
import com.yash.javaDemos.ExpenseTracker.Expense;
import com.yash.javaDemos.ExpenseTracker.ExpenseDAO;

public class ExpenseDAOImpl implements ExpenseDAO {
	private static final int MAX_CAPACITY = 100;
	private Expense[] expenses = new Expense[MAX_CAPACITY];
	private int index = 0;

	public void save(Expense expense) {
		// TODO Auto-generated method stub
		if (index < MAX_CAPACITY) {
			expenses[index++] = expense;
			System.out.println("Expense saved: " + expense);
		} else {
			System.out.println("Expense not saved, maximum capacity reached");
		}

	}

	public Expense[] findAll() {
		// TODO Auto-generated method stub
		Expense[] currentExpenses = new Expense[index];
		System.arraycopy(expenses, 0, currentExpenses, 0, index);
		return currentExpenses;
	}

	public void remove(Expense expense) {
		// TODO Auto-generated method stub
		int curr_index = findIndex(expense);
		if (curr_index != -1) {
			for (int i = curr_index; i < index - 1; i++) {
				expenses[i] = expenses[i + 1];
			}
			expenses[--index] = null;
			System.out.println("Expense removed : " + expense);
		} else {
			System.out.println("Expense not found: " + expense);
		}

	}

	public void update(Expense expense) {
		// TODO Auto-generated method stub
		int curr_index = findIndex(expense);
		if (curr_index != -1) {
			expenses[curr_index] = expense;
			System.out.println("Expense updated : " + expense);
		} else {
			System.out.println("Expense not found : " + expense);
		}

	}

	private int findIndex(Expense expense) {
		for (int i = 0; i < index; i++) {
			if (expenses[i].getId() == expense.getId()) {
				return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExpenseDAO expenseDAO = new ExpenseDAOImpl();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
 
        try {
            Expense e1 = new Expense(1, "Movie", 300, sdf.parse("2024-08-10"));
            Expense e2 = new Expense(2, "Auto", 200, sdf.parse("2024-08-11"));
            Expense e3 = new Expense(3, "Groceries", 5000, sdf.parse("2024-08-12"));
 
           
            expenseDAO.save(e1);
            expenseDAO.save(e2);
            expenseDAO.save(e3);
 
            System.out.println("All expenses:");
            for (Expense e : expenseDAO.findAll()) {
                System.out.println(e);
            }
 
            e2.setAmount(250);
            expenseDAO.update(e2);
 
            
           expenseDAO.remove(e1);
 
            System.out.println("All expenses after updation:");
            for (Expense e : expenseDAO.findAll()) {
                System.out.println(e);
            }
        }catch(

	Exception e)
	{
		e.printStackTrace();
	}

}}
