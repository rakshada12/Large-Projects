package com.yash.javaDemos;

import java.util.Scanner;

public class OopsAssign4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int[] sides = new int[3];
		for(int i=0;i<3;i++) {
			System.out.println("Enter the three sides: ");
			sides[i] = sc.nextInt();
		}
		if(sides[0] == sides[1] && sides[1]==sides[2]) {
			double area = sides[0]*sides[0];
			System.out.println("Square with area of : " + area);
		}else if(sides[0] == sides[1] || sides[1] == sides[2]) {
			double length = sides[0];
			double breadth = (sides[1] == sides[0] ? sides[2]:sides[1]);
			double area = length * breadth;
			System.out.println("Rectangle with area of : " + area);
		}else {
			//if(Math.max(sides[0],Math.max(sides[1]),sides[2])*Math.max(sides[0],Math.max(sides[1]),sides[2]) == );
			double semiPeri = (sides[0]*sides[1]*sides[2])/2;
			double area = Math.sqrt(semiPeri*(semiPeri-sides[0])*(semiPeri-sides[1])*(semiPeri-sides[2]));
			System.out.println("Triangle with area of : " + area);
			
			double maxSide = Math.max(sides[0],Math.max(sides[1],sides[2]));
			double s = 0;
			for(double side : sides) {
				if(side!=maxSide) {
					s += side*side;
				}
			}
			if(maxSide*maxSide == s) {
				System.out.println("Right angled triangle");
			}else {
				System.out.println("Normal Triangle");
			}
		}
		sc.close();
	}

}
