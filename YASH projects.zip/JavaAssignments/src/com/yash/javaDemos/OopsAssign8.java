package com.yash.javaDemos;

class Electronics{
	String name;
	String model;
	public Electronics(String name, String model) {
		this.name=name;
		this.model=model;	
	}
	public void getDetails() {
		System.out.println("Nmae : " + name);
		System.out.println("Model : " + model);
	}
}
class Mobile extends Electronics{
	String type;
	public Mobile(String name, String model, String type) {
		super(name,model);
		this.type=type;
	}
	public void getDetails() {
		System.out.println("Nmae : " + name);
		System.out.println("Model : " + model);
		System.out.println("Type : " + type);
	}
	
}
class LCD extends Electronics{
	int resolution;
	public LCD(String name, String model, int resolution) {
		super(name,model);
		this.resolution=resolution;
	}
	public void getDetails() {
		super.getDetails();
		System.out.println("Resolution : " + resolution);
	}
	
}
class Laptop extends Electronics{
	int ram;
	public Laptop(String name, String model, int ram) {
		super(name,model);
		this.ram=ram;
	}
	public void getDetails() {
		super.getDetails();
		System.out.println("Ram : " + ram);
	}
	
}

public class OopsAssign8 {
	public static void main(String[] args) {
		Electronics a = new Mobile("Iphone","15ProMax","OS");
		Electronics b = new LCD("RealMi","Ultra HD",1500);
		Electronics c = new Laptop("Lenovo","Thinkpad",1200);
		System.out.println("Details of mobile: ");
		a.getDetails();
		System.out.println("Details of LCD");
		b.getDetails();
		System.out.println("Details of Laptop");
		c.getDetails();
	}
	

}
