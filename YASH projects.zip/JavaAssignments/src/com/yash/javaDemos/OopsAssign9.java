package com.yash.javaDemos;

class ObjectCounter {
    private static int count = 0;
    public ObjectCounter() {
        count++;
        System.out.println("Objecy created, object count: " + count);
    }
 

	@Override
    protected void finalize() throws Throwable {
        try {
            System.out.println("Grbage collected " + this.hashCode() + " object of hashcode");
        } finally {
            count--;
            System.out.println("Object freed. Current object count: " + count);//finalize method overriden to display a msg when a object is garbage collected
            super.finalize();
        }
    }
}
 
public class OopsAssign9 {
    public static void main(String[] args) {
        ObjectCounter obj1 = new ObjectCounter();
        ObjectCounter obj2 = new ObjectCounter();
        ObjectCounter obj3 = new ObjectCounter();
        obj1 = null;
        obj2 = null;

        System.gc();

        ObjectCounter obj4 = new ObjectCounter();

        System.gc();
    }
}
