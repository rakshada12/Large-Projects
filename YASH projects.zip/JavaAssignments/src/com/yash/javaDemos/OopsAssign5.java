package com.yash.javaDemos;

abstract class CalcAbs {
	void sum(int a,int b) {
	}
	void sub(int a,int b) {
	}
	void mul(int a,int b) {
	}
	void div(int a,int b) {
	}
	

}
class A extends CalcAbs{

	@Override
	void sum(int a, int b) {
		// TODO Auto-generated method stub
		int s = a+b;
		System.out.println("Sum of two numbers : " + s );
		
	}

}

class B extends A{

	@Override
	void sub(int a, int b) {
		// TODO Auto-generated method stub
		int s = a-b;
		System.out.println("Subtraction of two numbers : " + s );
		
	}

}

class C extends B{

	@Override
	void mul(int a, int b) {
		// TODO Auto-generated method stub
		double m = a*b;
		System.out.println("Multiplication of two numbers : " + m );
		
	}

}

class OopsAssign5 extends C{

	@Override
	void div(int a, int b) {
		// TODO Auto-generated method stub
		double d = a/b;
		System.out.println("Division of two numbers : " + d);
		
	}
	public static void main(String[] args) {
		OopsAssign5 a = new OopsAssign5();
		a.div(10, 2);
		a.mul(5, 6);
		a.sub(5, 3);
		a.sum(9, 1);
		
	}

}


