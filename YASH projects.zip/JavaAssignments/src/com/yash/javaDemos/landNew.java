package com.yash.javaDemos;
 
 
	/**
	 * Below class is based upon class and object use case with encapsulation and data
	 * intialization techniques
	 * @author snehal.pawar
	 *
	 */
	public class landNew {
		double landSize;//non static members ---default value  is 0.0
		String address;//default value is null
		String archName;
		String landType;
		String legalDocuments;
		String interiorDesg;
		//creating contructor
		public landNew(double size,String addr,String architectName,String landtype,String legaldocuments)
		{
			/*archName="Allen";
			landType="Residential";
			legalDocuments="TrueCopy for Registration";	*/	
			landSize=size;
			address=addr;
			archName=architectName;
			landType=landtype;
			legalDocuments=legaldocuments;
		}
		public landNew(double landSize,String address,String archName,String landType,String legalDocuments,String interiorDesg)
		{
			/*archName="Allen";
			landType="Residential";
			legalDocuments="TrueCopy for Registration";	*/	
			this.landSize=landSize;
			this.address=address;
			this.archName=archName;
			this.landType=landType;
			this.legalDocuments=legalDocuments;
			this.interiorDesg=interiorDesg;
		}
		void getDetails()
		{
			System.out.println("The details are"+archName+" "+landType+" "+legalDocuments +" "+landSize+" "+address +" "+interiorDesg);
		}

 
	public static void main(String[] args) {
		landNew ld=new landNew(3000,"Pune","allen","Residential","TrueCopy for Registration");
		ld.getDetails();
		landNew ld2=new landNew(3000,"Pune","allen","Residential","TrueCopy for Registration","John");
		ld2.getDetails();
	}
 
}
