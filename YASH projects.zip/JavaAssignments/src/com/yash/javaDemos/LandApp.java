
package com.yash.javaDemos;
 
  class LandNew1 

{

	double landSize;//non static members ---default value  is 0.0

	String address;//default value is null

	String archName;

	String landType;

	String legalDocuments;

	String interiorDesg;

	//creating contructor

	public LandNew1()

	{

		/*archName="Allen";

		landType="Residential";

		legalDocuments="TrueCopy for Registration";	*/	

		this.landSize=landSize;

		this.address=address;

		this.archName=archName;

		this.landType=landType;

		this.legalDocuments=legalDocuments;

	}

	public LandNew1(double landSize,String address,String archName,String landType,String legalDocuments,String interiorDesg)

	{

		/*archName="Allen";

		landType="Residential";

		legalDocuments="TrueCopy for Registration";	*/	

		this.landSize=landSize;

		this.address=address;

		this.archName=archName;

		this.landType=landType;

		this.legalDocuments=legalDocuments;

		this.interiorDesg=interiorDesg;

	}

	void getDetails()

	{

		System.out.print("The details are"+archName+" "+landType+" "+legalDocuments +" "+landSize+" "+address +" "+interiorDesg);

	}

}	

  class CommercialApt extends LandNew1//inheritance

  {

	  String renterName;

	  CommercialApt(double landSize,String address,String archName,String landType,String legalDocuments,String interiorDesg,String RenterName)

	  {

		  super();

		  this.landSize=landSize;

		  this.address=address;

		  this.archName=archName;

		  this.landType=landType;

		  this.legalDocuments=legalDocuments;

		 this.interiorDesg=interiorDesg;

		 this.renterName=RenterName;

	  }

	  void getDetails1()

		{

		  super.getDetails();//overriding getDetails method

		  System.out.print(renterName);

		}

  }

class LandApp {
 
	public static void main(String[] args) {

		CommercialApt apt=new CommercialApt(3000,"Pune","allen","Commercial","TrueCopy for Registration","John","Robert");

		apt.getDetails1();

		//LandNew1 ld=new LandNew1(3000,"Pune","allen","Residential","TrueCopy for Registration");

		//ld.getDetails();

		//LandNew1 ld2=new LandNew1(3000,"Pune","allen","Residential","TrueCopy for Registration","John");

		//ld2.getDetails();
 
	}
 
}

 