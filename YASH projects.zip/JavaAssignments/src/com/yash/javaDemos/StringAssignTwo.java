package com.yash.javaDemos;

import java.util.Arrays;

class Test{
	String obj_name;
	public Test(String obj_name) {
		this.obj_name = obj_name;
	}
	static void show() {
		Test t1 = new Test("t1");
		display();
	}
	static void display() {
		Test t2 = new Test("t2");
	}
	protected void finalize() throws Throwable  
    {
        System.out.println(this.obj_name + " successfully garbage collected"); 
    } 
}

public class StringAssignTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char[] s = "rakshada".toCharArray();
		System.out.println("Question 2 ");
        Arrays.sort(s);;
        System.out.println(new String(s));
        
        s = new StringBuilder(new String(s)).reverse().toString().toCharArray();
        String desc = new String(s);
        System.out.println("Desc Order : " + desc);
        System.out.println("Ques 3) ");
        
        String str = "Hello World";
        for (int i = 0; i < str.length(); i++) { 
            if (str.charAt(i) == 'a' || str.charAt(i) == 'e'
                || str.charAt(i) == 'i' || str.charAt(i) == 'o'
                || str.charAt(i) == 'u' || str.charAt(i) == 'A'
                || str.charAt(i) == 'E' || str.charAt(i) == 'I'
                || str.charAt(i) == 'O'
                || str.charAt(i) == 'U') { 
                continue; 
            } 
            else { 
                System.out.print(str.charAt(i));
               
                }
            }
        
        System.out.println("\nQuestion 4) ");
        String s2 = "Vineeta";
        char[] ch = s2.toCharArray();
        System.out.println("Repeated characters: ");
        for(int i=0;i<s2.length();i++) {
        	for(int j=i+1;j<s2.length();j++) {
        		if(ch[i] == ch[j]) {
        			System.out.print(ch[j] + " ");
        			break;
        		}
        	}
        }
        System.out.println("Question 5) ");
        StringBuffer buf=new StringBuffer("Yash"); 
        buf.append("Tech");  
        System.out.println(buf);
        
        StringBuilder tuf=new StringBuilder("All the");  
        tuf.append(" best");  
        System.out.println(tuf);  
        System.out.println("Question 6) ");
        String s1 = new String("Maths");
        String s3 = new String("Maths");
        if(s1==s3) {  //== operator is used for address comparison while .equals() used for content comparison
        	System.out.println("same location");
        }else {
        	System.out.println("Different location");
        }
        String s4 = "Science";
        String s5 = "Science";
        if(s5==s4) {
        	System.out.println("Same location");
        }else {
        	System.out.println("Different location");
        }
        System.out.println("Question 7) ");
        
        Test.show();
        System.gc();
        
        
        
	}
	
}


