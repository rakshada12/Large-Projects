package com.yash.javaDemos;

import java.util.Arrays;
class Test1{
public static void SortByLength(String[] arr) {
    int n = arr.length;
    boolean swap;
    for (int i = 0; i < n - 1; i++) {
        swap = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j].length() > arr[j + 1].length()) {
               
                String temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swap = true;
            }
        }
        if (!swap) break;
    }
}
}

class Palindrome {
	 
    public static boolean isPalindrome(String s) {
        int n = s.length();
        for (int i = 0; i < n / 2; i++) {
            if (s.charAt(i) != s.charAt(n - i - 1)) {
                return false;
            }
        }
        return true;
    }
 
    public static int filterPalindromes(String[] arr) {
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (isPalindrome(arr[i])) {
                arr[count] = arr[i];
                count++;
            } else {
                arr[count] = null;
            }
        }
        return count;
    }
}


public class StringArrayJava {


	public int thirdMax(int[] a, int arr_size) {
		
		int temp;
		for(int i=0;i<arr_size;i++) {
			for(int j=i+1;j<arr_size;j++) {
				 if (a[i] > a[j])   
	                {  
	                    temp = a[i];  
	                    a[i] = a[j];  
	                    a[j] = temp;  
	                }  
			}
		}
		return a[arr_size - 3];
		
	}
	
	public void findDuplicate(int[] a, int arr_size) {
		int temp, j;
		for(int i=0;i<arr_size;i++) {
			temp = 1;
			for(j=i+1;j<arr_size;j++) {
				if(a[j] == a[i]) {
					temp++;
				}
				else break;
				
			}
			
			i=j-1;
			if(temp>1) {
				System.out.println("The no. is " + a[i] + "\nfrequency " + temp);
		}
		
		}
	}
	
	
	
	 public static int[] sortByUnitPlace(int[] array) {
	     
	        int[] count = new int[10];
	 
	        int[] output = new int[array.length];
	       
	        for (int num : array) {
	            int unitPlace = num % 10;
	            count[unitPlace]++;
	        }
	 
	        for (int i = 1; i < 10; i++) {
	            count[i] += count[i - 1];
	        }

	        for (int i = array.length - 1; i >= 0; i--) {
	            int num = array[i];
	            int unitPlace = num % 10;
	            output[count[unitPlace] - 1] = num;
	            count[unitPlace]--;
	        }
	 
	        System.arraycopy(output, 0, array, 0, array.length);
	 
	        return array;
	    }
	
	
	
	
	
	
	public void pythagorasTriplets(int[] arr) {
		int a = 0, b=0, c=0;
		Arrays.sort(arr);
		for (int i = arr.length - 1; i >= 2; i--) {
            c = arr[i];
            int left = 0;
            int right = i - 1;
 
            while (left < right) {
                 a = arr[left];
                b = arr[right];
                if (a * a + b * b == c * c) {
                    System.out.println("Triplet is = (" + a + ", " + b + ", " + c + ")");
                    left++;
                    right--;
                } else if (a * a + b * b < c * c) {
                    left++;
                } else {
                    right--;
                }
            }
        }
		
		
		
	}
	
	public boolean evenOddPrime(int num) {
		if(num <= 1) {
			return false;
		}
		if(num == 2) {
			return true;
		}
		if(num % 2 == 0) {
			return false;
		}
		for(int i = 3;i<=Math.sqrt(num);i++) {
			if(num%i==0) {
				return false;
			}
		}
		return true;
	}
	
	public void sortAscDesc(int[] arr, int start, int end) {
		int temp;
		
		for(int i = start;i<end;i++) {
			for(int j=i+1;j<end;j++) {
				 if(arr[i] > arr[j]) {    
	                   temp = arr[i];    
	                   arr[i] = arr[j];    
	                   arr[j] = temp;    
	               }     
				
			}
		}
		
	}
	
	public void sortDescAsc(int[] arr, int start, int end) {
		int temp;
		 for (int i = start; i < end; i++) {     
	            for (int j = i+1; j < end; j++) {     
	               if(arr[i] < arr[j]) {    
	                   temp = arr[i];    
	                   arr[i] = arr[j];    
	                   arr[j] = temp;    
	               }     
	            }     
	        }
	}
	
	public int getHcf(int[] brr) {
		int hcf = brr[0];
		for(int i=1;i<brr.length;i++) {
			hcf = getHcf(hcf, brr[i]);
		}
		return hcf;
	}
	public int getHcf(int a, int b) {
		while(b!=0) {
			int temp=b;
			b = a%b;
			a = temp;
		}
		return a;
	}
	public int getLcm(int[] brr) {
		int lcm = brr[0];
		for(int i=1;i<brr.length;i++) {
			lcm = getLcm(lcm, brr[i]);
		}
		return lcm;
	}
	public int getLcm(int a, int b) {
		if(a==0||b==0) {
			return 0;
		}
		return (a*b) / getHcf(a,b);
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringArrayJava saj = new StringArrayJava();
		int[] a={12,90,34,56,89,12};
		int[] arr = {3,1,4,6,5,17,19,78};
		int[] brr = {12,15,20,25};
		int len = a.length;
		System.out.println("Ques 1) ");
		System.out.println("Third largest element is " + saj.thirdMax(a, len));
		System.out.println("Ques 2) ");
		saj.findDuplicate(a, len);
		System.out.println("Ques 4) ");
		saj.pythagorasTriplets(arr);
		System.out.println("Ques 5) ");
		
		int even = 0;
		int odd = 0;
		int prime = 0;
		for(int num: arr) {
			if(saj.evenOddPrime(num)) {
				prime++;
			}
			if(num % 2 == 0) {
				even++;
			}else {
				odd++;
			}
		}
		System.out.println("Even " + even + " Odd " + odd + " Prime " + prime);
		int mid = arr.length / 2;
		saj.sortAscDesc(arr, 0, mid);
		saj.sortDescAsc(arr, mid, arr.length);
		System.out.println("Ques 6) ");
		System.out.print("Sorted Array : ");
		for(int x : arr) {
			System.out.print(x + " ");
		}
		
		System.out.println("\nQues 7) ");
		
		System.out.println("HCF : " + saj.getHcf(brr) + " LCM : " + saj.getLcm(brr));
		
		char[] charArr = {'a','b','c','d','e','g','f'};
		char[] vowels = {'a','e','i','o','u'};
		boolean[] isVowel = new boolean[128];
		for(char c: vowels) {
			isVowel[c] = true;
		}
		int count = 0;
		
		for(char c: charArr) {
			if(isVowel[c]) {
				count++;
			}
		}
		int consonantCount = charArr.length - count;
		char[] vowels2 = new char[count];
		char[] consonant2 = new char[consonantCount];
		int vindex=0, cindex=0;
		for(char c : charArr) {
			if(isVowel[c]) {
				vowels2[vindex++] = c;
			}else {
				consonant2[cindex++] = c;
			}
		}
		char[] result = new char[charArr.length];
		int index=0;
		for(char c:vowels2) {
			result[index++] = c;
		}
		for(char c:consonant2) {
			result[index++] = c;
		}
		System.out.println("Question 8)");
		System.out.println("New Array : " + Arrays.toString(result));
		
		System.out.println("Question 10)");
		 String[] stringArray = {"Rose", "Sunflower", "Technologies", "CSS", "Database"};
		 Test1.SortByLength(stringArray);
		 
		 System.out.println("Sorted array : ");
	        System.out.println(Arrays.toString(stringArray)); 
	      
	        System.out.println("Question 11)");
	        String[] arrayStr= {"ana", "Bubble", "madam", "Java"};
	        int count2 = Palindrome.filterPalindromes(arrayStr);
	        
	        for (int i = 0; i < count; i++) {
	            System.out.print(arrayStr[i] + " ");
	        }
	        
	        System.out.println("Question 12)");
	        int[] array = {3, 67, 12, 89, 90, 12, 91};
	        int[] sortedArray = sortByUnitPlace(array);
	        
	        System.out.println("Sorted array based on unit place: ");
	        for (int num : sortedArray) {
	            System.out.print(num + " ");
	        }
		
	}
	

}

