package com.yash.javaDemos;

public class Land1 {

}
