package com.yash.javaDemos;

import java.util.Scanner;

class Elements1{
	static void printElements(int m1[][], int M) {
		System.out.println("First row: ");
		for(int i=0;i<M;i++) {
			System.out.println(m1[0][i] + " ");
		}
		System.out.println();
		System.out.println("Last row: ");
		for(int i=0;i<M;i++) {
			System.out.println(m1[M-1][i] + " ");
		}
		System.out.println();
		System.out.println("First column: ");
		for(int i=0;i<M;i++) {
			System.out.println(m1[i][0] + " ");
		}
		System.out.println();
		System.out.println("Last column: ");
		for(int i=0;i<M;i++) {
			System.out.println(m1[i][M-1] + " ");
		}
		System.out.println();
	}
}

public class StringAssignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("First String  : ");
		String firstString = scanner.nextLine();
		
		System.out.println("Second String  : ");
		String secondString = scanner.nextLine();
		
		System.out.println("Enter index ");
		int index = scanner.nextInt();
		
		if(index<0 || index>firstString.length()) {
			System.out.println("Invalid index");
		}else {
			String newString = firstString.substring(0, index) + secondString + firstString.substring(index);
			System.out.println("New String : " + newString);
		}
		
		
		
		System.out.println("Ques 9 of array assignment");
		
	
		System.out.println("Enter the order of matrix");
		int M = scanner.nextInt();
		int[][] m1 = new int[M][M];
		System.out.println("Enter the elements");
		for(int i=0;i<M;i++) {
			for(int j=0;j<M;j++) {
				m1[i][j]=scanner.nextInt();
			}
		}
		
		Elements1.printElements(m1, M);
		
		scanner.close();
		
	}
	

}
