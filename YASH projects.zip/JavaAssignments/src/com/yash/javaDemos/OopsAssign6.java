package com.yash.javaDemos;


class GenMax {
    public int maximum(int... n) {
        int max = n[0];
        for (int num : n) {
            if (num > max) {
                max = num;
            }
        }
        return max;
    }
}

class Max3 extends GenMax {
    
    public int maximum(int a, int b, int c) {
        return super.maximum(a, b, c);
    }
}

class Max4 extends GenMax {
   
    public int maximum(int a, int b, int c, int d) {
        return super.maximum(a, b, c, d);
    }
}

public class OopsAssign6 {
	public static void main(String[] args) {
	 Max3 a = new Max3();
     System.out.println("Maximum of 3 numbers: " + a.maximum(2, 0, 4));
     Max4 b = new Max4();
     System.out.println("Maximum of 4 numbers : " + b.maximum(1, 25, 3, 7));
     GenMax c = new GenMax();
     System.out.println("Maximum of N numbers :" + c.maximum(2, 29, 46, 6, 99)); 

}
}
