package com.yash.javaDemos.exceptions;

import java.util.Scanner;

public class ClassAssignment3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Enter size of array");
			int size = Integer.parseInt(sc.nextLine());
			if(size<=0) {
				throw new IllegalArgumentException("Array size not allowed");
			}
			int[] arr = new int[size];
			System.out.println("Array is created");
		} catch(NumberFormatException e) {
			System.out.println("Invalid input, enter a numeric value");
		}catch(IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
		

	}

	

}
