package com.yash.javaDemos.exceptions;


public class Demo {


		static void demoMethod() {
			NullPointerException e = new NullPointerException("First Exception");
			e.initCause(new ArithmeticException("cause"));
			throw e;
		}

	
	public static void main(String[] args) {
		try {
			demoMethod();
		} catch(NullPointerException n){
			System.out.println("Exception Caught: " + n);
			System.out.println("Actual Cause:" + n.getCause());
		}
	}


	}

