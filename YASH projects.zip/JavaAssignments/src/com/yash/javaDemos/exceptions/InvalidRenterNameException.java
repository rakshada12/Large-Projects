package com.yash.javaDemos.exceptions;
 
public class InvalidRenterNameException extends Exception 
{
	public InvalidRenterNameException(String msg)
	{
	super(msg);
	}
 
}
