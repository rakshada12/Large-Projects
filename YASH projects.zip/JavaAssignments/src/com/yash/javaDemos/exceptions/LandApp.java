package com.yash.javaDemos.exceptions;
 
import com.yash.javaDemos.exceptions.InvalidDocument;
import com.yash.javaDemos.exceptions.InvalidRenterNameException;
 
class LandNew1 
{
	double landSize;//non static members ---default value  is 0.0
	String address;//default value is null
	String archName;
	String landType;
	String legalDocuments;
	String interiorDesg;
	//creating contructor
	public LandNew1()
	{
		/*archName="Allen";
		landType="Residential";
		legalDocuments="TrueCopy for Registration";	*/	
		this.landSize=landSize;
		this.address=address;
		this.archName=archName;
		this.landType=landType;
		this.legalDocuments=legalDocuments;
	}
	public LandNew1(double landSize,String address,String archName,String landType,String legalDocuments,String interiorDesg)
	{
		/*archName="Allen";
		landType="Residential";
		legalDocuments="TrueCopy for Registration";	*/	
		this.landSize=landSize;
		this.address=address;
		this.archName=archName;
		this.landType=landType;
		this.legalDocuments=legalDocuments;
		this.interiorDesg=interiorDesg;
	}
	void getDetails() throws InvalidDocument
	{
		if(legalDocuments=="True Copy")
		System.out.println("The details are"+archName+" "+landType+" "+legalDocuments +" "+landSize+" "+address +" "+interiorDesg);
		else
			throw new InvalidDocument("Invalid document please check");
	}
}	
   class CommercialApt extends LandNew1//inheritance
  {
	  String renterName;
	  CommercialApt(double landSize,String address,String archName,String landType,String legalDocuments,String interiorDesg,String RenterName)
	  {
		  super();
		  this.landSize=landSize;
		  this.address=address;
		  this.archName=archName;
		  this.landType=landType;
		  this.legalDocuments=legalDocuments;
		 this.interiorDesg=interiorDesg;
		 this.renterName=renterName;
	  }
	  void getDetails1() throws InvalidRenterNameException,InvalidDocument
		{
		  super.getDetails();//overriding getDetails method
		  if(renterName=="ABC")
		  System.out.println(renterName);
		  else 
			  throw new InvalidRenterNameException("Renter is invalid");
		}
  }
class LandApp {
 
	public static void main(String[] args) throws InvalidRenterNameException,InvalidDocument {
		CommercialApt apt=new CommercialApt(3000,"Pune","allen","Commercial","True Copy","John","Robert");
		apt.getDetails1();
		//LandNew1 ld=new LandNew1(3000,"Pune","allen","Residential","TrueCopy for Registration");
		//ld.getDetails();
		//LandNew1 ld2=new LandNew1(3000,"Pune","allen","Residential","TrueCopy for Registration","John");
		//ld2.getDetails();
 
	}
 
}
