package com.yash.javaDemos.exceptions;

import java.util.Scanner;

public class IndexTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] names = {"Rakshada","Vaibhav","Rakesh","Arun","Govind"};
		try {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the index  : ");
		int index = scanner.nextInt();
		if(index<0 || index>=names.length) {
			throw new ArrayIndexOutOfBoundsException("Index out of bounds");
		}
		System.out.println("Index : " + index + " Name : " + names[index]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Error Invalid Index");
		} catch (Exception e){
			System.out.println("Invalid input. Please enter a valid integer");
		}

	}

}
