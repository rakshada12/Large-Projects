package com.yash.javaDemos.exceptions;

import java.util.Scanner;

public class ClassAssignment2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		 
		        System.out.print("Enter a double value: ");
		        String input = scanner.nextLine();
		 
		        double number = 0;
		 
		        try {
		            number = Double.parseDouble(input);
		        } catch (NumberFormatException e) {
		            System.out.println("Error: Invalid input");
		        }
		 
		        System.out.println("The double value is: " + number);
		    }

}
