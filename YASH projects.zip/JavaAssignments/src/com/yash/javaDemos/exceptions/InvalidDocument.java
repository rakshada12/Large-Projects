package com.yash.javaDemos.exceptions;

public class InvalidDocument extends Exception {

	public InvalidDocument(String msg)
	{
		super(msg);
	}

	}


