package com.yash.javaDemos;

import java.util.Arrays;

public class ArrayDemo {//data members and member functions--Encapsulation
	void oneDimensional(int [] array)//member functions
	{
		System.out.println("the elements are"+array[0]+" "+array[1]+" "+array[2]);
		for(int i=0; i<array.length;i++)
		{
			System.out.println(array[i]);
		}
	}
	void twoDimensional(int[][] array)
	{
		System.out.println("the elements are"+array[0][0]+array[0][1]+array[0][2]+array[1][0]);
		for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
            	System.out.println(array[i][j]);
            }
        }
	}
	void stringArray(String [] arrayNames)
 
	{
		System.out.println("the elements are"+arrayNames[0]);
		for(int i=0; i<arrayNames.length;i++)
		{
			System.out.println(arrayNames[i]);
		}
		
	}
	public static void main(String[] args) {
		//public,private,protected,default
		//register ---creat objects
		ArrayDemo a=new ArrayDemo();
		int []oneDimensional= {1200,4566,3455,5566};
		int [][]twoDimensional= {{123,5676,7788},{1200,5600}};
		String []names= {"Java","DotNet","Oracle"};
		a.oneDimensional(oneDimensional);
		a.twoDimensional(twoDimensional);
		a.stringArray(names);
		//two[0][0]
		 int[][] sArray = new int[3][];
		 sArray[0] = new int[3];
		 sArray[1] = new int[2];
		 sArray[2] = new int[4];
		sArray[0][0]=15;
		sArray[0][1]=7;
		sArray[0][0]=22;
		sArray[1][0]=67;
		sArray[1][1]=81;
		sArray[2][0]=12;
		sArray[2][1]=91;
		sArray[2][2]=1;
		sArray[2][3]=17;
		
		for(int i=0;i<sArray.length;i++)
		{
		System.out.println("The elements are " +Arrays.toString(sArray[i]));
		}
	}
 
}