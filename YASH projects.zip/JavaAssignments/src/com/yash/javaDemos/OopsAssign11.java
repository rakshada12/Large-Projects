package com.yash.javaDemos;

import java.util.Date;

class Employee {
    private int employeeID;
    private String employeename;
    private double employeesalary;
    private String employeeaddress;
    private Date employeeDOB;
    private Date employeeDOJ;
 
    
    public Employee(int employeeID, String employeename, double employeesalary, String employeeaddress, Date employeeDOB, Date employeeDOJ) {
        this.employeeID = employeeID;
        this.employeename = employeename;
        this.employeesalary = employeesalary;
        this.employeeaddress = employeeaddress;
        this.employeeDOB = employeeDOB;
        this.employeeDOJ = employeeDOJ;
    }
 
    @Override
    public String toString() {
        return "Employee ID: " + employeeID + "\n" +
               "Employee Name: " + employeename + "\n" +
               "Employee Salary:" + employeesalary + "\n" +
               "Employee Address: " + employeeaddress + "\n" +
               "Employee DOB: " + employeeDOB + "\n" +
               "Employee DOJ: " + employeeDOJ;
    }
}
 
public class OopsAssign11 {
    public static void main(String[] args) {
        Date dob = new Date(00, 9, 12);  
        Date doj = new Date(114, 2, 10);
 
        Employee emp = new Employee(189, "Rakshada Pant", 15000, "Green city Shahdol", dob, doj);
        System.out.println(emp);
    }
}
