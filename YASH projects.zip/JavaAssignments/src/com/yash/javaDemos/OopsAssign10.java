package com.yash.javaDemos;

class Product implements Cloneable {
    private int PID;
    private String pName;
    private double price;
    private String unitOfMeasurement;

    public Product(int PID, String pName, double price, String unitOfMeasurement) {
        this.PID = PID;
        this.pName = pName;
        this.price = price;
        this.unitOfMeasurement = unitOfMeasurement;
    }

    public int getPID() {
        return PID;
    }
 
    public void setPID(int PID) {
        this.PID = PID;
    }
 
    public String getPName() {
        return pName;
    }
 
    public void setPName(String pName) {
        this.pName = pName;
    }
 
    public double getPrice() {
        return price;
    }
 
    public void setPrice(double price) {
        this.price = price;
    }
 
    public String getUnitOfMeasurement() {
        return unitOfMeasurement;
    }
 
    public void setUnitOfMeasurement(String unitOfMeasurement) {
        this.unitOfMeasurement = unitOfMeasurement;
    }
 
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
 
    public void printDetails() {
        System.out.println("PID:" + PID);
        System.out.println("Product Name:" + pName);
        System.out.println("Price:" + price);
        System.out.println("Unit: " + unitOfMeasurement);
    }
}
 
public class OopsAssign10 {
    public static void main(String[] args) {
        try {
            
            Product original = new Product(1, "Mobile", 12000.00, "Piece");
 
            Product cloned = (Product) original.clone();
            cloned.setPName("Iphone mobile");
            cloned.setPrice(25000.00);

            System.out.println("Original Product Details:");
            original.printDetails();
            System.out.println("\nCloned Product Details:");
            cloned.printDetails();

            if (cloned instanceof Product) {
                System.out.println("\n Yes its instance of Product class");
            } else {
                System.out.println("\n Not an instance of the Product class.");
            }
 
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}
