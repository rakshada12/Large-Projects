package com.yash.javaDemos;

public class CustomSort {
	 
    public static void main(String[] args) {
        int[] arr = {3, 1, 4, 6, 5, 7, 10, 13, 17, 2};
        int mid = arr.length / 2;
        sortAscending(arr, 0, mid);

        sortDescending(arr, mid, arr.length);
 
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
 
  
    public static void sortAscending(int[] arr, int start, int end) {
        for (int i = start; i < end; i++) {
            for (int j = i + 1; j < end; j++) {
                if (arr[i] > arr[j]) {
                   
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
    }
 

    public static void sortDescending(int[] arr, int start, int end) {
        for (int i = start; i < end; i++) {
            for (int j = i + 1; j < end; j++) {
                if (arr[i] < arr[j]) {
                   
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
    }
}
