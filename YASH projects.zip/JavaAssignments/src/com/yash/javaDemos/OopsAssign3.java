package com.yash.javaDemos;
import java.util.Date;

class Branch {
    private int branchID;
    private String branchName;
    private String branchAddress;
 
    public Branch(int branchID, String branchName, String branchAddress) {
        this.branchID = branchID;
        this.branchName = branchName;
        this.branchAddress = branchAddress;
    }
 
    public int getBranchID() {
        return branchID;
    }
 
    public String getBranchName() {
        return branchName;
    }
 
    public String getBranchAddress() {
        return branchAddress;
    }

    @Override
    public String toString() {
        return "Branch ID: " + branchID + ", Branch Name: " + branchName + ", Branch Address: " + branchAddress;
    }
}
 
class Customer1 {
    private int customerID;
    private int accountNumber;
    private String customerName;
    private String customerAddress;
    private Date accountOpeningDate;
    private Branch branch;
 
    public Customer1(int customerID, int accountNumber, String customerName, String customerAddress, Date accountOpeningDate, Branch branch) {
        this.customerID = customerID;
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.accountOpeningDate = accountOpeningDate;
        this.branch = branch;
    }
 
    public int getCustomerID() {
        return customerID;
    }
 
    public int getAccountNumber() {
        return accountNumber;
    }
 
    public String getCustomerName() {
        return customerName;
    }
 
    public String getCustomerAddress() {
        return customerAddress;
    }
 
    public Date getAccountOpeningDate() {
        return accountOpeningDate;
    }
 
    public Branch getBranch() {
        return branch;
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerID + ", Account Number: " + accountNumber + ", Name: " + customerName +
                ", Address: " + customerAddress + ", Account Opening Date: " + accountOpeningDate + "\nBranch: " + branch;
    }
}
 
class CustomerAccountStatement {
    private int statementID;
    private double amount;
    private boolean isDeposit;  // True if deposit, false if withdrawal
    private Date transactionDate;
    private Customer1 customer;
 
 
    public CustomerAccountStatement(int statementID, double amount, boolean isDeposit, Date transactionDate, Customer1 customer) {
        this.statementID = statementID;
        this.amount = amount;
        this.isDeposit = isDeposit;
        this.transactionDate = transactionDate;
        this.customer = customer;
    }
 
    public int getStatementID() {
        return statementID;
    }
 
    public double getAmount() {
        return amount;
    }
 
    public boolean isDeposit() {
        return isDeposit;
    }
 
    public Date getTransactionDate() {
        return transactionDate;
    }
 
    public Customer1 getCustomer() {
        return customer;
    }

    @Override
    public String toString() {
        String transactionType = isDeposit ? "Deposit" : "Withdrawal";
        return "Statement ID: " + statementID + ", Amount: " + amount + ", Transaction Type: " + transactionType +
                ", Transaction Date: " + transactionDate + "\n" + customer;
    }
}
 
public class OopsAssign3 {
    public static void main(String[] args) {
        Branch b1 = new Branch(12, "Division Office", "Shahdol");
        Branch b2 = new Branch(13, "South Branch", "Umaria");
 
        Customer1 c1 = new Customer1(1, 121, "Rakshada", "Green City", new Date(), b1);
        Customer1 c2 = new Customer1(2, 122, "Poornima", "Malviya Nagar", new Date(), b2);
 
        CustomerAccountStatement[] statements = new CustomerAccountStatement[4];
        statements[0] = new CustomerAccountStatement(1, 1000, true, new Date(), c1);  // Deposit
        statements[1] = new CustomerAccountStatement(2, 300, false, new Date(), c1); // Withdrawal
        statements[2] = new CustomerAccountStatement(3, 1500, true, new Date(), c2); // Deposit
        statements[3] = new CustomerAccountStatement(4, 2000, false, new Date(), c2); // Withdrawal

        for (CustomerAccountStatement s : statements) {
            System.out.println(s);
            System.out.println("--------------------------");
     
        }
    }
}
