package com.yash.javaDemos;

class Person {
    protected int pid;
    protected String pname;
    protected String paddress;
    protected String dob;

    public Person(int pid, String pname, String paddress, String dob) {
        this.pid = pid;
        this.pname = pname;
        this.paddress = paddress;
        this.dob = dob;
    }

    public int getPid() {
        return pid;
    }
 
    public void setPid(int pid) {
        this.pid = pid;
    }
 
    public String getPname() {
        return pname;
    }
 
    public void setPname(String pname) {
        this.pname = pname;
    }
 
    public String getPaddress() {
        return paddress;
    }
 
    public void setPaddress(String paddress) {
        this.paddress = paddress;
    }
 
    public String getDob() {
        return dob;
    }
 
    public void setDob(String dob) {
        this.dob = dob;
    }
}
 
class Department {
    private int departmentID;
    private String departmentName;
 
    public Department(int departmentID, String departmentName) {
        this.departmentID = departmentID;
        this.departmentName = departmentName;
    }

    public int getDepartmentID() {
        return departmentID;
    }
 
    public void setDepartmentID(int departmentID) {
        this.departmentID = departmentID;
    }
 
    public String getDepartmentName() {
        return departmentName;
    }
 
    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }
 
    @Override
    public String toString() {
        return "Department ID: " + departmentID + " Department Name: " + departmentName;
    }
}
 
class Employee1 extends Person {
    private double salary;
    private String dateOfJoining;
    private String baseLocation;
    private Department department;
    private String contactNumber;
    private String emailId;
 
    
    public Employee1(int pid, String pname, String paddress, String dob, double salary, String dateOfJoining,
                    String baseLocation, Department department, String contactNumber, String emailId) {
        super(pid, pname, paddress, dob);  
        this.salary = salary;
        this.dateOfJoining = dateOfJoining;
        this.baseLocation = baseLocation;
        this.department = department;
        this.contactNumber = contactNumber;
        this.emailId = emailId;
    }
 

    public double getSalary() {
        return salary;
    }
 
    public void setSalary(double salary) {
        this.salary = salary;
    }
 
    public String getDateOfJoining() {
        return dateOfJoining;
    }
 
    public void setDateOfJoining(String dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }
 
    public String getBaseLocation() {
        return baseLocation;
    }
 
    public void setBaseLocation(String baseLocation) {
        this.baseLocation = baseLocation;
    }
 
    public Department getDepartment() {
        return department;
    }
 
    public void setDepartment(Department department) {
        this.department = department;
    }
 
    public String getContactNumber() {
        return contactNumber;
    }
 
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
 
    public String getEmailId() {
        return emailId;
    }
 
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
 
    @Override
    public String toString() {
        return "Employee Details:\n" +
                "PID: " + pid + "\n" +
                "Name: " + pname + "\n" +
                "Address: " + paddress + "\n" +
                "DOB: " + dob + "\n" +
                "Salary: " + salary + "\n" +
                "Date of Joining: " + dateOfJoining + "\n" +
                "Base Location: " + baseLocation + "\n" +
                "Department: " + department + "\n" +
                "Contact Number: " + contactNumber + "\n" +
                "Email ID: " + emailId + "\n";
    }
}
 
class Customer extends Person {
    private String dateOfRegistration;
    private String deliveryAddress;
    private String contactNumber;
    private String emailId;
 
    
    public Customer(int pid, String pname, String pAddress, String dob, String dateOfRegistration,
                    String deliveryAddress, String contactNumber, String emailId) {
        super(pid, pname, pAddress, dob); 
        this.dateOfRegistration = dateOfRegistration;
        this.deliveryAddress = deliveryAddress;
        this.contactNumber = contactNumber;
        this.emailId = emailId;
    }
 
 
    public String getDateOfRegistration() {
        return dateOfRegistration;
    }
 
    public void setDateOfRegistration(String dateOfRegistration) {
        this.dateOfRegistration = dateOfRegistration;
    }
 
    public String getDeliveryAddress() {
        return deliveryAddress;
    }
 
    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }
 
    public String getContactNumber() {
        return contactNumber;
    }
 
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
 
    public String getEmailId() {
        return emailId;
    }
 
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
 
    @Override
    public String toString() {
        return "Customer Details:\n" +
                "PID: " + pid + "\n" +
                "Name: " + pname + "\n" +
                "Address: " + paddress + "\n" +
                "DOB: " + dob + "\n" +
                "Date of Registration: " + dateOfRegistration + "\n" +
                "Delivery Address: " + deliveryAddress + "\n" +
                "Contact Number: " + contactNumber + "\n" +
                "Email ID: " + emailId + "\n";
    }
}
 
public class OopsAssign1 {
    public static void main(String[] args) {
        Department[] departments = new Department[3];
        departments[0] = new Department(1, "Java");
        departments[1] = new Department(2, "AWS");
        departments[2] = new Department(3, "Python");
 
        Employee1 emp = new Employee1(1234, "Rakshada", "Green city Shahdol", "2000-05-23", 15000,
                                    "2015-03-10", "Pune", departments[1], "9826391722", "rakshadapant12@gmail.com");

        Customer cust = new Customer(2001, "Poornima", "Maliviya Nagar Bhopal", "1990-08-25",
                                     "2023-01-15", "Indore", "9840879345", "poornima@gmail.com");
 
        System.out.println(emp);
        System.out.println(cust);
    }
}
