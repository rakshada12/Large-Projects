package com.yash.javaDemos;

import java.util.Scanner;

class StringCompare {
    public String compareStrings(String str1, String str2) {
        if (str1.equals(str2)) {
            return "The strings are same";
        } else {
            return "The strings are not same";
        }
    }
}
 
class ByCompare extends StringCompare {   
    @Override
    public String compareStrings(String str1, String str2) {
        int l1 = str1.length();
        int l2 = str2.length();
        int minLength = Math.min(l1, l2);
 
        for (int i = 0; i < minLength; i++) {
            char ch1 = str1.charAt(i);
            char ch2 = str2.charAt(i);
 
            if (ch1 != ch2) {
                return "Strings differ at " + (i + 1) + ": " + ch1 + " and " + ch2 + "";
            }
        }
        if (l1 != l2) {
            return "Strings differ in length";
        }
        return "The strings are same";
    }
}
 
public class OopsAssign7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str1 = sc.next();
        String str2 = sc.next();
        StringCompare b = new StringCompare();
        System.out.println("Normal Comparison: " + b.compareStrings(str1, str2));
        ByCompare c = new ByCompare();
        System.out.println("Character by char comparison : " + c.compareStrings(str1, str2));
    }
}
