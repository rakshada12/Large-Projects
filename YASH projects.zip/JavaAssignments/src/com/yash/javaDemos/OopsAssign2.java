package com.yash.javaDemos;

import java.util.Scanner;

abstract class Shape {
    abstract double area();
}
 
class Triangle extends Shape {
    private double ax, ay, bx, by, cx, cy;
 
    public Triangle(double ax, double ay, double bx, double by, double cx, double cy) {
    	this.ax = ax;
        this.ay = ay;
        this.bx = bx;
        this.by = by;
        this.cx = cx;
        this.cy = cy;
    }
 
    private double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
 //Calculating area of triangle
    @Override
    double area() {
        double sideAB = distance(ax, ay, bx, by);
        double sideBC = distance(bx, by, cx, cy);
        double sideCA = distance(cx, cy, ax, ay);
        double s = (sideAB + sideBC + sideCA) / 2;
        return Math.sqrt(s * (s - sideAB) * (s - sideBC) * (s - sideCA));
    }
}
 
class Square extends Shape {
    private double ax, ay, bx, by, cx, cy, dx, dy;
 
    public Square(double ax, double ay, double bx, double by, double cx, double cy, double dx, double dy) {
    	this.ax = ax;
        this.ay = ay;
        this.bx = bx;
        this.by = by;
        this.cx = cx;
        this.cy = cy;
        this.dx = dx;
        this.dy = dy;
    }
 
    private double sideLength(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
 
    //Area of square
    @Override
    double area() {
        double side = sideLength(ax, ay, bx, by);
        return side * side;
    }
}
 
class Rectangle extends Shape {
    private double ax, ay, bx, by, cx, cy, dx, dy;
 
    // Constructor
    public Rectangle(double ax, double ay, double bx, double by, double cx, double cy, double dx, double dy) {
    	this.ax = ax;
        this.ay = ay;
        this.bx = bx;
        this.by = by;
        this.cx = cx;
        this.cy = cy;
        this.dx = dx;
        this.dy = dy;
    }
 
    private double sideLength(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
 
    @Override
    double area() {
        double length = sideLength(ax, ay, bx, by);
        double width = sideLength(bx, by, cx, cy);
        return length * width;
    }
}
 
public class OopsAssign2 {
    public static void main(String[] args) {
    	Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter coordinates - ax ay bx by cx cy : ");
        Triangle triangle = new Triangle(scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble());
        System.out.println("Area of Triangle : " + triangle.area());
 
        System.out.println("Enter coordinates - ax ay bx by cx cy dx dy : ");
        Square square = new Square(scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble());
        System.out.println("Area of Square: " + square.area());

        System.out.println("Enter coordinates - ax ay bx by cx cy dx dy : ");
        Rectangle rectangle = new Rectangle(scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble(), scanner.nextDouble());
        System.out.println("Area of Rectangle: " + rectangle.area());
 
        scanner.close();
    }
}
