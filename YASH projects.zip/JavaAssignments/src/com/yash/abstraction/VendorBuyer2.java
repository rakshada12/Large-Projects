package com.yash.abstraction;

public class VendorBuyer2 implements Land1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VendorBuyer2 v2=new VendorBuyer2();
		v2.getDetails();
		Land1.showMessage();
		

	}

}
