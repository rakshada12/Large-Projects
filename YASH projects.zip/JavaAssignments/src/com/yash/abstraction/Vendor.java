package com.yash.abstraction;

public class Vendor {
    public static void main(String[] args) {
        Architect ar = new ResidentialArchitect();
        ar.design("residential house", 3);
        ar.estimateCost(1500, 100);
 
        Architect ca = new CommercialArchitect();
        ca.design("commercial building", 10);
        ca.estimateCost(5000, 150);
    }
}
