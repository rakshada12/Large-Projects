package com.yash.abstraction;

class A{
	
}

public class Demo {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		A obj = new A();
//		obj.width =5;
//		obj.height=2;
//		obj.length=5;
//		int y =obj.width*obj.height*obj.length;
//		System.out.println(y);
		
		
//		int x = 3;
//		if(x==3) {
//			int x=4;
//			System.out.println(x);
//		}
		int[][] a ={{10,20,40},{50,60},{90,80,70}};

		System.out.println(a[0][0]);


	}

}
