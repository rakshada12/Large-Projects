package com.yash.abstraction;

abstract class Architect {
  
    abstract void design(String houseType, int numberOfRooms);
 
  
    void estimateCost(double area, double costSquareFoot) {
        double totalCost = area * costSquareFoot;
        System.out.println("House cost : " + totalCost);
    }
}
 

class ResidentialArchitect extends Architect {
   
    void design(String houseType, int numberOfRooms) {
        System.out.println("House Type:" + houseType + " Rooms :  " + numberOfRooms);
    }
}
 

class CommercialArchitect extends Architect {
   
    void design(String houseType, int numberOfRooms) {
        System.out.println("House Type:" + houseType + " Rooms :  " + numberOfRooms);
    }
}