package com.yash.abstraction;

public interface Land1 {
	public static final double landSize = 3000;
	public static final String address="Pune";//default value is null
	public static final String archName="allen";
	public static final  String landType="Residential";
	public static final String legalDocuments="Regstd";
	public static final  String interiorDesg="Robert";
	default void getDetails()
	{
		System.out.println("The details are"+landType+" "+legalDocuments +" "+landSize+" "+address);
	}
	static public void showMessage()
	{
		System.out.println("iam in static method of Java8 interface");
	}

}
