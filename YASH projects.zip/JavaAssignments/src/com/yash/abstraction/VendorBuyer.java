package com.yash.abstraction;

public class VendorBuyer extends Land {
	String name;
	VendorBuyer(String name,double landSize,String address)
	{
	  super();
	  this.name=name;
	  this.landSize=landSize;
		this.address=address;
	}
	void showDetails()
	{
		System.out.println(name+" "+landSize+" "+address);
	}
 
	public static void main(String[] args) {
		VendorBuyer v=new VendorBuyer("Ashish",3000,"Pune");
		v.showDetails();
		
 
	}
 
}