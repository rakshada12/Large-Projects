package com.yash.abstraction;

class CommercialApt1 extends Land//inheritance
{
	  String renterName;
	  CommercialApt1(double landSize,String address,String archName,String landType,String legalDocuments,String interiorDesg,String RenterName)
	  {
		  super();
		  this.landSize=landSize;
		  this.address=address;
		  this.archName=archName;
		  this.landType=landType;
		  this.legalDocuments=legalDocuments;
		  this.interiorDesg=interiorDesg;
		  this.renterName=RenterName;
	  }
	  void getDetails1()
		{
		  super.getDetails();//overriding getDetails method
		  System.out.println(renterName);
		}
 
	public static void main(String[] args) {
		CommercialApt1 apt=new CommercialApt1(3000,"Pune","allen","Commercial","TrueCopy for Registration","John","Robert");
		apt.getDetails1();
 
	}
}
