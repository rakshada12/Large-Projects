
package com.yash.abstraction;
 
abstract class Land {

	double landSize;//non static members ---default value  is 0.0

	String address;//default value is null

	String archName;

	String landType;

	String legalDocuments;

	String interiorDesg;

	public Land()//constructor

	{

		/*archName="Allen";

		landType="Residential";

		legalDocuments="TrueCopy for Registration";	*/	

		this.landSize=landSize;

		this.address=address;

		this.archName=archName;

		this.landType=landType;

		this.legalDocuments=legalDocuments;

		this.interiorDesg=interiorDesg;

	}

	void getDetails() {//concrete method

			System.out.println("The details are"+landSize+" "+address+" "+archName+" "+landType+" "+legalDocuments +" "+interiorDesg);

		}

	}
 
 
