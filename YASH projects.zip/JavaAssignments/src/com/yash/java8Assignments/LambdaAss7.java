package com.yash.java8Assignments;

import java.util.Scanner;
import java.util.function.BiFunction;

public class LambdaAss7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		 
        System.out.print("Enter the amount: ");
        double principal = scanner.nextDouble();
 
        System.out.print("Enter the annual interest rate: ");
        double ir = scanner.nextDouble();
 
        System.out.print("Enter the time in months: ");
        int months = scanner.nextInt();
 
        BiFunction<Double, Double, Double> calculate = (p, r) -> {
            double monthlyRate = r / (12 * 100); 
            return p * monthlyRate * Math.pow(1 + monthlyRate, months) / (Math.pow(1 + monthlyRate, months) - 1);
        };
 
       
        double emi = calculate.apply(principal, ir);
 
        // results
        System.out.printf("The EMI for the loan amount is: %.2f\n", emi);
        System.out.println("Total number of EMIs : " + months);
 
        scanner.close();

	}

}
