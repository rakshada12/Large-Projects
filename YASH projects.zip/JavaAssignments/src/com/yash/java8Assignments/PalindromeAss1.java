package com.yash.java8Assignments;

import java.util.function.Predicate;

public class PalindromeAss1 {
	public static void main(String[] args) {
		Predicate<String> p = x -> {
			String str = x;
			String reverseStr = new StringBuilder(str).reverse().toString();
			return str.equals(reverseStr);
		};
		
		String s = "madam";
		boolean result = p.test(s);
		System.out.println(s + " is a palindrome: " + result);
	}

}
