package com.yash.java8Assignments;

import java.util.function.BiPredicate;

public class LambdaAss2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Taj is astuated in Agra";
        String sequence = "ast";
        BiPredicate<String, String> isSequence = (s, seq) -> {
            int i = 0;
            for (char c : s.toCharArray()) {
                if (c == seq.charAt(i)) {
                    i++;
                }
                if (i == seq.length()) {
                    return true; 
                }
            }
            return false;
        };
        
        // Testing the lambda function
        boolean result = isSequence.test(str, sequence);
        if (result) {
            System.out.println("Sequence found.");
        } else {
            System.out.println("Sequence not found.");
        }
        //Solution to question 4)
        System.out.println("Output of question 4: ");
        String og = "Rakshada";
        String ig = "Pant";
        int position = 6;
        StringBuilder newString = new StringBuilder(og);
        newString.insert(position, ig);
        System.out.println("New String: " + newString.toString());
        newString = null;
        System.gc();
        System.out.println("Garbage collection requested");
        System.out.println("New String: " + newString);

	}

}

