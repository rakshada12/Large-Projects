package com.yash.java8Assignments;

import java.util.Scanner;
import java.util.function.Predicate;

public class LambdaAss3 {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter choice : ");
			int choice = sc.nextInt();
			System.out.println("Enter no. to test : ");
			int number = sc.nextInt();
			Predicate<Integer> isEven = x -> x % 2 == 0;
			Predicate<Integer> isOdd = x -> x % 2 != 0;
			Predicate<Integer> isArmstrong = x -> {
			    int original = x;
			    int sum = 0;
			    int s = String.valueOf(x).length();
			    while (x != 0) {
			        int ss = x % 10;
			        sum += Math.pow(ss, s);
			        x /= 10;
			    }
			    return sum == original;
			};
			Predicate<Integer> isPalindrome = x -> {
				String str = x.toString();
				String reverseStr = new StringBuilder(x).reverse().toString();
				return str.equals(reverseStr);
			};
			
			switch (choice) {
			case 1:
			    System.out.println(number + " is even: " + isEven.test(number));
			    break;
			case 2:
			    System.out.println(number + " is odd: " + isOdd.test(number));
			    break;
			case 3:
			    System.out.println(number + " is an Armstrong number: " + isArmstrong.test(number));
			    break;
			case 4:
			    System.out.println(number + " is a palindrome: " + isPalindrome.test(number));
			    break;
			default:
			    System.out.println("Invalid choice");
			    break;
   }sc.close();
		}
        

	}

}
