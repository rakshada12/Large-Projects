package com.yash.java8Assignments;

import java.util.Scanner;
import java.util.function.Function;

public class LambdaAss6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the char to get the specified pattern : ");
        String str = sc.next();
 
      

	}

}
