package com.yash.java8Assignments;

import java.util.ArrayList;
import java.util.List;

public class LambdaAss5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr = {1, 2, 3, 4, 6, 7, 8, 11, 13, 14, 15, 19, 20, 21};
	        String newArr = format(arr);
	        System.out.println(newArr);
	    }
	 
	    private static String format(int[] a) {
	        List<String> result = new ArrayList<>();
	        int start = a[0];  
	        int end = start;          
	 
	        for (int i = 1; i < a.length; i++) {
	            if (a[i] == end + 1) {
	                // If the current number is consecutive, extend
	                end = a[i];
	            } else {
	                // If the current number is not consecutive, close the range
	                makeRange(result, start, end);
	                start = a[i];
	                end = start;
	            }
	        }
	       
	        makeRange(result, start, end);
	 
	        return String.join(",", result);
	    }
	 
	    private static void makeRange(List<String> result, int start, int end) {
	        if (start == end) {   
	            result.add(String.valueOf(start));
	        } else {
	            result.add(start + "-" + end);
	        }

	}

}
