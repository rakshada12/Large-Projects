package com.yash.java8Assignments;

import java.util.function.BiFunction;

public class LambdaAss9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = {30, 37, 33, 32, 39, 40};
		 
      
        BiFunction<int[], int[], Integer> partition = (arr1, pid) -> {
            int[] arr = arr1;
            int low = pid[0];
            int high = pid[1];
 
            int pivot = arr[high];
            int i = low - 1;
 
            for (int j = low; j < high; j++) {
                if (arr[j] <= pivot) {
                    i++;
                    
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
 
            
            int temp = arr[i + 1];
            arr[i + 1] = arr[high];
            arr[high] = temp;
 
            return i + 1;
        };

        quickSort(array, 0, array.length - 1, partition);
 
        //sorted array
        System.out.println("Sorted array: ");
        for (int num : array) {
            System.out.print(num + " ");
        }
    }

    public static void quickSort(int[] array, int low, int high, BiFunction<int[], int[], Integer> partition) {
        if (low < high) {
            int pi = partition.apply(array, new int[]{low, high});
 
            quickSort(array, low, pi - 1, partition);
            quickSort(array, pi + 1, high, partition);
        }

	}

}
