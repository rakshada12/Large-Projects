package com.yash.streamAssignments;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.stream.Collectors;

public class AveragePrice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Item> items = Arrays.asList(
				new Item(1,"Television",LocalDateTime.of(2022, 4, 20, 10, 0),LocalDateTime.of(2027, 4, 20, 10, 0), 30000),
				new Item(2,"AC",LocalDateTime.of(2023, 4, 22, 10, 0),LocalDateTime.of(2028, 4, 20, 10, 0), 20000),
				new Item(3,"Mobile",LocalDateTime.of(2023, 4, 20, 10, 0),LocalDateTime.of(2029, 4, 20, 10, 0), 50000),
				new Item(4,"Cooler",LocalDateTime.of(2023, 4, 20, 10, 0),LocalDateTime.of(2029, 4, 20, 10, 0), 20000)
				);
		
		OptionalDouble avgPrice = items.stream().mapToDouble(Item::getPrice).average();
		if(avgPrice.isPresent()) {
			System.out.println("Average Price: " + avgPrice.getAsDouble());
		}else {
			System.out.println("No items available");
		}
		System.out.println("2) Highest and lowest price");
		Optional<Item> maxPriceItem = items.stream() .max(Comparator.comparing(Item::getPrice)); 
		if (maxPriceItem.isPresent()) { 
			System.out.println("Item with highest price: " + maxPriceItem.get()); 
			} else { System.out.println("No items found or issue with the data."); 
			}
		Optional<Item> minPriceItem = items.stream() .min(Comparator.comparing(Item::getPrice)); 
		minPriceItem.ifPresent(item -> System.out.println("Item with lowest price:" + minPriceItem));
		
		Optional<Item> maxPriceNoExpiryItem = items.stream().filter(item -> item.getDate_of_expiry()==null).max(Comparator.comparing(Item::getPrice));
		maxPriceNoExpiryItem.ifPresent(item -> System.out.println("Item with max price and no expiry date: "+item));
		System.out.println("4) Store item name and price from the list to a set");
		Set<String> itemNameAndPriceSet = items.stream() .map(item -> item.getIname() + ": " + item.getPrice()) .collect(Collectors.toSet()); 
		// Print the set 
		itemNameAndPriceSet.forEach(System.out::println);
		System.out.println("5) Remove duplicate prices from the list of items");
		Set<Float> s = new HashSet<>();
		List<Item> uniquePriceItems = items.stream() .filter(item -> s.add(item.getPrice())) .collect(Collectors.toList());  
		uniquePriceItems.forEach(System.out::println);
		}
	}


