package com.yash.streamAssignments;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class StreamsAss2 {
	public static void main(String[] args) {
		State s1 = new State(2, "Maharashtra");
		State s2 = new State(3, "Tamil Nadu");
		State s3 = new State(4, "Andhra Pradesh");
		List<City> cities = Arrays.asList(
				new City(1, "Mumbai", s1, 5.0f, 5000, 40000),
				new City(1, "Pune", s1, 8.0f, 3000, 80000),
				new City(2, "Chennai", s2, 9.0f, 30000, 500000),
				new City(3, "Hyderabad", s3, 8.0f, 8000, 600000)
				
				);
		
		System.out.println("1) City with smallest Area and highest population---------");
		
		Optional<City> city = cities.stream().min((c1, c2) -> {
			int areaCompare = Integer.compare(c1.getArea_of_city(), c2.getArea_of_city());
			if(areaCompare == 0) {
				return Integer.compare(c2.getPopulation(), c1.getPopulation());
			}
			return areaCompare;
		});
		city.ifPresent(System.out::println);
		
		System.out.println("2) City with highest population index and largest Area---------");
		Optional<City> city1 = cities.stream().max((c1, c2)->{
			int populationCompare = Float.compare(c1.getPopulationIndex(), c2.getPopulationIndex());
			if(populationCompare == 0) {
				return Integer.compare(c1.getArea_of_city(), c2.getArea_of_city());
			}
			return populationCompare;
		});
		city1.ifPresent(System.out::println);
		
		System.out.println("3) City details sorted by populationIndex(lowest first)--------");
		cities.stream().sorted((c1, c2) -> Float.compare(c1.getPopulationIndex(), c2.getPopulationIndex())).forEach(System.out::println);
		
		System.out.println("4) Printing city with lowest population index and lowest area of city--------");
		Optional<City> c1 = cities.stream().min((m1, m2)-> {
			int compare = Float.compare(m1.getPopulationIndex(), m2.getPopulationIndex());
			if(compare==0) {
				return Integer.compare(m1.getArea_of_city(), m2.getArea_of_city());
			}
			return compare;
		});
		c1.ifPresent(System.out::println);
		
		System.out.println("5) Count how many cities each state has--------");
		Map<String, Long> citiescount = cities.stream().collect(Collectors.groupingBy(city2 -> city2.getObjState().getStatename(), Collectors.counting()));
		citiescount.forEach((state, count) -> System.out.println("State: " + state + "|| Number of cities: " + count));
		
		System.out.println("6) Printing total area of each state--------");
		Map<String, Integer> totalarea = cities.stream().collect(Collectors.groupingBy(ci->ci.getObjState().getStatename(), Collectors.summingInt(City::getArea_of_city)));
		totalarea.forEach((state, area) -> System.out.println("State: " + state + " Total Area: " + area));
		}
	
	}


