package com.yash.streamAssignments;

import java.time.LocalDateTime;

class Student {
    int rollno;
    LocalDateTime date_of_addmission, dob;
    String maths, physics, chemistry, english, hindi; 
    String classname;
 
    public Student(int rollno, LocalDateTime date_of_addmission, LocalDateTime dob, String maths,
                   String physics, String chemistry, String english, String hindi, String classname) {
        this.rollno = rollno;
        this.date_of_addmission = date_of_addmission;
        this.dob = dob;
        this.maths = maths;
        this.physics = physics;
        this.chemistry = chemistry;
        this.english = english;
        this.hindi = hindi;
        this.classname = classname;
    }
 
    
    public int getMaths() {
        return Integer.parseInt(maths);
    }
 
    public int getPhysics() {
        return Integer.parseInt(physics);
    }
 
    public int getChemistry() {
        return Integer.parseInt(chemistry);
    }
 
    public int getEnglish() {
        return Integer.parseInt(english);
    }
 
    public int getHindi() {
        return Integer.parseInt(hindi);
    }
 
    public int getTotalMarks() {
        return getMaths() + getPhysics() + getChemistry() + getEnglish() + getHindi();
    }
 
    public double getPercentage() {
        return (getTotalMarks() / 500.0) * 100;
    }
 
    public boolean isPromoted() {
        return getMaths() > 40 && getPhysics() > 40 && getChemistry() > 40 &&
               getEnglish() > 40 && getHindi() > 40;
    }
 
    @Override
    public String toString() {
        return "Student{" +
                "rollno=" + rollno +
                ", date_of_addmission=" + date_of_addmission +
                ", dob=" + dob +
                ", maths=" + maths +
                ", physics=" + physics +
                ", chemistry=" + chemistry +
                ", english=" + english +
                ", hindi=" + hindi +
                ", classname='" + classname + '\'' +
                '}';
    }
}
