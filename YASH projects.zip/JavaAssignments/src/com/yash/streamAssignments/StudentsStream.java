package com.yash.streamAssignments;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StudentsStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<Student> students = Arrays.asList(
				 new Student(1,LocalDateTime.of(2022, 4, 20, 10, 0),LocalDateTime.of(2000, 4, 20, 10, 0), "78","80","79","90","80","5"),
				 new Student(2,LocalDateTime.of(2024, 4, 20, 10, 0),LocalDateTime.of(2001, 4, 20, 10, 0), "60","40","50","80","80","8"),
				 new Student(3,LocalDateTime.of(2019, 4, 20, 10, 0),LocalDateTime.of(2007, 4, 20, 10, 0), "50","40","90","90","80","5"),
				 new Student(4,LocalDateTime.of(2022, 4, 20, 10, 0),LocalDateTime.of(2009, 4, 20, 10, 0), "30","30","30","30","30","4")
				 
				 );
				 
			    System.out.println("1) Less than 40 percent total marks");    
			        List<Student> result = students.stream()
			                                       .filter(x -> x.getPercentage() < 40)
			                                       .collect(Collectors.toList());
			 
			        result.forEach(System.out::println);
			        System.out.println("2) Scored more than 75 percent in any of the 3 sub");   
			        List<Student> result1 = students.stream()
                            .filter(student -> {
                                int count = 0;
                                if (student.getMaths() > 75) count++;
                                if (student.getPhysics() > 75) count++;
                                if (student.getChemistry() > 75) count++;
                                if (student.getEnglish() > 75) count++;
                                if (student.getHindi() > 75) count++;
                                return count >= 3;
                            })
                            .collect(Collectors.toList());

			        result1.forEach(System.out::println);
			        System.out.println("3) List of all students who scored more than 75 percent in all sub");   
			        List<Student> result2 = students.stream().filter(student -> student.getMaths() > 75 &&
			        													student.getPhysics() > 75 &&
			        													student.getChemistry() > 75 &&
			        													student.getEnglish() > 75 &&
			        													student.getHindi() > 75).collect(Collectors.toList());
			        result2.forEach(System.out::println);
			        System.out.println("4) Students who failed in atleast 1 sub"); 
			        List<Student> result3 = students.stream().filter(student -> student.getMaths() <40 ||
							student.getPhysics() > 40 ||
							student.getChemistry() > 40 ||
							student.getEnglish() > 40 ||
							student.getHindi() > 40).collect(Collectors.toList());
			        result3.forEach(System.out::println);
			        System.out.println("5) Students promoted to another class"); 
			        long count = students.stream().filter(Student::isPromoted).count();
			        System.out.println("Number of students promoted: " + count);
			        System.out.println("6) Students need to give exams in two sub to be promoted"); 
			        long count1 = students.stream().filter(student -> {
			        	int fail =0;
			        	if (student.getMaths() < 40) fail++;
                        if (student.getPhysics() < 40) fail++;
                        if (student.getChemistry() < 40) fail++;
                        if (student.getEnglish() < 40) fail++;
                        if (student.getHindi() < 40) fail++;
                        return fail == 2;
			        
			        }).count();
			        System.out.println("No. of Students need to give exams in two sub to be promoted:"+count1);
	}

}
