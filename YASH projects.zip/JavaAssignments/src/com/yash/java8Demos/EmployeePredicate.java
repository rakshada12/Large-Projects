package com.yash.java8Demos;



public interface EmployeePredicate {//SAM --one single method as test
	public boolean test(Employee employee);
 
}

