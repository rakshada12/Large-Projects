package com.yash.java8Demos;

import java.util.ArrayList;
import java.util.List;

class filterBySalAge2 implements EmployeePredicate{
	
	 public boolean test(Employee employee) {
	        return employee.getSalary()>50000 && employee.getAge()>40;
	    }
	 
	 
	 public static List<Employee> filterEmployee(List<Employee> emp,EmployeePredicate predicate)
	    {
	    	List<Employee> result=new ArrayList<>();
	    	for(Employee employee:emp)
	    	{
	    		if(predicate.test(employee)) {
	    			result.add(employee);
	    		}
	    		}
	    	return result;
	    }
	
}

 
public class EmpApp {

	
	public List<Employee>filterBySal(List<Employee> employees){
		List<Employee> result1=new ArrayList<>();
		for(Employee e:employees)
		{
			if(e.getSalary()>50000)
			{
				result1.add(e);
			}
		}
		return result1;
	}
	public List<Employee>filterByAge(List<Employee> employees){
		List<Employee> result2=new ArrayList<>();
		for(Employee e:employees)
		{
			if(e.getAge()>40)
			{
				result2.add(e);
			}
		}
		return result2;
	}
	public List<Employee>filterBySalAndAge(List<Employee> employees){
		List<Employee> result3=new ArrayList<>();
		for(Employee e:employees)
		{
			if(e.getSalary()>50000 && e.getAge()>40)//logical operator
			{
				result3.add(e);
			}
		}
		return result3;
	}

 
	public static void main(String[] args) {
		EmpApp emp=new EmpApp();
		ArrayList<Employee> e=new ArrayList<>();
		e.add(new Employee(1,"Allen",60000,25));
		e.add(new Employee(2,"Robert",70000,425));
		e.add(new Employee(3,"John",40000,23));
		e.add(new Employee(4,"Elon",52000,50));
		e.add(new Employee(5,"Julia",30000,45));
		System.out.println(emp.filterBySal(e));
		System.out.println(emp.filterByAge(e));
		System.out.println(emp.filterBySalAndAge(e));
		//for(Employee data:emp.filterBySal(e))
			//System.out.println(data);
		//System.out.println(emp.filterBySal(e));
		
		System.out.println("----------------------------------------------------------------------------------");
		System.out.println("Using predicate : \n");
	
		System.out.println(filterBySalAge2.filterEmployee(e, new filterBySalAge2()));
		
	}
 
}
