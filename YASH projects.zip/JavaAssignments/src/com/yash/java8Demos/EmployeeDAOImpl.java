package com.yash.java8Demos;

public class EmployeeDAOImpl {
	
	public void getAddress() {
		System.out.println("Pune-Magarpatta");
	}
	public static void main(String[] args) {
		EmployeeDAOImpl empdao = new EmployeeDAOImpl();
		EmployeeDAO dao = empdao::getAddress;
		dao.getEmployeeName();
		EmployeeDAO dao2 = new EmployeeDAOImpl()::getAddress;
		dao2.getEmployeeName();
		
	}

}
