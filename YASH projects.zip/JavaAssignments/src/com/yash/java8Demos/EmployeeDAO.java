package com.yash.java8Demos;

public interface EmployeeDAO {
	public abstract void getEmployeeName();
	
	public default void getCompanyName() {
		System.out.println("Yash Technologies");
	}
	
	public static void getAddress() {
		System.out.println("Pune");
	}

}
