package com.yash.expensetracker.test;

import java.util.Date;

import com.yash.expensetracker.dao.ExpenseDAO;
import com.yash.expensetracker.daoimpl.ExpenseDAOImpl;
import com.yash.expensetracker.model.Expense;

public class ExpenseTrackerSaveOperationTest {
	public static void main(String[] args) {
		ExpenseDAO expensedao = new ExpenseDAOImpl();
		Expense expense = new Expense();
		expense.setId(3);
		expense.setTitle("Books");
		expense.setAmount(450);
		expense.setExpDate(new Date());
		expensedao.save(expense);
		Expense[] e = expensedao.findAll();
		for(Expense ex : e) {
			System.out.println(ex);
		}
	}

}
