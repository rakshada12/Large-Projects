package com.yash.expensetracker.main;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.yash.expensetracker.dao.ExpenseDAO;
import com.yash.expensetracker.daoimpl.ExpenseDAOImpl;
import com.yash.expensetracker.exceptions.ExpenseNotFoundException;
import com.yash.expensetracker.model.Expense;
import com.yash.expensetracker.service.ExpenseService;
import com.yash.expensetracker.serviceimpl.ExpenseServiceImpl;
 
public class ExpenseTrackerApp {	
	   public static void main(String[] args) throws ExpenseNotFoundException {
    	Scanner scanner = new Scanner(System.in);
        ExpenseDAO expenseDAO = new ExpenseDAOImpl();
        ExpenseService expenseService = new ExpenseServiceImpl(expenseDAO, 10000.00); 
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        while (true) {
            System.out.println("Select an operation:");
            for (ExpenseTrackerOperation operation : ExpenseTrackerOperation.values()) {
                System.out.println(operation.getOperationCode() + ". " + operation.getDescription());
            }
 
            int userChoice = scanner.nextInt();
 
            try {
                ExpenseTrackerOperation operation = ExpenseTrackerOperation.fromCode(userChoice);
 
                switch (operation) {
                    case ADD_EXPENSE:
                        addExpense(expenseService, scanner, sdf);
                        break;
                    case VIEW_ALL_EXPENSES:
                        viewAllExpenses(expenseService);
                        break;
                    case VIEW_EXPENSE_BY_ID:
                        viewExpenseById(expenseService, scanner);
                        break;
                    case REMOVE_EXPENSE:
                        deleteExpense(expenseService, scanner);
                        break;
                    case UPDATE_EXPENSE:
                        updateExpense(expenseService, scanner, sdf);
                        break;
                    case SHOW_BALANCE:
                        showBalance(expenseService);
                        break;
                    case EXIT:
                        System.out.println("Exiting the application.");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid option.");
                        break;
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }


	   private static void addExpense(ExpenseService expenseService, Scanner scanner, SimpleDateFormat sdf) {
	        try {
	            System.out.println("Enter expense ID:");
	            int id = scanner.nextInt();
	            scanner.nextLine(); // Consume newline
	 
	            System.out.println("Enter description:");
	            String description = scanner.nextLine();
	 
	            System.out.println("Enter amount:");
	            double amount = scanner.nextDouble();
	 
	            System.out.println("Enter date (yyyy-MM-dd):");
	            String dateString = scanner.next();
	            Date expDate = sdf.parse(dateString);
	 
	            Expense expense = new Expense(id, description, amount, expDate);
	            expenseService.addExpense(expense);
	            System.out.println("Expense added successfully!");
	 
	        } catch (Exception e) {
	            System.out.println("Error: " + e.getMessage());
	        }
	    }
	 
	    private static void viewAllExpenses(ExpenseService expenseService) {
	        Expense[] expenses = expenseService.getAllExpenses();
	        if (expenses.length == 0) {
	            System.out.println("No expenses found.");
	        } else {
	            for (Expense expense : expenses) {
	                System.out.println(expense);
	            }
	        }
	    }
	 
	    private static void viewExpenseById(ExpenseService expenseService, Scanner scanner) throws ExpenseNotFoundException {
	        try {
	            System.out.println("Enter expense ID:");
	            int id = scanner.nextInt();
	            Expense expense = expenseService.getExpenseById(id);
	            System.out.println(expense);
	        } catch (ExpenseNotFoundException e) {
	            System.out.println("Error: " + e.getMessage());
	        }
	    }
	 
	    private static void deleteExpense(ExpenseService expenseService, Scanner scanner){
	        try {
	            System.out.println("Enter expense ID to remove:");
	            int id = scanner.nextInt();
	            Expense expense = expenseService.getExpenseById(id);
	            expenseService.deleteExpense(expense);
	            System.out.println("Expense removed successfully!");
	        } catch (Exception e) {
	            System.out.println("Error: " + e.getMessage());
	        }
	    }
	 
	    private static void updateExpense(ExpenseService expenseService, Scanner scanner, SimpleDateFormat sdf) {
	        try {
	            System.out.println("Enter the ID of the expense to update:");
	            int id = scanner.nextInt();
	            scanner.nextLine(); // Consume newline
	 
	            Expense existingExpense = expenseService.getExpenseById(id);
	 
	            System.out.println("Enter new description (current: " + existingExpense.getTitle() + "):");
	            String description = scanner.nextLine();
	 
	            System.out.println("Enter new amount (current: " + existingExpense.getAmount() + "):");
	            double amount = scanner.nextDouble();
	 
	            System.out.println("Enter new date (yyyy-MM-dd) (current: " + sdf.format(existingExpense.getExpDate()) + "):");
	            String dateString = scanner.next();
	            Date expDate = sdf.parse(dateString);
	 
	            Expense updatedExpense = new Expense(id, description, amount, expDate);
	            expenseService.modifyExpense(updatedExpense);
	            System.out.println("Expense updated successfully!");
	 
	        } catch (Exception e) {
	            System.out.println("Error: " + e.getMessage());
	        }
	    }
	 
	    private static void showBalance(ExpenseService expenseService) {
	        double balance = expenseService.showBalance();
	        System.out.println("Current Balance: " + balance);
	    }
        
        
 
//        while (true) {
//            System.out.println("\n--- Expense Tracker Menu ---");
//            System.out.println("1. Add Expense");
//            System.out.println("2. View All Expenses");
//            System.out.println("3. View Expense by ID");
//            System.out.println("4. Delete Expense");
//            System.out.println("5. Modify Expense");
//            System.out.println("6. Show Balance");
//            System.out.println("7. Exit");
//            System.out.print("Choose an option: ");
//            
//            int option = scanner.nextInt();
//            scanner.nextLine(); // Consume newline left-over
// 
//            switch (option) {
//                case 1:
//                    try {
//                        System.out.print("Enter Expense ID: ");
//                        int id = scanner.nextInt();
//                        scanner.nextLine(); // Consume newline
// 
//                        System.out.print("Enter Description: ");
//                        String description = scanner.nextLine();
// 
//                        System.out.print("Enter Amount: ");
//                        double amount = scanner.nextDouble();
// 
//                        System.out.print("Enter Date (yyyy-MM-dd): ");
//                        String dateStr = scanner.next();
//                        Date expDate = sdf.parse(dateStr);
// 
//                        Expense newExpense = new Expense(id, description, amount, expDate);
//                        expenseService.addExpense(newExpense);
// 
//                        System.out.println("Expense added successfully!");
//                    } catch (Exception e) {
//                        System.out.println("Error: " + e.getMessage());
//                    }
//                    break;
// 
//                case 2:
//                    System.out.println("All Expenses:");
//                    Expense[] expenses = expenseService.getAllExpenses();
//                    if (expenses.length == 0) {
//                        System.out.println("No expenses found.");
//                    } else {
//                        for (Expense e : expenses) {
//                            System.out.println(e);
//                        }
//                    }
//                    break;
// 
//                case 3:
//                	try {
//                    System.out.print("Enter Expense ID to view: ");
//                    int idToView = scanner.nextInt();
//                    Expense expense = expenseService.getExpenseById(idToView);
//                        System.out.println("Expense found: " + expense);
//                    } catch (ExpenseNotFoundException e) {
//                        System.out.println("Error: " + e.getMessage());
//                    }
//                    break;
// 
//                case 4:
//                	System.out.print("Enter Expense ID to delete: ");
//                    int idToDelete = scanner.nextInt();
//                    Expense expenseToDelete = expenseService.getExpenseById(idToDelete);
//                    if (expenseToDelete != null) {
//                        expenseService.deleteExpense(expenseToDelete);
//                        System.out.println("Expense deleted successfully.");
//                    } else {
//                        System.out.println("Expense not found.");
//                    }
//                    break;
// 
//                case 5:
//                    try {
//                        System.out.print("Enter Expense ID to modify: ");
//                        int idToModify = scanner.nextInt();
//                        scanner.nextLine(); 
// 
//                        Expense expenseToModify = expenseService.getExpenseById(idToModify);
//                        if (expenseToModify != null) {
//                            System.out.print("Enter New Description: ");
//                            String newDescription = scanner.nextLine();
// 
//                            System.out.print("Enter New Amount: ");
//                            double newAmount = scanner.nextDouble();
// 
//                            System.out.print("Enter New Date (yyyy-MM-dd): ");
//                            String newDateStr = scanner.next();
//                            Date newExpDate = sdf.parse(newDateStr);
// 
//                            expenseToModify.setTitle(newDescription);
//                            expenseToModify.setAmount(newAmount);
//                            expenseToModify.setExpDate(newExpDate);
// 
//                            expenseService.modifyExpense(expenseToModify);
//                            System.out.println("Expense modified successfully!");
//                        } else {
//                            System.out.println("Expense not found.");
//                        }
//                    } catch (Exception e) {
//                        System.out.println("Error: " + e.getMessage());
//                    }
//                    break;
// 
//                case 6:
//                    System.out.println("Current Balance: " + expenseService.showBalance());
//                    break;
// 
//                case 7:
//                    System.out.println("Exiting...");
//                    scanner.close();
//                    System.exit(0);
//                    break;
//            }
//        }
//    }
}

