package com.yash.expensetracker.main;

public enum ExpenseTrackerOperation {ADD_EXPENSE(1, "Add Expense"), VIEW_ALL_EXPENSES(2, "View All Expenses"), 
	VIEW_EXPENSE_BY_ID(3, "View Expense by ID"), REMOVE_EXPENSE(4, "Remove Expense"), UPDATE_EXPENSE(5, "Update Expense"), SHOW_BALANCE(6, "Show Balance"),
    EXIT(7, "Exit");
 
    private final int operationCode;
    private final String description;
 
   
    ExpenseTrackerOperation(int operationCode, String description) {
        this.operationCode = operationCode;
        this.description = description;
    }
 
    public int getOperationCode() {
        return operationCode;
    }
 
    public String getDescription() {
        return description;
    }
 
    public static ExpenseTrackerOperation fromCode(int code) {
        for (ExpenseTrackerOperation operation : values()) {
            if (operation.getOperationCode() == code) {
                return operation;
            }
        }
        throw new IllegalArgumentException("Invalid operation code: " + code);
    }

}
