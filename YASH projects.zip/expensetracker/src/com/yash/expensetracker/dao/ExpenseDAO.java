package com.yash.expensetracker.dao;

import com.yash.expensetracker.model.Expense;

public interface ExpenseDAO {
	void save(Expense expense);
	Expense[] findAll();
	void remove(Expense expense);
	void update(Expense expense);
	

}
