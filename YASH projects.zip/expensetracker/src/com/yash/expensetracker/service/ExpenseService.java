package com.yash.expensetracker.service;

import com.yash.expensetracker.exceptions.ExpenseNotFoundException;
import com.yash.expensetracker.model.Expense;

public interface ExpenseService {
	void addExpense(Expense expense);
	Expense[] getAllExpenses();
	void deleteExpense(Expense expense);
	void modifyExpense(Expense expense);
	double showBalance();
	Expense getExpenseById(int id) throws ExpenseNotFoundException;

}
