package com.yash.expensetracker.serviceimpl;

import java.text.SimpleDateFormat;

import com.yash.expensetracker.dao.ExpenseDAO;
import com.yash.expensetracker.daoimpl.ExpenseDAOImpl;
import com.yash.expensetracker.exceptions.ExpenseNotFoundException;
import com.yash.expensetracker.model.Expense;
import com.yash.expensetracker.service.ExpenseService;

public class ExpenseServiceImpl implements ExpenseService{
	private ExpenseDAO expenseDAO;
	private double balance;

	public ExpenseServiceImpl(ExpenseDAO expenseDAO, double initialBalance) {
		this.expenseDAO = expenseDAO;
		this.balance=initialBalance;
	}

	@Override
	public void addExpense(Expense expense) {
		// TODO Auto-generated method stub
		expenseDAO.save(expense);
		balance -= expense.getAmount();
		
	}

	@Override
	public Expense[] getAllExpenses() {
		// TODO Auto-generated method stub
		return expenseDAO.findAll();
	}

	@Override
	public void deleteExpense(Expense expense){
		// TODO Auto-generated method stub
		expenseDAO.remove(expense);
	}

	@Override
	public void modifyExpense(Expense expense) {
		// TODO Auto-generated method stub
		expenseDAO.update(expense);	
		
	}
	
	@Override
	public double showBalance() {
		// TODO Auto-generated method stub
		return balance;	
	}
	
	@Override
	public Expense getExpenseById(int id) throws ExpenseNotFoundException {
		// TODO Auto-generated method stub
		Expense[] allExpense = expenseDAO.findAll();
		for(Expense expense : allExpense) {
			if(expense.getId() == id) {
				return expense;
			}
		}
		throw new ExpenseNotFoundException("Expense of id " + id + " not found.");
	}
	
}


