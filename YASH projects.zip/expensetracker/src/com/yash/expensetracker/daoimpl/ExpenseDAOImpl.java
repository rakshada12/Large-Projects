package com.yash.expensetracker.daoimpl;
import com.yash.expensetracker.model.Expense;
import com.yash.expensetracker.dao.ExpenseDAO;

import java.util.Date;
import java.text.SimpleDateFormat;


public class ExpenseDAOImpl implements ExpenseDAO {
	private static final int MAX_CAPACITY = 100;
	private Expense[] localRepo = new Expense[MAX_CAPACITY];
	private int count = 0;

	public void save(Expense expense) {
		// TODO Auto-generated method stub
		if (count < MAX_CAPACITY) {
			localRepo[count++] = expense;
		
		} else {
			System.out.println("Expense not saved, maximum capacity reached");
		}

	}

	public Expense[] findAll() {
		// TODO Auto-generated method stub
		Expense[] currentExpenses = new Expense[count];
		System.arraycopy(localRepo, 0, currentExpenses, 0, count);
		return currentExpenses;
	}

	public void remove(Expense expense) {
		// TODO Auto-generated method stub
			for (int i = 0; i < count; i++) {
				if(localRepo[i].getId() == expense.getId()) {
					localRepo[i]=localRepo[--count];
					localRepo[count]=null;
					return;
			}
			}
	}

	public void update(Expense expense) {
		// TODO Auto-generated method stub
		for (int i = 0; i < count; i++) {
			if(localRepo[i].getId() == expense.getId()) {
				localRepo[i]=expense;
				return;
		}
		}
	}



}
