package com.yash.expensetracker.model;

import java.util.Date;

public class Expense {
    private int id;
    private String title;
    private double amount;
    private Date exp_date;
 
    public Expense(int id, String title, double amount, Date exp_date) {
    	this.id = id;
        this.title = title;
        this.amount = amount;
        this.exp_date = exp_date;
    }
 
    public Expense() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
        return id;
    }
 
    public void setId(int id) {
this.id = id;
    }
 
    public String getTitle() {
        return title;
    }
 
    public void setTitle(String title) {
        this.title = title;
    }
 
    public double getAmount() {
        return amount;
    }
 
    public void setAmount(double amount) {
        this.amount = amount;
    }
 
    public Date getExpDate() {
        return exp_date;
    }
 
    public void setExpDate(Date exp_date) {
        this.exp_date = exp_date;
    }
 
    @Override
    public String toString() {
        return "Expense : [" +
                "id=" + id +
                ", 'Title=" + title + '\'' +
                ", amount=" + amount +
                ", exp_date=" + exp_date +
                ']';
    }
}
