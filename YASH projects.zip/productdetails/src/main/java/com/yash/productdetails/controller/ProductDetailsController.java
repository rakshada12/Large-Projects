package com.yash.productdetails.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.yash.productdetails.model.ProductDetails;
import com.yash.productdetails.service.ProductDetailsService;




@Controller
@RequestMapping("/details")
public class ProductDetailsController {
	@Autowired
	private ProductDetailsService productService;
	
	@PostMapping("/createProductDetails")
	public void createProductDetails(@RequestBody ProductDetails productDetails) {
		productService.createProductDetails(productDetails);
	}
	
	@GetMapping("/getAllProductDetails")
	public ResponseEntity<?> getList(){
		List<ProductDetails> comps= productService.getAllProductDetails();
		return new ResponseEntity<List<ProductDetails>>(comps,HttpStatus.OK);
	}
	
	@GetMapping("/get/{id}")
	public ProductDetails getProductDetailsById(@PathVariable Long id) {
		return productService.getProductDetailsById(id);
	}

}
