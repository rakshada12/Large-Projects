package com.yash.productdetails.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.productdetails.model.ProductDetails;
import com.yash.productdetails.repository.ProductDetailsRepository;

@Service
public class ProductDetailsServiceImpl implements ProductDetailsService {
	@Autowired
	private ProductDetailsRepository repo;

//	@Override
//	public List<ProductDetails> getList() {
//		// TODO Auto-generated method stub
//		return repo.findAll();
//	}
	
	public ProductDetails getProductDetailsById(Long id) {
		Optional<ProductDetails> productDetails = repo.findById(id);
		return productDetails.orElse(null);
	}
	
	public ProductDetails createProductDetails(ProductDetails productDetails) {
		// TODO Auto-generated method stub
		return repo.save(productDetails);
		
	}

	public List<ProductDetails> getAllProductDetails() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
