package com.yash.productdetails.service;

import java.util.List;
import java.util.Optional;

import com.yash.productdetails.model.ProductDetails;



public interface ProductDetailsService {
	
	public ProductDetails createProductDetails(ProductDetails productDetails);
	public ProductDetails getProductDetailsById(Long id);
	public List<ProductDetails> getAllProductDetails();

}
