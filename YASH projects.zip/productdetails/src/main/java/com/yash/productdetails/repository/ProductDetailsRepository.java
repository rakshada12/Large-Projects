package com.yash.productdetails.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.productdetails.model.ProductDetails;



public interface ProductDetailsRepository extends JpaRepository<ProductDetails,Long> {	

}
