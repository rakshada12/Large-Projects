package com.yash.atmsimulation.service;

import com.yash.atmsimulation.model.Account;



public interface AccountService {

		public Account login(String accountNumber, String accountPin);
		public double checkBalance(Long accountId);
		public void withdraw(Long accountId, double amount);
		public void deposit(Long accountId, double amount);
		public void transfer(Long fromAccountId, Long toAccountId, double amount);
		public void updateAccount(Account account);
		public Account getAccountByAccountNumber(String accountNumber);

}
