package com.yash.atmsimulation.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter
@Entity
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@NotNull(message="Account number cannot be null")
	private String accountNumber;
	@NotBlank(message="Please enter the account pin number")
	private String accountPin;
	private double balance;
	public Account(@NotNull(message = "Account number cannot be null") String accountNumber,
			@NotBlank(message = "Please enter the account pin number") String accountPin, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.accountPin = accountPin;
		this.balance = balance;
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
