package com.yash.atmsimulation.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.atmsimulation.exceptions.AccountNotFoundException;
import com.yash.atmsimulation.exceptions.InsufficientFunds;
import com.yash.atmsimulation.exceptions.InvalidCredentialsException;
import com.yash.atmsimulation.model.Account;
import com.yash.atmsimulation.repository.AccountRepository;
import com.yash.atmsimulation.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	private AccountRepository accountRepo;
	

	@Override
	public Account login(String accountNumber, String accountPin) {
	
		Account account = accountRepo.findByAccountNumberAndAccountPin(accountNumber, accountPin);
		if(account == null) {
			throw new InvalidCredentialsException("Invalid credentials");
		}
		return account;
	}

	@Override
	public double checkBalance(Long accountId) {
		Account account = accountRepo.findById(accountId).orElse(null);
        if (account == null) {
            throw new AccountNotFoundException("Account not found");
        }      
		// TODO Auto-generated method stub
		return account.getBalance();
	}

	@Override
	public void withdraw(Long accountId, double amount) {
		// TODO Auto-generated method stub
		 Account account = accountRepo.findById(accountId).orElse(null);
	        if (account == null) {
	            throw new AccountNotFoundException("Account not found");
	        }
	        if (account.getBalance() >= amount) {
	            account.setBalance(account.getBalance() - amount);
	            accountRepo.save(account);
	        } else {
	            throw new InsufficientFunds("Insufficient funds");
	        }
		
	}

	@Override
	public void deposit(Long accountId, double amount) {
		// TODO Auto-generated method stub
		Account account = accountRepo.findById(accountId).orElse(null);
        if (account == null) {
            throw new AccountNotFoundException("Account not found");
        }
        account.setBalance(account.getBalance() + amount);
        accountRepo.save(account);
		
	}

	@Override
	public void transfer(Long fromAccountId, Long toAccountId, double amount) {
		// TODO Auto-generated method stub
		Account fromAccount = accountRepo.findById(fromAccountId).orElse(null);
        Account toAccount = accountRepo.findById(toAccountId).orElse(null);
 
        if (fromAccount == null || toAccount == null) {
            throw new AccountNotFoundException("Both accounts not found");
        }
 
        if (fromAccount.getBalance() >= amount) {
            fromAccount.setBalance(fromAccount.getBalance() - amount);
            toAccount.setBalance(toAccount.getBalance() + amount);
 
            accountRepo.save(fromAccount);
            accountRepo.save(toAccount);
        } else {
            throw new InsufficientFunds("Insufficient funds in source account");
        }
		
	}

	@Override
	public void updateAccount(Account account) {
		// TODO Auto-generated method stub
		accountRepo.save(account);
	}

	@Override
	public Account getAccountByAccountNumber(String accountNumber) {
		// TODO Auto-generated method stub
		return accountRepo.findByAccountNumber(accountNumber);
	}

}
