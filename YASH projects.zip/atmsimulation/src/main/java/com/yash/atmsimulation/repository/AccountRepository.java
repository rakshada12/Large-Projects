package com.yash.atmsimulation.repository;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.yash.atmsimulation.model.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
	//public Account findByAccountPinNumber(String accountNumber, String accountPin);
	
	 @Query("SELECT a FROM Account a WHERE a.accountNumber = :accountNumber AND a.accountPin = :accountPin")
	    Account findByAccountNumberAndAccountPin(@Param("accountNumber") String accountNumber, @Param("accountPin") String accountPin);

	 @Query("SELECT a FROM Account a WHERE a.accountNumber = :accountNumber")
	    Account findByAccountNumber(@Param("accountNumber") String accountNumber);

}
