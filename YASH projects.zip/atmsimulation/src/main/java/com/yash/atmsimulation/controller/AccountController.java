package com.yash.atmsimulation.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.yash.atmsimulation.exceptions.AccountNotFoundException;
import com.yash.atmsimulation.exceptions.InsufficientFunds;
import com.yash.atmsimulation.exceptions.InvalidCredentialsException;
import com.yash.atmsimulation.model.Account;
import com.yash.atmsimulation.service.AccountService;



@Controller
public class AccountController {
	@Autowired
	private AccountService accountService;


	@GetMapping("/login")	
	public String showLoginPage() {
		return "login";
	}
	
	@GetMapping("/dashboard")
	public String dashboard(HttpSession session, Model model) {
	    Account account = (Account) session.getAttribute("account");
	    model.addAttribute("account", account);
	    return "dashboard";
	}
	
	@GetMapping("/change-pin")
	public String changePinPage() {
	    return "change-pin";
	}
	
	@PostMapping("/login")
	public String login(@RequestParam String accountNumber, @RequestParam String accountPin, HttpSession session, Model model) {
	    try {
	        Account account = accountService.login(accountNumber, accountPin);
	        session.setAttribute("account", account);
	        return "dashboard";
	    } catch (InvalidCredentialsException e) {
            model.addAttribute("error", e.getMessage());
            return "login"; 
	    }
	}
	 
	 @GetMapping("/balance")
	    public String checkBalance(@RequestParam Long accountId, Model model) {
	        double balance = accountService.checkBalance(accountId);
	        model.addAttribute("balance", balance);
	        return "balance";  
	    }
	 
	 @PostMapping("/dashboard")
	 public String dashboard(@RequestParam(name = "accountId", required = false) Long accountId, 
	         @RequestParam String action, 
	         @RequestParam double amount,
	         @RequestParam(name = "toAccountId", required = false) Long toAccountId,
	         Model model, HttpSession session) {
	     if (action.equals("withdraw")) {
	         try {
	        	 Account account = (Account) session.getAttribute("account");
	             accountService.withdraw(account.getId(), amount);
	             model.addAttribute("successMessage", "Amount ₹" + amount + " withdrawn from the account.");
	         } catch (InsufficientFunds e) {
	             model.addAttribute("errorMessage", e.getMessage());
	             return "dashboard";
	         }
	     }
	         else if (action.equals("deposit")) {
	             try {
	                 Account account = (Account) session.getAttribute("account");
	                 accountService.deposit(account.getId(), amount);
	                 model.addAttribute("successMessage", "Amount ₹" + amount + " deposited into the account.");
	             } catch (InsufficientFunds e) {
	                 model.addAttribute("errorMessage", "Insufficient funds in the source account.");
	             }
	         }
	             
	         else if (action.equals("transfer")) {
	             try {
	                 Account account = (Account) session.getAttribute("account");
	                 accountService.transfer(account.getId(), toAccountId, amount);
	                 account.setBalance(account.getBalance() - amount);
	                 session.setAttribute("account", account);
	                 model.addAttribute("successMessage", "Amount ₹" + amount + " transferred to account " + toAccountId);
	             } catch (AccountNotFoundException e) {
	                 model.addAttribute("errorMessage", "Account not found.");
	             } catch (InsufficientFunds e) {
	                 model.addAttribute("errorMessage", e.getMessage());
	                 return "dashboard";
	             }
	         }
	     
	     Account account = (Account) session.getAttribute("account");
	     model.addAttribute("account", account);
	     return "dashboard";
	 }
	 
	 @PostMapping("/logout")
	 public String logout(HttpSession session, Model model) {
	     session.invalidate();
	     model.addAttribute("logoutMessage", "You have been logged out successfully.");
	     return "redirect:/login";
	 }
	 
	 @PostMapping("/changePin")
	 public String changePin(@RequestParam String accountNumber, @RequestParam String oldPin, @RequestParam String newPin, Model model, HttpSession session) {
	     try {
	         Account account = accountService.getAccountByAccountNumber(accountNumber);
	         if (account != null && account.getAccountPin().equals(oldPin)) {
	             account.setAccountPin(newPin);
	             accountService.updateAccount(account);
	             model.addAttribute("successMessage", "PIN changed successfully.");
	         } else {
	             model.addAttribute("errorMessage", "Invalid account number or old PIN.");
	         }
	     } catch (Exception e) {
	         model.addAttribute("errorMessage", "Error changing PIN.");
	     }
	     return "change-pin";
	 }

//	    @PostMapping("/transfer")
//	    public String transfer(@RequestParam Long fromAccountId,
//	                           @RequestParam Long toAccountId,
//	                           @RequestParam double amount,
//	                           Model model) {
//	        try {
//	            accountService.transfer(fromAccountId, toAccountId, amount);
//	            model.addAttribute("successMessage", "Transfer successful");
//	        } catch (AccountNotFoundException e) {
//	            model.addAttribute("Account not found", e.getMessage());
//	        }
//	        return "dashboard";  
//	    }
	 
}


