package com.yash.crudassignment.service;

import com.yash.crudassignment.model.Competency;


public interface CompetencyService {
	public void saveCompetency(Competency competency);

}
