package com.yash.crudassignment.dao;

import java.util.List;

import com.yash.crudassignment.model.Competency;

public interface CompetencyDao {
    void saveCompetency(Competency competency);
    
}
