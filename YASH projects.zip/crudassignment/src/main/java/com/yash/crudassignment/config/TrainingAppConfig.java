package com.yash.crudassignment.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;



@Configuration
@EnableWebMvc
@ComponentScan(basePackages="com.yash.crudassignment")
public class TrainingAppConfig {
	public static void main(String args[]) {
		ApplicationContext ctx= new AnnotationConfigApplicationContext(HibernateConfig.class);
		System.out.println("Application started");
	}

}
