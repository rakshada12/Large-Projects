package com.yash.crudassignment.model;


import java.util.Set;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;



@Entity
public class Training {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    private String name;
 
    // Many-to-One relationship with Competency
    @ManyToOne
    private Competency competency;
 
    // Many-to-Many relationship with User
    @ManyToMany(mappedBy = "trainings")
    private Set<User> users;
 
    // Getters and Setters
    public Long getId() {
        return id;
    }
 
    public void setId(Long id) {
this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
this.name = name;
    }
 
    public Competency getCompetency() {
        return competency;
    }
 
    public void setCompetency(Competency competency) {
        this.competency = competency;
    }
 
    public Set<User> getUsers() {
        return users;
    }
 
    public void setUsers(Set<User> users) {
        this.users = users;
    }
}