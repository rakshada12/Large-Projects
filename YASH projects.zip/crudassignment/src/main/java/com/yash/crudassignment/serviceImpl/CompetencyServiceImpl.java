package com.yash.crudassignment.serviceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.crudassignment.dao.CompetencyDao;
import com.yash.crudassignment.model.Competency;
import com.yash.crudassignment.service.CompetencyService;

@Service
public class CompetencyServiceImpl implements CompetencyService {
	@Autowired
	private CompetencyDao competencyDao;

	@Override
	@Transactional
	public void saveCompetency(Competency competency) {
		// TODO Auto-generated method stub
		competencyDao.saveCompetency(competency);
		
	}

}
