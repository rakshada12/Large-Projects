package com.yash.crudassignment.daoImpl;

import java.util.List;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.yash.crudassignment.dao.TrainingDao;
import com.yash.crudassignment.model.Training;






@Transactional
@Repository
public class TrainingDaoImpl implements TrainingDao {
 
	@Autowired
    private HibernateTemplate hibernateTemplate;
 
 
    @Override
    @Transactional
    public void saveTraining(Training training) {
        hibernateTemplate.save(training);
    }
 
    @Override
    @Transactional
    public Training getTrainingById(Long id) {
        return hibernateTemplate.get(Training.class, id);
    }
 
    @Override
    @Transactional
    public List<Training> getAllTrainings() {
        return hibernateTemplate.loadAll(Training.class);
    }
 
    @Override
    @Transactional
    public void updateTraining(Training training) {
        hibernateTemplate.update(training);
    }
 
    @Override
    @Transactional
    public void deleteTraining(Long id) {
        Training training = getTrainingById(id);
        if (training != null) {
            hibernateTemplate.delete(training);
        }
    }
}