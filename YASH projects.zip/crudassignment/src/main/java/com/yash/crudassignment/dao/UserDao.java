package com.yash.crudassignment.dao;

import java.util.List;

import com.yash.crudassignment.model.User;

public interface UserDao {
    void saveUser(User user);
   
}
