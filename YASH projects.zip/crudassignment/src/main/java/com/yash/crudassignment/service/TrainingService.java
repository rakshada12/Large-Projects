package com.yash.crudassignment.service;

import java.util.List;

import com.yash.crudassignment.model.Training;




public interface TrainingService {
    void saveTraining(Training training);
    Training getTrainingById(Long id);
    List<Training> getAllTrainings();
    void updateTraining(Training training);
    void deleteTraining(Long id);
}
