package com.yash.crudassignment.dao;

import java.util.List;

import com.yash.crudassignment.model.Training;





public interface TrainingDao {
    void saveTraining(Training training);
    Training getTrainingById(Long id);
    List<Training> getAllTrainings();
    void updateTraining(Training training);
    void deleteTraining(Long id);
}
