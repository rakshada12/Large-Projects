package com.yash.crudassignment.serviceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.crudassignment.dao.TrainingDao;
import com.yash.crudassignment.model.Training;
import com.yash.crudassignment.service.TrainingService;






@Service
public class TrainingServiceImpl implements TrainingService {
	 
	@Autowired
    private TrainingDao trainingDao;
 
   
 
    @Override
    @Transactional
    public void saveTraining(Training training) {
        trainingDao.saveTraining(training);
    }
 
    @Override
    @Transactional
    public Training getTrainingById(Long id) {
        return trainingDao.getTrainingById(id);
    }
 
    @Override
    @Transactional
    public List<Training> getAllTrainings() {
        return trainingDao.getAllTrainings();
    }
 
    @Override
    @Transactional
    public void updateTraining(Training training) {
        trainingDao.updateTraining(training);
    }
 
    @Override
    @Transactional
    public void deleteTraining(Long id) {
        trainingDao.deleteTraining(id);
    }
}
