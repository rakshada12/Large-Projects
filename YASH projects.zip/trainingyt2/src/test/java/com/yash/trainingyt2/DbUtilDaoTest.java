package com.yash.trainingyt2;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



import com.yash.trainingyt2.dao.TrainingDAO;
import com.yash.trainingyt2.daoimpl.TrainingDAOJdbcImpl;
import com.yash.trainingyt2.model.Training;
import com.yash.trainingyt2.utilities.DbUtil;

public class DbUtilDaoTest {

	Training training;
	TrainingDAO trainingdao;
	DbUtil db;

	@BeforeEach
	public void setUp() {
		training = new Training();
		trainingdao = new TrainingDAOJdbcImpl();
		db = new DbUtil();
	}

	@Test
	public void test_GivenSaveOperationTraining_ShouldReturnTrue_IfRecordAvailable() {
	String sql = "insert into trng(trainingName, description, startDate, endDate)values(?,?,?,?)";
		PreparedStatement pstmt = db.prepareStatement(sql);
			try {
			pstmt.setString(1, "Python Training");
			pstmt.setString(2, "Python trng for freshers");
			pstmt.setString(3, "2024-09-09");
			pstmt.setString(4, "2025-02-22");
		
			ResultSet resultSet = pstmt.executeQuery();
			
				Training training1 = new Training(
						resultSet.getInt("id"),
						resultSet.getString("trainingName"),
						resultSet.getString("description"),
						resultSet.getDate("startDate"),
						resultSet.getDate("endDate"));
						//resultSet.getTimestamp("createdAt"),
						//resultSet.getTimestamp("updatedAt")
					
				
			Assert.assertNotNull(training1);
			Assert.assertEquals(19, training1.getId());
			Assert.assertEquals("Python Training", training1.getTrainingName());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

	@Test
	public void test_GivenTrainingList_ShouldReturnTrue_IfTrainingListAvailable() {
	
		List<Training> trainings = new ArrayList<>();
		int t = trainingdao.findAll().size();
		String sql = "select * from trng";
		try {
		ResultSet resultSet = db.prepareStatement(sql).executeQuery();
		while(resultSet.next()) {
			Training training = new Training(
					resultSet.getInt("id"),
					resultSet.getString("trainingName"),
					resultSet.getString("description"),
					resultSet.getDate("startDate"),
					resultSet.getDate("endDate")
					//resultSet.getTimestamp("createdAt"),
					//resultSet.getTimestamp("updatedAt")
					);
			trainings.add(training);
			Assert.assertNotNull(resultSet);
			Assert.assertEquals(8, t);
		}
		} catch(SQLException e) {
			throw new RuntimeException("Error retrieving training", e);
		}
		
			
	}

	@Test
	public void test_GivenId_ShouldReturnTrue_IfTrainingAvailableById() {

		training = trainingdao.findById(10);
		System.out.println(training.toString());
		int id1 = training.getId();
		System.out.println(id1);
		Assert.assertEquals(id1, 5);

	}

	@Test
	public void test_GivenId_ShouldReturnTrue_IfTrainingRemovedById() {

		training = trainingdao.findById(12);
		
		if(training==null) {
			Assert.assertNull(training);}
		else {
			Assert.assertNotNull(training);
		}
		
//		else {Assert.assertTrue(false);}

	}

	
	@SuppressWarnings("deprecation")
	@Test
	public void test_GivenId_ShouldReturnTrue_IfTrainingUpdatedById() {

		training = trainingdao.findById(4);
		training.setTrainingName("AWS Cloud Training");
		training.setStartDate(new Date(0, 0, 0));
		training.setEndDate(new Date(0, 0, 0));
		training.setDescription("this is aws training");
		int isUpdate = trainingdao.update(training);
		
		if(isUpdate>0) {
			Assert.assertTrue(true);}
		else {
			Assert.assertTrue(true);
		}
		
//		else {Assert.assertTrue(false);}

	}
}
