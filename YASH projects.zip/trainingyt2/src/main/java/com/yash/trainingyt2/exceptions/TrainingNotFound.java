package com.yash.trainingyt2.exceptions;

public class TrainingNotFound extends RuntimeException {
	public TrainingNotFound(String message) {
		super(message);
	}

}
