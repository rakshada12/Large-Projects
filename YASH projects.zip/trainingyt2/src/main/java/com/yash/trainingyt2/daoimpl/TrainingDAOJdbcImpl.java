package com.yash.trainingyt2.daoimpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.trainingyt2.dao.TrainingDAO;
import com.yash.trainingyt2.model.Training;
import com.yash.trainingyt2.utilities.DbUtil;

public class TrainingDAOJdbcImpl extends DbUtil implements TrainingDAO{
	
	DbUtil db = new DbUtil();
	
	public void save(Training training) {
		String sql = "insert into trng(id,trainingName,description,startDate,endDate)values(?,?,?,?,?)";
	
		try {
			PreparedStatement pstmt = prepareStatement(sql);
			pstmt.setLong(1, training.getId());
			pstmt.setString(2, training.getTrainingName());
		
			pstmt.setString(3, training.getDescription());
		
			pstmt.setDate(4, new java.sql.Date(training.getStartDate().getTime()));
			pstmt.setDate(5, new java.sql.Date(training.getEndDate().getTime()));
		
			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Error saving training", e);
		}
	}

	@Override
	public List<Training> findAll() {
		// TODO Auto-generated method stub
		List<Training>trainings = new ArrayList<>();
		String sql = "select * from trng";
		try {
		ResultSet resultSet = prepareStatement(sql).executeQuery();
		while(resultSet.next()) {
			Training training = new Training(
					resultSet.getInt("id"),
					resultSet.getString("trainingName"),
					resultSet.getString("description"),
					resultSet.getDate("startDate"),
					resultSet.getDate("endDate")
					//resultSet.getTimestamp("createdAt"),
					//resultSet.getTimestamp("updatedAt")
					);
			trainings.add(training);
			
		}
		} catch(SQLException e) {
			throw new RuntimeException("Error retrieving training", e);
		}
		return trainings;
	}

	@Override
	public Training findById(int id) {
		String sql = "SELECT * FROM trng WHERE id = ?"; 
		try (
				Connection  con = db.Connect();
			PreparedStatement pstmt = con.prepareStatement(sql)) { 
			pstmt.setInt(1, id); 
			try (ResultSet resultSet = pstmt.executeQuery()) { 
				if (resultSet.next()) { 
					return new Training(resultSet.getInt("id"), 
							resultSet.getString("trainingName"), 
							resultSet.getString("description"), 
							resultSet.getDate("startDate"), resultSet.getDate("endDate") 
							//resultSet.getTimestamp("createdAt"), 
							//resultSet.getTimestamp("updatedAt") 
							); 
					} else { 
						//throw new RuntimeException("Training ID not found: " + id); 
						} 
				} 
			} catch (SQLException e) { 
				throw new RuntimeException("Error finding training by ID", e); 
				}
		return null; 
		}
	
	

	@Override
	public int remove(Training training) {
		String sql = "DELETE FROM trng WHERE id = ?"; 
		Connection  con = db.Connect();
		try (PreparedStatement pstmt = con.prepareStatement(sql)) { 
			pstmt.setInt(1, training.getId()); 
			int rowsAffected = pstmt.executeUpdate(); 
			if (rowsAffected > 0) { 
				System.out.println("Training removed successfully."); 
				} else { 
					throw new RuntimeException("Training not found for removal: " + training.getId()); 
					} 
			return rowsAffected;
			} catch (SQLException e) { 
				throw new RuntimeException("Error removing training", e); 
				}
		}
		


	@Override
	public int update(Training training) {
		String sql = "UPDATE trng SET trainingName = ?, description = ?, startDate = ?, endDate = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?"; 
		try (PreparedStatement pstmt = prepareStatement(sql)) { 
			pstmt.setString(1, training.getTrainingName()); 
			pstmt.setString(2, training.getDescription()); 
			
			pstmt.setDate(3, new Date(training.getStartDate().getTime())); 
			pstmt.setDate(4, new Date(training.getEndDate().getTime())); 
			pstmt.setInt(5, training.getId()); 
			int rowsAffected = pstmt.executeUpdate(); 
			if (rowsAffected > 0) { 
				System.out.println("Training updated successfully."); 
				return rowsAffected;
				} else { 
					return rowsAffected;
		//			throw new RuntimeException("Training ID not found for update: " + training.getId()); 
					} 
			} catch (SQLException e) { 
				throw new RuntimeException("Error updating training", e); 
				} 
		} 
		
	}
	
	


