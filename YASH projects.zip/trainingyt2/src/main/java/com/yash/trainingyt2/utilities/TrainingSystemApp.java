package com.yash.trainingyt2.utilities;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.yash.trainingyt2.dao.TrainingDAO;
import com.yash.trainingyt2.daoimpl.TrainingDAOImpl;
import com.yash.trainingyt2.daoimpl.TrainingDAOJdbcImpl;
import com.yash.trainingyt2.exceptions.TrainingNotFound;
import com.yash.trainingyt2.model.Training;
import com.yash.trainingyt2.service.TrainingService;
import com.yash.trainingyt2.serviceimpl.TrainingServiceImpl;

public class TrainingSystemApp {
    public static void main(String[] args){
Scanner scanner = new Scanner(System.in);
		TrainingDAO trainingdao = new TrainingDAOJdbcImpl();
        TrainingService trainingService = new TrainingServiceImpl(trainingdao);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
 
        while (true) {
            System.out.println("Select an operation:");
            for (TrainingSystemOperation operation : TrainingSystemOperation.values()) {
                System.out.println(operation.getOperationCode() + ". " + operation.getDescription());
            }
 
            int userChoice = scanner.nextInt();
 
            try {
                TrainingSystemOperation operation = TrainingSystemOperation.fromCode(userChoice);
 
                switch (operation) {
                    case CREATE_TRAINING:
                        createTraining(trainingService, scanner, sdf);
                        break;
                    case LIST_TRAININGS:
                        listTrainings(trainingService);
                        break;
                    case VIEW_TRAINING_BY_ID:
                        viewTrainingById(trainingService, scanner);
                        break;
                    case UPDATE_TRAINING:
                        updateTraining(trainingService, scanner, sdf);
                        break;
                    case DELETE_TRAINING:
                        deleteTraining(trainingService, scanner);
                        break;
                    case EXIT:
                        System.out.println("Exiting the application.");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid option.");
                        break;
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }
 
    private static void createTraining(TrainingService trainingService, Scanner scanner, SimpleDateFormat sdf) {
        try {
            System.out.println("Enter training ID:");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
 
            System.out.println("Enter training name:");
            String trainingName = scanner.nextLine();
 
            System.out.println("Enter description:");
            String description = scanner.nextLine();
 
            System.out.println("Enter start date (yyyy-MM-dd):");
            String startDateString = scanner.next();
            Date startDate = sdf.parse(startDateString);
 
            System.out.println("Enter end date (yyyy-MM-dd):");
            String endDateString = scanner.next();
            Date endDate = sdf.parse(endDateString);
 
            Training training = new Training(id, trainingName, description, startDate, endDate);
            trainingService.createTraining(training);
            System.out.println("Training created successfully!");
 
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
 
    private static void listTrainings(TrainingService trainingService) {
        List<Training> trainings = trainingService.getAllTrainings();
        if (trainings.isEmpty()) {
            System.out.println("No trainings found.");
        } else {
            for (Training training : trainings) {
                System.out.println(training);
            }
        }
    }
 
    private static void viewTrainingById(TrainingService trainingService, Scanner scanner){
    	try {
        System.out.println("Enter training ID:");
		int id = scanner.nextInt();
		Training training = trainingService.getTrainingById(id);
		System.out.println(training);
    	} catch(TrainingNotFound e) {
    		System.out.println("Error: "+e.getMessage());
    	}
    }
 
    private static void updateTraining(TrainingService trainingService, Scanner scanner, SimpleDateFormat sdf) {
        try {
            System.out.println("Enter the ID of the training to update:");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
 
            Training existingTraining = trainingService.getTrainingById(id);
 
            System.out.println("Enter new training name (current: " + existingTraining.getTrainingName() + "):");
            String trainingName = scanner.nextLine();
 
            System.out.println("Enter new description (current: " + existingTraining.getDescription() + "):");
            String description = scanner.nextLine();
 
            System.out.println("Enter new start date (yyyy-MM-dd) (current: " + sdf.format(existingTraining.getStartDate()) + "):");
            String startDateString = scanner.next();
            Date startDate = sdf.parse(startDateString);
 
            System.out.println("Enter new end date (yyyy-MM-dd) (current: " + sdf.format(existingTraining.getEndDate()) + "):");
            String endDateString = scanner.next();
            Date endDate = sdf.parse(endDateString);
 
            Training updatedTraining = new Training(id, trainingName, description, startDate, endDate);
            trainingService.updateTraining(updatedTraining);
            System.out.println("Training updated successfully!");
 
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
 
    private static void deleteTraining(TrainingService trainingService, Scanner scanner) {
        try {
            System.out.println("Enter training ID to delete:");
            int id = scanner.nextInt();
            Training training = trainingService.getTrainingById(id);
            trainingService.deleteTraining(training);
        } catch (RuntimeException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
