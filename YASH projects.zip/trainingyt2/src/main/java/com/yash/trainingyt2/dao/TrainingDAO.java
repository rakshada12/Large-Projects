package com.yash.trainingyt2.dao;

import java.util.List;

import com.yash.trainingyt2.model.Training;

public interface TrainingDAO {
	 void save(Training training);
	    List<Training> findAll();
	    Training findById(int id);
	    int remove(Training training);
	    int update(Training training);

}
