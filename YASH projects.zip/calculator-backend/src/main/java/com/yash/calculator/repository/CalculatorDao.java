package com.yash.calculator.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.calculator.model.Calculator;
@Repository
public interface CalculatorDao extends JpaRepository<Calculator, Integer> {
	
}
