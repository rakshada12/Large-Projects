package com.yash.calculator.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Calculator {
	
	@Id
	@Column
	private int id;
	
	@Column
    private int memory;
	
	@Column
	private String expression;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getExpression() {
		return expression;
	}
	public void setExpression(String expression) {
		this.expression = expression;
	}
	public int getMemory() {
		return memory;
	}
	public void setMemory(int memory) {
		this.memory = memory;
	}
	public Calculator(int id, int memory, String expression) {
		super();
		this.id = id;
		this.memory = memory;
		this.expression = expression;
	}
	public Calculator() {
		super();
	}
	
}
