package com.yash.hibernatecrud.model;
 
import java.util.Date;
 
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
 
import org.springframework.lang.NonNull;
 
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
 
@Data
@Getter 
@Setter
@ToString
@NoArgsConstructor
//@AllArgsConstructor

@Entity
public class Competency {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	@NonNull
	@NotBlank(message = "Compentency name should not be blank.")
	private  String competencyName;
	public Competency(@NotBlank(message = "Compentency name should not be blank.") String competencyName) {
		super();
		this.competencyName = competencyName;
	}
	
	
}