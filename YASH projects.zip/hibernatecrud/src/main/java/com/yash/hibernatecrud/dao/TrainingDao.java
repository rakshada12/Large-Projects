package com.yash.hibernatecrud.dao;

import java.util.List;

import com.yash.hibernatecrud.model.Training;

public interface TrainingDao {
	
	
	public List<Training> list();

	public void save(Training training);

	

	

}
