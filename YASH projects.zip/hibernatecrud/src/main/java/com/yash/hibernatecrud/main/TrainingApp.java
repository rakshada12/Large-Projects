package com.yash.hibernatecrud.main;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.yash.hibernatecrud.config.HibernateConfig;
import com.yash.hibernatecrud.config.TrainingAppConfig;
import com.yash.hibernatecrud.dao.TrainingDao;
import com.yash.hibernatecrud.daoImpl.TrainingDaoImpl;
import com.yash.hibernatecrud.model.Competency;
import com.yash.hibernatecrud.model.Training;
import com.yash.hibernatecrud.service.TrainingService;

/**
 * Hello world!
 */
public class TrainingApp {
    public static void main(String[] args) {
    	ApplicationContext ctx= new AnnotationConfigApplicationContext(HibernateConfig.class,TrainingAppConfig.class);  
        System.out.println("Database connected");
        TrainingService trainingService=ctx.getBean(TrainingService.class);
//        Training training = new Training("Oracle", "UI Comp", "React for freshers",new Date(), new Date(), new Date(), new Date());
//        trainingService.addTrainings(training);
//        System.out.println("Training Record inserted successfully");
	
        
//        for(Training t:trainingService.getAllTrainings()) {
//        	System.out.println("The list of trainings is as follows : "+t.getId()+" "+t.getTrainingName()+" "+t.getRequesterName()+" "+t.getDescription());
//        }
        
        
        
        Competency com= new Competency("UI comp");
    	Training tr= new Training("React", "UI comp", "React training", new Date(), new Date(), new Date(),new Date(), com);
    	trainingService.addTrainings(tr);
    	System.out.println("record inserted succesfully");
    	for(Training t:trainingService.getAllTrainings())
    	{
    		System.out.println("List of trainings"+t);
    	}
        
    	
        
    	
//    	
//    	TrainingDaoImpl tdao = new TrainingDaoImpl();
//    	System.out.println("connected");
//    	Competency com=new Competency("test");
//    	Training training = new Training("XYZ", "XYZ", "XYZ for freshers",new Date(), new Date(), new Date(), new Date(), com);
//    	
//    	
//    	
//    	tdao.save(training);
//    	System.out.println("record inserted");
//       
    }
}
