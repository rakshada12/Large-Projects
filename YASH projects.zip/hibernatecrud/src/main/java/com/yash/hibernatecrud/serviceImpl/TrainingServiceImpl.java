package com.yash.hibernatecrud.serviceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.hibernatecrud.dao.TrainingDao;
import com.yash.hibernatecrud.model.Training;
import com.yash.hibernatecrud.service.TrainingService;


@Service
public class TrainingServiceImpl implements TrainingService {
	@Autowired
	private TrainingDao trainingDao;

	
	@Transactional
	public void addTrainings(Training training) {
		trainingDao.save(training);
		
	}

	@Transactional
	public List<Training> getAllTrainings() {
		// TODO Auto-generated method stub
		return trainingDao.list();
	}

}
