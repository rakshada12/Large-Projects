package com.yash.hibernatecrud.service;

import java.util.List;

import com.yash.hibernatecrud.model.Training;

public interface TrainingService {
	public void addTrainings(Training training);
	public List<Training> getAllTrainings();

}
