package com.yash.hibernatecrud.daoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.hibernatecrud.dao.TrainingDao;
import com.yash.hibernatecrud.model.Training;


@Repository
public class TrainingDaoImpl implements TrainingDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Transactional
	public void save(Training training) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(training);
		
	}

	@Transactional
	public List<Training> list() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("from Training", Training.class).list();
	}

}