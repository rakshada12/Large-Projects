package com.yash.hibernatecrud.model;
 
import java.util.Date;
 
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
 
import org.springframework.lang.NonNull;
 
import lombok.AllArgsConstructor;
import lombok.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.AllArgsConstructor;
import javax.persistence.Entity;
import javax.persistence.Id;
@Data
@Getter 
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Training {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@NonNull
	@NotEmpty(message = "Training name should be null.")
	@NotBlank(message = "Traning name should not be blank.")
	private  String trainingName;
	@NonNull
	private String requestorName;
	@NonNull
	private  String description;
	@NonNull
	private  Date startDate;
	@NonNull
	private  Date endDate;
	@NonNull
	private  Date createdAt;
	@NonNull
	private  Date updatedAt;
	@NonNull
	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="compentency_detail_id")
	private Competency comp;
	public Training(
			@NotEmpty(message = "Training name should be null.") @NotBlank(message = "Traning name should not be blank.") String trainingName,
			String requestorName, String description, Date startDate, Date endDate, Date createdAt, Date updatedAt,
			Competency comp) {
		super();
		this.trainingName = trainingName;
		this.requestorName = requestorName;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.comp = comp;
	}
	
	
 
}