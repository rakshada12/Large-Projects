package com.yash.crudjdbc.daoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.crudjdbc.dao.TrainingDao;
import com.yash.crudjdbc.model.Training;






@Repository
public class TrainingDaoImpl implements TrainingDao
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Transactional
	public void save(Training training) {
		String sql = "INSERT INTO training (id,trainingName,requesterName,startDate,description,endDate,createdAt,updatedAt) VALUES (?, ?, ?, ? ,? ,? ,? ,?)";
        jdbcTemplate.update(sql,training.getId(),training.getTrainingName(),training.getRequestorName(),training.getStartDate(),training.getDescription(),training.getEndDate(),training.getCreatedAt(),training.getUpdatedAt());
 
		
	}
 
	
	public List<Training> list() 
	{
        String sql = "SELECT * FROM training";
        return jdbcTemplate.query(sql, new RowMapper<Training>()
        {
            public Training mapRow(ResultSet rs, int rowNum) throws SQLException 
            {
               Training training = new Training();
               training.setId(rs.getLong("id"));
               training.setTrainingName(rs.getString("trainingName"));
               training.setRequestorName(rs.getString("requesterName"));
                return training;
 
		
            }
        });
    }


	
}