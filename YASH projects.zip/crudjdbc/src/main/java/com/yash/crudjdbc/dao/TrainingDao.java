package com.yash.crudjdbc.dao;

import java.util.List;

import com.yash.crudjdbc.model.Training;





public interface TrainingDao {
	
	
	public List<Training> list();

	public void save(Training training);
	

	

}
