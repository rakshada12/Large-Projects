package com.yash.crudjdbc.main;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.yash.crudjdbc.config.TrainingAppConfig;
import com.yash.crudjdbc.model.Training;
import com.yash.crudjdbc.service.TrainingService;






/**
 * Hello world!
 */
public class TrainingApp {
    public static void main(String[] args) {
    	ApplicationContext ctx= new AnnotationConfigApplicationContext(TrainingAppConfig.class);  
        System.out.println("Database connected");
        TrainingService trainingService=ctx.getBean(TrainingService.class);
//        Competency comp = new Competency("Java comp");
       
       Training training1 = new Training((long) 5, "React", "React Comp", "React for freshers",new Date(), new Date(), new Date(), new Date());
        trainingService.addTrainings(training1);
        System.out.println("Training Record inserted successfully");
	
//        trainingService.deleteTraining(3L);
//        
//        for(Training t:trainingService.getAllTrainings()) {
//        	
//        	 
//        	System.out.println("The list of trainings is as follows : "+t.getId()+" "+t.getTrainingName()+" "+t.getRequestorName()+" "+t.getDescription());
//        }
        
 
        
      
    	
    	
//    	TrainingDaoImpl tdao = new TrainingDaoImpl();
//    	System.out.println("connected");
//    	Competency com=new Competency("test");
//    	Training training = new Training("XYZ", "XYZ", "XYZ for freshers",new Date(), new Date(), new Date(), new Date(), com);
//    	
//    	
//    	
//    	tdao.save(training);
//    	System.out.println("record inserted");
       
    }
}
