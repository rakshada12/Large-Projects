package com.yash.crudjdbc.service;

import java.util.List;

import com.yash.crudjdbc.model.Training;





public interface TrainingService {
	public void addTrainings(Training training);
	public List<Training> getAllTrainings();


}
