package com.yash.crudjdbc.serviceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.crudjdbc.dao.TrainingDao;
import com.yash.crudjdbc.model.Training;
import com.yash.crudjdbc.service.TrainingService;





@Service
public class TrainingServiceImpl implements TrainingService {
	@Autowired
	private TrainingDao trainingDao;

	
	@Transactional
	public void addTrainings(Training training) {
		trainingDao.save(training);
		
	}

	@Transactional
	public List<Training> getAllTrainings() {
		// TODO Auto-generated method stub
		return trainingDao.list();
	}

	


}
