package com.yash.demoapptraining.test;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.yash.demoapptraining.exception.TraningIdNotFoundeXception;
import com.yash.demoapptraining.model.Training;
import com.yash.demoapptraining.repository.TrainingRepository;
import com.yash.demoapptraining.service.TrainingServiceImpl;

@ExtendWith(MockitoExtension.class)
public class TrainingServiceImplTest {

    @Mock
    private TrainingRepository trainingRepo;

    @InjectMocks
    private TrainingServiceImpl trainingService;

    @Test
    public void testAddTraining() {
   
        Training training = new Training("Testing", "Java comp", "Testing for freshers");
        when(trainingRepo.save(training)).thenReturn(training);
        Training result = trainingService.addTraining(training);
        assertEquals(training, result);
    }

    @Test
    public void testListTrainings() {
      
        List<Training> trainings = new ArrayList<>();
        trainings.add(new Training("Test1", "UI Comp", "Test traing"));
        trainings.add(new Training("Test2", "Python comp", "Test training 2"));
        when(trainingRepo.findAll()).thenReturn(trainings);
        List<Training> result = trainingService.listTrainings();

        assertEquals(trainings, result);
    }

    @Test
    public void testUpdateTraining() {
        Training training = new Training("Testing", "Java comp", "Testing for freshers");
        when(trainingRepo.save(training)).thenReturn(training);
        Training result = trainingService.updateTraining(training);

        assertEquals(training, result);
    }

    @Test
    public void testDeleteTraining() throws TraningIdNotFoundeXception {

        Long id = 1L;
        when(trainingRepo.existsById(id)).thenReturn(true);

        trainingService.deleteTraining(id);// No exception will be thrown
    }

    @Test
    public void testDeleteTrainingNotFound() {
   
        Long id = 1L;
        when(trainingRepo.existsById(id)).thenReturn(false);
        assertThrows(TraningIdNotFoundeXception.class, () -> trainingService.deleteTraining(id));
    }
}
