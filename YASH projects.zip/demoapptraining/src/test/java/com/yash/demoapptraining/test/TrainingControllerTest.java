package com.yash.demoapptraining.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.demoapptraining.controller.TrainingController;
import com.yash.demoapptraining.exception.TraningIdNotFoundeXception;
import com.yash.demoapptraining.model.Training;
import com.yash.demoapptraining.service.TrainingServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@ExtendWith(MockitoExtension.class)
public class TrainingControllerTest {

    private MockMvc mockMvc;

    @Mock
    private TrainingServiceImpl trainingService;

    @InjectMocks
    private TrainingController trainingController;

    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(trainingController).build();
    }

    @Test
    public void testAddTraining() throws Exception {
        Training training = new Training("Testing", "Java comp", "Testing for freshers");
        when(trainingService.addTraining(any())).thenReturn(training);

        String json = objectMapper.writeValueAsString(training);
        mockMvc.perform(post("/addTraining")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isCreated());
        assertNotNull(training);
    }

    @Test
    public void testListTrainings() throws Exception {
 
        List<Training> trainings = new ArrayList<>();
        trainings.add(new Training("Testing", "Java comp", "Testing for freshers"));
        trainings.add(new Training("Controller Testing", "Java comp", "Testing for freshers"));
        when(trainingService.listTrainings()).thenReturn(trainings);

        mockMvc.perform(get("/listTraining"))
                .andExpect(status().isOk());
        assertEquals(trainings.size(), 2);
    }

    @Test
    public void testUpdateTraining() throws Exception {
        Training training = new Training("UI Testing", "Java comp", "Testing for freshers");
        when(trainingService.updateTraining(any())).thenReturn(training);
        String json = objectMapper.writeValueAsString(training);
        mockMvc.perform(put("/updateTraining")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk());

        assertNotNull(training);
    }


}


