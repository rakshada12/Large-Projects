package com.yash.demoapptraining.test;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
 
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.yash.demoapptraining.model.Training;
import com.yash.demoapptraining.repository.TrainingRepository;
 

 
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class TrainingRepositoryTest {
 
	@Autowired
	private TrainingRepository tRepo;
 
	@Test
	public void test_saveMethod_GivenTrainingRecord_ShouldSaveTraining()
	{           Training t=new Training("hgghj","fdgdg","dsfsdf");
				Training trr=tRepo.save(t);
				assertNotNull(trr);
				Assertions.assertThat(trr.getName().equals(t.getName()));
 
	}
	@Test
	public void test_findTrainingByNameMethod_GivenTrainingRecord_ShouldreturnTrueIfTrainingNameMatches()
	{
		   Training t=new Training("hgghj","fdgdg","dsfsdf");
			Training trr=tRepo.save(t);
		Training tt=tRepo.findTrainingByName(trr.getName());//findById(trr.getId()).get();
		assertNotNull(tt);
	Assertions.assertThat(tt.getName().equals(t.getName()));
 
	}
}