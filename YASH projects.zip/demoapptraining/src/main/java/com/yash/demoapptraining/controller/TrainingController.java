package com.yash.demoapptraining.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.demoapptraining.exception.TraningIdNotFoundeXception;
import com.yash.demoapptraining.model.Training;
import com.yash.demoapptraining.service.MapValidationErrorService;
import com.yash.demoapptraining.service.TrainingService;


import org.springframework.http.ResponseEntity;

import org.springframework.validation.annotation.Validated;




@RestController
public class TrainingController {
	
	@Autowired
	private TrainingService trainingService;
	
//	 @Autowired
//		private MapValidationErrorService mapValidationErrorService;

		/*@PostMapping
		public ResponseEntity<?> createNewProject(@Validated @RequestBody Training training, BindingResult result) {
			ResponseEntity<?> errorMap = mapValidationErrorService.mapValidationError(result);
			if (errorMap != null)
				return errorMap;
			Training savedTraining = trainingService.addTraining(training);
			return new ResponseEntity<Training>(savedTraining, HttpStatus.CREATED);
		}*/
	
    @PostMapping("/addTraining")
	public ResponseEntity<Training> addTraining(@RequestBody Training training) {
		
		Training savedTraining = trainingService.addTraining(training);
			return new ResponseEntity<Training>(savedTraining, HttpStatus.CREATED);
	}

	@GetMapping("/listTraining")
	public ResponseEntity<List<Training>> listTrainings() {
		
		//return trainingService.listTrainings();
		List<Training> trainings = trainingService.listTrainings();
		return new ResponseEntity<List<Training>>(trainings, HttpStatus.OK);
	}

	@PutMapping("/updateTraining")
	public Training updateTraining( @RequestBody Training training) {
		
		return trainingService.updateTraining(training);
	}

	@DeleteMapping("/deleteTraining/{id}")
	public ResponseEntity<String> deleteTraining( @PathVariable Long id) throws TraningIdNotFoundeXception {
		//trainingService.deleteTraining(id);
		trainingService.deleteTraining(id);
		return new ResponseEntity<String>(
				"Training with " + id+ " is successfully deleted", HttpStatus.OK);
	}
	

}
