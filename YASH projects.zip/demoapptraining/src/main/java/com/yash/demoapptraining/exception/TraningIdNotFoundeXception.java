package com.yash.demoapptraining.exception;

public class TraningIdNotFoundeXception extends Exception {
	TraningIdNotFoundeXception()
	{}
	public TraningIdNotFoundeXception(String msg)
	{
		super(msg);
	}

}
