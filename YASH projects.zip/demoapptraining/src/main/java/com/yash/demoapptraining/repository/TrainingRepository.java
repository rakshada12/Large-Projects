package com.yash.demoapptraining.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.demoapptraining.model.Training;



@Repository
public interface TrainingRepository extends JpaRepository<Training,Long> {
	public Training findTrainingByName(String trainingName);

}
