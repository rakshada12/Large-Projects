package com.yash.productcart.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.productcart.model.ProductCart;

public interface ProductCartRepository extends JpaRepository<ProductCart,Long> {

	

}
