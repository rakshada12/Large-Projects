package com.yash.productcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter
@Setter
public class ProductCart {
	@Id
	private Long productId;
	private String productName;
	private double price;
	private String description;
	private double rating;
	@Override
	public String toString() {
		return "ProductCart [productId=" + productId + ", productName=" + productName + ", price=" + price
				+ ", description=" + description + ", rating=" + rating + "]";
	}
	public ProductCart(Long productId, String productName, double price, String description, double rating) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.description = description;
		this.rating = rating;
	}
	
	
	
	

}
