package com.yash.productcart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.reactive.function.client.WebClient;

import com.yash.productcart.model.ProductCart;
import com.yash.productcart.repository.ProductCartRepository;
import com.yash.productcart.service.ProductCartServiceImpl;
import com.yash.productdetails.model.ProductDetails;
import com.yash.productrating.model.ProductRating;

import reactor.core.publisher.Flux;

@Controller
@RequestMapping("/api")
public class ProductCartController {
	@Autowired
	WebClient.Builder webClientBuilder;
	@Autowired
	ProductCartRepository repo;
	
	@Autowired
	private ProductCartServiceImpl productService;
	
	@PostMapping("/create")
	public void createRecord(@RequestBody ProductCart cart)
	{
		System.out.println("creating a record");
		productService.addCart(cart);
	}
	
//	@GetMapping("/cart")
//	public ResponseEntity<?> getList(){
//		return new ResponseEntity<>(productService.getList(), HttpStatus.OK);
//	}
	
	@GetMapping(value="/cart", headers="Accept=application/json")
	public Flux<ProductCart> getList()
	{
		List<ProductCart> cartList=productService.getList();
		return Flux.fromIterable(cartList).flatMap(cart->{
			WebClient productWebClient=webClientBuilder.baseUrl("http://localhost:8084/details").build();
			WebClient ratingWebClient=webClientBuilder.baseUrl("http://localhost:8085/rating").build();
			return productWebClient.get().uri("/getAllProductDetails")
					.retrieve().bodyToFlux(ProductDetails.class).zipWith(ratingWebClient.get().uri("/getAllRatings")
							.retrieve().bodyToFlux(ProductRating.class),
							(product,productRating)->new ProductCart((long) product.getProductId(),product.getProductName(),cart.getPrice(),
									cart.getDescription(),productRating.getRating()))
					.collectList()
					.flatMapMany(Flux::fromIterable);
		});
	
	}

}
