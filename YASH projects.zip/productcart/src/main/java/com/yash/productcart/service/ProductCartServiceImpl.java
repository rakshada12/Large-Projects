package com.yash.productcart.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.yash.productcart.model.ProductCart;
import com.yash.productcart.repository.ProductCartRepository;


@Service
public class ProductCartServiceImpl implements ProductCartService {
	
	
	@Autowired
	private ProductCartRepository repo;

	@Override
	public List<ProductCart> getList() {
		// TODO Auto-generated method stub
//		List<ProductCart> cartList = repo.findAll();
//        return cartList.stream().map(cartsList -> {
//            ProductDetails product = restTemplate.getForObject("http://localhost:8084/details/get/" + cartsList.getProductId(), ProductDetails.class);
//            ProductRating productRating = restTemplate.getForObject("http://localhost:8085/product/rating/" + cartsList.getProductId(), ProductRating.class);
//            return new ProductCart(cartsList.getProductId(), product.getProductName(), cartsList.getPrice(), cartsList.getDescription(), productRating.getRating());
//        }).collect(Collectors.toList());
		return repo.findAll();
	}

	@Override
	public void addCart(ProductCart p) {
		// TODO Auto-generated method stub
		repo.save(p);
	}

}
