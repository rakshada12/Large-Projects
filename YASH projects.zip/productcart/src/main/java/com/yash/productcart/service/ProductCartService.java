package com.yash.productcart.service;

import java.util.List;

import com.yash.productcart.model.ProductCart;

public interface ProductCartService {
	public List<ProductCart> getList();
	public void addCart(ProductCart p);

}
