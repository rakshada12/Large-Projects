package com.yash.oms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.yash.oms.model.Item;
import com.yash.oms.model.Restaurant;
//import com.yash.oms.model.Restaurant;


@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {
	List<Item> findByRestaurant(Restaurant restaurant);
}
