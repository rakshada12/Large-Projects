package com.yash.oms.model;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;




@Entity
@Table(name = "items")
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long itemId;
    @NotBlank(message="Item cannot be blank")
    private String itemName;
    @NotNull(message="quantity cannot be null")
    private Integer quantityOfItem;
    private Double cost;
    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    private Restaurant restaurant;
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Integer getQuantityOfItem() {
		return quantityOfItem;
	}
	public void setQuantityOfItem(Integer quantityOfItem) {
		this.quantityOfItem = quantityOfItem;
	}
	public Double getCost() {
		return cost;
	}
	public void setCost(Double cost) {
		this.cost = cost;
	}
	public Restaurant getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	public Item(@NotBlank(message = "Item cannot be blank") String itemName,
			@NotNull(message = "quantity cannot be null") Integer quantityOfItem, Double cost, Restaurant restaurant) {
		super();
		this.itemName = itemName;
		this.quantityOfItem = quantityOfItem;
		this.cost = cost;
		this.restaurant = restaurant;
	}
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	

	
   
}
