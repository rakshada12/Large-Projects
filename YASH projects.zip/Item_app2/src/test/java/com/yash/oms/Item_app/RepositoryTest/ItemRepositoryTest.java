package com.yash.oms.Item_app.RepositoryTest;




import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.yash.oms.model.Item;
import com.yash.oms.repository.ItemRepository;
import com.yash.oms.service.ItemServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

public class ItemRepositoryTest {

    @Mock
    private ItemRepository itemRepository;

    @InjectMocks
    private ItemServiceImpl itemService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindByRestaurantId() {
        Long restaurantId = 1L;
        Item item1 = new Item("abc", restaurantId, 10, 10.0);
        Item item2 = new Item("xyz", restaurantId, 20, 5.0);
        List<Item> items = Arrays.asList(item1, item2);

        when(itemRepository.findByRestaurantId(restaurantId)).thenReturn(items);

        List<Item> result = itemService.viewAllItemsByRestaurant(restaurantId);
        assertEquals(2, result.size());
        assertEquals("abc", result.get(0).getItemName());
        assertEquals("xyz", result.get(1).getItemName());
    }
}
