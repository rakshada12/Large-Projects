package com.yash.oms.Item_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
