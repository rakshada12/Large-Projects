module trainingsyt {
	requires java.sql;
	
}