package com.yash.trainingsyt.dao;

import java.util.List;

import com.yash.trainingsyt.model.Training;

public interface TrainingDAO {
	 void save(Training training);
	    List<Training> findAll();
	    Training findById(int id);
	    void remove(Training training);
	    void update(Training training);

}
