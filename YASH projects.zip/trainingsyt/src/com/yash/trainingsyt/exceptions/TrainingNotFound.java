package com.yash.trainingsyt.exceptions;

public class TrainingNotFound extends RuntimeException {
	public TrainingNotFound(String message) {
		super(message);
	}

}
