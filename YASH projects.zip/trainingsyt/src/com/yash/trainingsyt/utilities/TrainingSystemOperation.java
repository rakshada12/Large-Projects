package com.yash.trainingsyt.utilities;

public enum TrainingSystemOperation {
    CREATE_TRAINING(1, "Create Training"),
    LIST_TRAININGS(2, "List Trainings"),
    VIEW_TRAINING_BY_ID(3, "View Training by ID"),
    UPDATE_TRAINING(4, "Update Training"),
    DELETE_TRAINING(5, "Delete Training"),
    EXIT(6, "Exit");
 
    private final int operationCode;
    private final String description;
 
    TrainingSystemOperation(int operationCode, String description) {
        this.operationCode = operationCode;
        this.description = description;
    }
 
    public int getOperationCode() {
        return operationCode;
    }
 
    public String getDescription() {
        return description;
    }
 
    public static TrainingSystemOperation fromCode(int code) {
        for (TrainingSystemOperation operation : values()) {
            if (operation.getOperationCode() == code) {
                return operation;
            }
        }
        throw new IllegalArgumentException("Invalid operation code: " + code);
    }
}
