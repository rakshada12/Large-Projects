package com.yash.trainingsyt.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DbUtil {

		public static String driverName = "com.mysql.jdbc.Driver";
		public String url = "jdbc:mysql://localhost:3306/yash";
		public String userName = "root";
		public String password = "root";
		public Connection con = null;
		private PreparedStatement pstmt;
		
		public DbUtil() {
			System.out.println("---------------Inside the constructor");
		}
		static {
			System.out.println("---------------In static block");
			try {
				Class.forName(driverName);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public Connection Connect() {
			try {
				con = (Connection)DriverManager.getConnection(url,userName,password);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
		}
		public PreparedStatement prepareStatement(String sql) {
			try {
				pstmt =(PreparedStatement) Connect().prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return pstmt;
		}
		
		public void closePrepareStatement() {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	

}
