package com.yash.trainingsyt.test;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.trainingsyt.dao.TrainingDAO;
import com.yash.trainingsyt.model.Training;
import com.yash.trainingsyt.utilities.DbUtil;

public class DbUtilDaoTest {
	public static void main(String[] args) {
		Training training;
		TrainingDAO trainingdao;
		DbUtil db;

		// Connection con = db.Connect();

	}

}
