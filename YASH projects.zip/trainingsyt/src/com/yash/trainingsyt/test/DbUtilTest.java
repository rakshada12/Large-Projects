package com.yash.trainingsyt.test;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.trainingsyt.utilities.DbUtil;


public class DbUtilTest extends DbUtil {
	public static void main(String[] args) {
		DbUtil db = new DbUtil();
		System.out.println(db.driverName);
		Connection con = db.Connect();
		System.out.println(con);
		String sql = "insert into trng(trainingName, description)values(?,?)";
		PreparedStatement pstmt = db.prepareStatement(sql);
		try {
			pstmt.setString(1, "Java Training");
			pstmt.setString(2, "Java trng for full stack development");
			pstmt.execute();
			System.out.println("Training record added successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
