package com.yash.trainingsyt.test;
import java.util.Date;
import java.util.List;

import com.yash.trainingsyt.dao.TrainingDAO;
import com.yash.trainingsyt.daoimpl.TrainingDAOImpl;
import com.yash.trainingsyt.model.Training;

public class TrainingDAOImplSaveTest {
	public static void main(String[] args) {
	TrainingDAO trainingdao = new TrainingDAOImpl();
	Training training1 = new Training();
	
	training1.setId(1);
	training1.setTrainingName("AWS");
	training1.setDescription("Play with concepts");
	training1.setStartDate(new Date());
	training1.setEndDate(new Date());
	trainingdao.save(training1);
	List<Training> trainings = trainingdao.findAll();
	System.out.println(trainings);
	}

}
