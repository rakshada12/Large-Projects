package com.yash.trainingsyt.serviceimpl;

import java.util.List;

import com.yash.trainingsyt.dao.TrainingDAO;
import com.yash.trainingsyt.exceptions.TrainingNotFound;
import com.yash.trainingsyt.model.Training;
import com.yash.trainingsyt.service.TrainingService;

public class TrainingServiceImpl implements TrainingService {
    private TrainingDAO trainingDAO;
 
    public TrainingServiceImpl(TrainingDAO trainingDAO) {
        this.trainingDAO = trainingDAO;
    }
 
    @Override
    public void createTraining(Training training) {
        trainingDAO.save(training);
    }
 
    @Override
    public List<Training> getAllTrainings() {
        return trainingDAO.findAll();
    }
 
    @Override
    public Training getTrainingById(int id){
    	try {
    	return trainingDAO.findById(id);
    	} catch (RuntimeException e) {
    	 throw new TrainingNotFound("Training of id " + id + " not found.");
    	}
 }
 
    @Override
    public void updateTraining(Training training) {
        trainingDAO.update(training);
    }
 
    @Override
    public void deleteTraining(Training training) {
        trainingDAO.remove(training);
    }
}
