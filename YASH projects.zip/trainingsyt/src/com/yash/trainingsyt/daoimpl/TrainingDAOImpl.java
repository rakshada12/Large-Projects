package com.yash.trainingsyt.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.yash.trainingsyt.dao.TrainingDAO;
import com.yash.trainingsyt.model.Training;

public class TrainingDAOImpl implements TrainingDAO {
    private List<Training> trainings = new ArrayList<>();
 
    @Override
    public void save(Training training) {
        trainings.add(training);
    }
 
    @Override
    public List<Training> findAll() {
        return new ArrayList<>(trainings);
    }
 
    @Override
    public Training findById(int id) {
        for(Training training : trainings) {
        	if(training.getId() == id) {
        		return training;
        	}
        }
        throw new RuntimeException("Training ID not found: " + id);
    }
 
    @Override
    public void remove(Training training) {
        if (!trainings.remove(training)) {
            throw new RuntimeException("Training not found for deletion: " + training.getId());
        }
    }
 
    @Override
    public void update(Training training) {
        Training existingTraining = findById(training.getId());
        existingTraining.setTrainingName(training.getTrainingName());
        existingTraining.setDescription(training.getDescription());
        existingTraining.setStartDate(training.getStartDate());
        existingTraining.setEndDate(training.getEndDate());
        //existingTraining.setUpdatedAt(new Date());
    }
}
