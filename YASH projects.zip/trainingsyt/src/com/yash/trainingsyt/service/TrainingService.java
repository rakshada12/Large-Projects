package com.yash.trainingsyt.service;

import java.util.List;

import com.yash.trainingsyt.model.Training;

public interface TrainingService {
    void createTraining(Training training);
    List<Training> getAllTrainings();
    Training getTrainingById(int id);
    void updateTraining(Training training);
    void deleteTraining(Training training);
}
