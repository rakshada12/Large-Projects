package com.yash.trainingyt3.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.trainingyt3.model.Training;

@Repository
public interface TrainingDAO {
	 void save(Training training);
	    List<Training> findAll();
	    Training findById(int id);
	    void remove(Training training);
	    void update(Training training);

}
