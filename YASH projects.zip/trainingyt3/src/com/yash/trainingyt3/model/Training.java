package com.yash.trainingyt3.model;

import java.util.Date;

public class Training {

	private int id;
	private String trainingName;
	private String description;
	private Date startDate;
	private Date endDate;
	private Date createdAt;
	private Date updatedAt;

	    public Training(int id, String trainingName, String description, Date startDate, Date endDate) {
	    	this.id = id;
	        this.trainingName = trainingName;
	        this.description = description;
	        this.startDate = startDate;
	        this.endDate = endDate;
	        this.createdAt = new Date();
	        this.updatedAt = new Date();
	    }
	 
	    

		public int getId() {
	        return id;
	    }
	 
	    public void setId(int id) {
	this.id = id;
	        this.updatedAt = new Date();
	    }
	 
	    public String getTrainingName() {
	        return trainingName;
	    }
	 
	    public void setTrainingName(String trainingName) {
	        this.trainingName = trainingName;
	        this.updatedAt = new Date();
	    }
	 
	    public String getDescription() {
	        return description;
	    }
	 
	    public void setDescription(String description) {
	        this.description = description;
	        this.updatedAt = new Date();
	    }
	 
	    public Date getStartDate() {
	        return startDate;
	    }
	 
	    public void setStartDate(Date startDate) {
	        this.startDate = startDate;
	        this.updatedAt = new Date();
	    }
	 
	    public Date getEndDate() {
	        return endDate;
	    }
	 
	    public void setEndDate(Date endDate) {
	        this.endDate = endDate;
	        this.updatedAt = new Date();
	    }
	 
	    public Date getCreatedAt() {
	        return createdAt;
	    }
	 
	    public Date getUpdatedAt() {
	        return updatedAt;
	    }
	    
	    public Training() {
			// TODO Auto-generated constructor stub
		}
	 
	    



		@Override
	    public String toString() {
	        return "Training [ID=" + id + ", Training Name=" + trainingName + ", Description=" + description +
	               ", Start Date=" + startDate + ", End Date=" + endDate + ", Created At=" + createdAt +
	               ", Updated At=" + updatedAt + "]";
	    }

}