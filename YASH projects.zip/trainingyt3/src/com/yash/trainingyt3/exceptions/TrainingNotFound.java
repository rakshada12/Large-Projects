package com.yash.trainingyt3.exceptions;

public class TrainingNotFound extends RuntimeException {
	public TrainingNotFound(String message) {
		super(message);
	}

	public TrainingNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}


}
