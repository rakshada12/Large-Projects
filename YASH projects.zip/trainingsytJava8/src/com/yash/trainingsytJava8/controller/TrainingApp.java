package com.yash.trainingsytJava8.controller;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Optional;
import java.util.Scanner;


import com.yash.trainingsytJava8.exceptions.RecordNotExist;
import com.yash.trainingsytJava8.model.Training;
import com.yash.trainingsytJava8.service.TrainingService;
import com.yash.trainingsytJava8.service.TrainingServiceImpl;
import com.yash.trainingsytJava8.utilities.Constants;

/**
 * 
 * menu driven main class.
 *
 */

public class TrainingApp{
	/**
	 * 
	 * @param args holds the main class for running the application
	 */
	
	public static void main(String args[])
	{
		//Initializing the training list
		TrainingServiceImpl.setTrngList(TrainingService.initTrainings(new ArrayList<Training>()));
		//Try with resources to automatically close the scanner
		try(Scanner sc=new Scanner(System.in)){
			//calling method that handles the training operations
		trngOperations(sc);
		}catch(Exception e) {
			System.out.println("An error occured: " + e.getMessage());
		}
	}
 
	private static void trngOperations(Scanner sc) {
		
		int i=Constants.STR_EMPTY;
		TrainingService t = new TrainingServiceImpl();
		do {
			try {
			System.out.println("Please enter one choice");
			System.out.println("1:GET Training By ID");
			System.out.println("2:GET Training By Name");
			System.out.println("3:GET Training By Requester");
			System.out.println("4:GET Requesters");
			System.out.println("5:EXIT");
			i=sc.nextInt();
			int userInput=Constants.STR_EMPTY;
			String userInput2 = Constants.STR_EMPTY2;
			switch(i)
			{
			case Constants.STR_1:
			
				System.out.println("Please Enter the training id");
				//userInput=sc.nextInt();
				int trainingId=sc.nextInt();
                Optional<Training> trainingOpt = t.getTrainingById(trainingId);
                
                trainingOpt.ifPresentOrElse(
                    training -> System.out.println(training),
                    	() -> System.out.println("Training with ID " + trainingId + " not found.")
                );
                break;
			
			case Constants.STR_2:
			
				
				System.out.println("Please Enter the training name");
				try {
				userInput2=sc.next();
				System.out.println(t.getTrainingByName(userInput2));
				}
				catch(RecordNotExist e) {
		    		System.out.println("Error: "+e.getMessage());
		    	}
				break;
			
			case Constants.STR_3:
			
				System.out.println("Please Enter the training requester");
				try {
				sc.nextLine();
				userInput2=sc.nextLine();
				
				System.out.println(t.getTrainingByRequester(userInput2));
				}
				catch(RecordNotExist e) {
		    		System.out.println("Error: "+e.getMessage());
		    	}
				break;
			
			case Constants.STR_4:
			
				System.out.println("Getting the list of requesters...");
				System.out.println("------------------------------");
				System.out.println(t.getRequesterList());
				break;
			
			case Constants.STR_EXIT:
			
				 System.out.println("----------Exiting----------");
                 sc.close();
			break;
			}
	}catch(InputMismatchException e) {
		System.out.println("Invalid input, please enter a valid no.");
		sc.nextLine();
	}
		
	}while(!(i==(Constants.STR_EXIT)));
		//while(i!=(Constants.STR_EXIT));  	Repeating until user selects EXIT
}
}
