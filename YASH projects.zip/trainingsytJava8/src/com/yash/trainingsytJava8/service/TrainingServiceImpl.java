package com.yash.trainingsytJava8.service;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;


import com.yash.trainingsytJava8.exceptions.RecordNotExist;
import com.yash.trainingsytJava8.model.Training;
import com.yash.trainingsytJava8.utilities.CustomSupplier;
import com.yash.trainingsytJava8.utilities.TrainingPredicate;
/**
 * 
 * TrainingServiceImpl class provides implementation to the getTrainingById, getTrainingByName, getTrainingByRequester
 * and getRequesterList() methods of TrainingService interface
 *
 */

public class TrainingServiceImpl implements TrainingService {
    private static List<Training> trngList;
    private static CustomSupplier supplier = new CustomSupplier();
    public static List<Training> getTrngList() {
		return trngList;
	}
 
	public static void setTrngList(List<Training> trngList) {
		TrainingServiceImpl.trngList = trngList;
	}
 
	@Override
	public Optional<Training> getTrainingById(int id) {
//			List<Training> result1=new ArrayList<>();
//			
//			//System.out.println(trngList);
//			for(Training e:trngList)
//			{
//			
//				if(e.getId()==id)
//				{
//					result1.add(e);
//					//return List.of(e);
//				}
//				
//			}
//			//System.out.println(supplier.get());
//			return result1;	
		LocalDate date = LocalDate.now();
		LocalDateTime datetime = LocalDateTime.now();
		DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm:ss yyyy-mm-dd");
		System.out.println("Current Date: " + date);
		System.out.println("Current DateTime: " + datetime.format(f));
		System.out.println("---------------------------------------------------");
		return trngList.stream().filter(TrainingPredicate.byId(id)).findFirst();//.orElseGet(supplier);
	}

	
	public List<Training> getTrainingByName(String name) {
		// TODO Auto-generated method stub
		
		LocalDate date = LocalDate.now();
		LocalDateTime datetime = LocalDateTime.now();
		DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm:ss yyyy-mm-dd");
		System.out.println("Current Date: " + date);
		System.out.println("Current DateTime: " + datetime.format(f));
		System.out.println("---------------------------------------------------");
		List<Training> result = trngList.stream().filter(TrainingPredicate.byName(name)).collect(Collectors.toList());
		if (result.isEmpty()) {
			throw new RecordNotExist("Record of Training " + name + " not found.");
		}
		return result;
		   	
	}

	
	
	public List<Training> getTrainingByRequester(String requesterName) {
		// TODO Auto-generated method stub

		LocalDate date = LocalDate.now();
		LocalDateTime datetime = LocalDateTime.now();
		DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm:ss yyyy-mm-dd");
		System.out.println("Current Date: " + date);
		System.out.println("Current DateTime: " + datetime.format(f));
		System.out.println("---------------------------------------------------");
		List<Training> result = trngList.stream().filter(TrainingPredicate.byRequesterName(requesterName)).collect(Collectors.toList());
		if(result.isEmpty()) {
			throw new RecordNotExist("Record of Requester " + requesterName + " not found.");
		}
		return result;
	}

	
	public List<String> getRequesterList() {
		// TODO Auto-generated method stub
		
		//creating a consumer to perform actions on each requester name
		Consumer<String> r = requester -> System.out.println("Requester: "+requester);
		//collecting the requester's names and apply consumer
		List<String> requesterList = trngList.stream().map(Training::getRequesterName).peek(r).collect(Collectors.toList());
		//applying consumer to each element
		return requesterList;
		//return (List<String>) trngList.stream().map(t->t.getRequesterName()).distinct().collect(Collectors.toList());
	}
 
 
	
}