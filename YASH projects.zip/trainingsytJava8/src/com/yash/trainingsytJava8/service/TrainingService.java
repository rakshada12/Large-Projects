package com.yash.trainingsytJava8.service;
import java.util.List;
import java.util.Optional;

import com.yash.trainingsytJava8.model.Training;
import com.yash.trainingsytJava8.utilities.Constants;
/**
 * 
 * TrainingService that holds declaration for an abstract method.
 *
 */

public interface TrainingService 
{
	public Optional<Training> getTrainingById(int id);
	public List<Training> getTrainingByName(String name);
	public List<Training> getTrainingByRequester(String requesterName);
	public List<String> getRequesterList();
	default String getCompanyName()
	{
		return Constants.COMPANY_NAME;
	}

	static List<Training> initTrainings(List<Training> trainingList)
	{
		Training trng1=new Training(1,"Java","Java Comp","Java Traning on Web");
		Training trng2=new Training(2,"React","UI Comp","React Traning on UI");
		Training trng3=new Training(3,"Python","Python Comp","Python Traning on Web");
		Training trng4=new Training(4,"Java","Java Comp","Java Advanced training");
		trainingList.add(trng1);
		trainingList.add(trng2);
		trainingList.add(trng3);
		trainingList.add(trng4);
		return trainingList;
	}
 
	
}
