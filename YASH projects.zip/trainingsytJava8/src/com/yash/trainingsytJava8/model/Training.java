package com.yash.trainingsytJava8.model;

public class Training {
	private int id;
	private String trainingName;
	private String requesterName;
	private String description;
	 
	 
	public Training(int id, String trainingName, String requesterName, String description) {
		super();
		this.id = id;
		this.trainingName = trainingName;
		this.requesterName = requesterName;
		this.description = description;
	}
	 
	public int getId() {
		return id;
	}
	 
	public void setId(int id) {
		this.id = id;
	}
	 
	public String getTrainingName() {
		return trainingName;
	}
	 
	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}
	 
	public String getRequesterName() {
		return requesterName;
	}
	 
	public void setRequesterName(String requesterName) {
		this.requesterName = requesterName;
	}
	 
	public String getDescription() {
		return description;
	}
	 
	public void setDescription(String description) {
		this.description = description;
	}
	 
	@Override
	public String toString() {
		return "Training [id=" + id + ", trainingName=" + trainingName + ", requesterName=" + requesterName
				+ ", description=" + description + "]";
	}
	 
	 
	 
	 
	}
