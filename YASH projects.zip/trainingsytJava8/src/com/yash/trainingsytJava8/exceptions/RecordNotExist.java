package com.yash.trainingsytJava8.exceptions;

/**
 * 
 * Custom exception for showing no record found.
 *
 */
public class RecordNotExist extends RuntimeException {
	public RecordNotExist(String message) {
		super(message);
	}

}

