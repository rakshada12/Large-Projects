package com.yash.trainingsytJava8.test;

import java.util.ArrayList;

import com.yash.trainingsytJava8.model.Training;
import com.yash.trainingsytJava8.service.TrainingService;
import com.yash.trainingsytJava8.service.TrainingServiceImpl;

public class TrainingTest {
	public static void main(String[] args) {
		TrainingService service1 = new TrainingServiceImpl();
		TrainingServiceImpl.setTrngList(TrainingService.initTrainings(new ArrayList<Training>()));

		//System.out.println(training1.getId());
		System.out.println(service1.getTrainingByName("Python"));
		System.out.println(service1.getTrainingById(2));
		System.out.println(service1.getTrainingById(5));
		System.out.println(service1.getTrainingByRequester("java comp"));
		System.out.println(service1.getRequesterList());
		
	}

}
