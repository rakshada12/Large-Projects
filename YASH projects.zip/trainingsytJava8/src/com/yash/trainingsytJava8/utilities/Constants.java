package com.yash.trainingsytJava8.utilities;

/**
 * 
 * @author rakshada.pant
 *
 */

public class Constants {
	public static final String COMPANY_NAME="Yash Technologies";
	public static final int STR_EMPTY=0;
	public static final String STR_EMPTY2=" ";
	public static final int STR_1=1;
	public static final int STR_2=2;
	public static final int STR_3=3;
	public static final int STR_4=4;
	public static final int STR_EXIT=5;
	
 
}
