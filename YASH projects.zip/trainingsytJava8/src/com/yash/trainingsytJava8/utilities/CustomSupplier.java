package com.yash.trainingsytJava8.utilities;
import java.util.function.Supplier;

import com.yash.trainingsytJava8.model.Training;

public class CustomSupplier implements Supplier<Training> {

	@Override
	public Training get() {
		System.out.println("No result found.");
		return null;
	}
	

}
