package com.yash.trainingsytJava8.utilities;

import java.util.function.Predicate;

import com.yash.trainingsytJava8.model.Training;

public class TrainingPredicate {
	public static Predicate<Training> byId(int id){
		return t->t.getId() == id;
	}
	
	public static Predicate<Training> byName(String name){
		return t->t.getTrainingName().equalsIgnoreCase(name);
	}
	
	public static Predicate<Training> byRequesterName(String requesterName){
		return t->t.getRequesterName().equalsIgnoreCase(requesterName);
	}

}
