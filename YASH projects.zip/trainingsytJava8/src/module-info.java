module trainingsytJava8 {
}