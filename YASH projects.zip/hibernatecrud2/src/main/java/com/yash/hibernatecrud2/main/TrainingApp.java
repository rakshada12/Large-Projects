package com.yash.hibernatecrud2.main;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.yash.hibernatecrud2.config.HibernateConfig;
import com.yash.hibernatecrud2.config.TrainingAppConfig;

import com.yash.hibernatecrud2.model.Competency;
import com.yash.hibernatecrud2.model.Training;
import com.yash.hibernatecrud2.service.TrainingService;




/**
 * Hello world!
 */
public class TrainingApp {
    public static void main(String[] args) {
    	ApplicationContext ctx= new AnnotationConfigApplicationContext(HibernateConfig.class,TrainingAppConfig.class);  
        System.out.println("Database connected");
        TrainingService trainingService=ctx.getBean(TrainingService.class);
       Competency comp = new Competency("Java comp");
       
        Training training1 = new Training("Java", "Java Comp", "Java for freshers",new Date(), new Date(), new Date(), new Date(), comp);
        trainingService.addTrainings(training1);
        System.out.println("Training Record inserted successfully");
	
//        trainingService.deleteTraining(3L);
//        
//        for(Training t:trainingService.getAllTrainings()) {
//        	
//        	 
//        	System.out.println("The list of trainings is as follows : "+t.getId()+" "+t.getTrainingName()+" "+t.getRequestorName()+" "+t.getDescription());
//        }
        
 
        
      
    	
    	
//    	TrainingDaoImpl tdao = new TrainingDaoImpl();
//    	System.out.println("connected");
//    	Competency com=new Competency("test");
//    	Training training = new Training("XYZ", "XYZ", "XYZ for freshers",new Date(), new Date(), new Date(), new Date(), com);
//    	
//    	
//    	
//    	tdao.save(training);
//    	System.out.println("record inserted");
       
    }
}
