package com.yash.hibernatecrud2.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="training") 
public class Training {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String trainingName;
	private String requestorName;
	private String description;
	private Date startDate;
	private Date endDate;
	private Date createdAt;
	private Date updatedAt;
	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="compentency_id")
	private Competency comp;
	public Training(String trainingName, String requestorName, String description, Date startDate, Date endDate,
			Date createdAt, Date updatedAt, Competency comp) {
		super();
		this.trainingName = trainingName;
		this.requestorName = requestorName;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.comp = comp;
	}
	public Training() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Competency getComp() {
		return comp;
	}
	public void setComp(Competency comp) {
		this.comp = comp;
	}
	public String getTrainingName() {
		return trainingName;
	}
	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}
	public String getRequestorName() {
		return requestorName;
	}
	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Long getId() {
		// TODO Auto-generated method stub
		return id;
	}
	
	
	
	
	
 
}