package com.yash.hibernatecrud2.dao;

import java.util.List;

import com.yash.hibernatecrud2.model.Training;



public interface TrainingDao {
	
	
	public List<Training> list();

	public void save(Training training);
	
	public void updateTraining(Training training);
	public void deleteTraining(Long id);
	

}
