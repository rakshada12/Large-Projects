package com.yash.hibernatecrud2.daoImpl;

import java.util.List;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.yash.hibernatecrud2.dao.TrainingDao;
import com.yash.hibernatecrud2.model.Training;




@Repository
public class TrainingDaoImpl implements TrainingDao{
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Transactional
	public void save(Training training) {
		hibernateTemplate.saveOrUpdate(training);
 
	}
	@Transactional
	public List<Training> list() {
		return hibernateTemplate.loadAll(Training.class);
	}
	
	@Transactional
	@Override
	public void updateTraining(Training training) {
		// TODO Auto-generated method stub
		hibernateTemplate.update(training);
		
	}
	@Transactional
	@Override
	public void deleteTraining(Long id) {
		// TODO Auto-generated method stub
		Training training = hibernateTemplate.get(Training.class, id);
		if(training != null) {
			hibernateTemplate.delete(training);
		}
		
	}
	
	

}