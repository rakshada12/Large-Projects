package com.yash.hibernatecrud2.dao;

import com.yash.hibernatecrud2.model.Competency;

public interface CompetencyDao {
	public void save(Competency comp);

}
