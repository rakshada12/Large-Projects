package com.yash.hibernatecrud2.serviceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.hibernatecrud2.dao.TrainingDao;
import com.yash.hibernatecrud2.model.Training;
import com.yash.hibernatecrud2.service.TrainingService;




@Service
public class TrainingServiceImpl implements TrainingService {
	@Autowired
	private TrainingDao trainingDao;

	
	@Transactional
	public void addTrainings(Training training) {
		trainingDao.save(training);
		
	}

	@Transactional
	public List<Training> getAllTrainings() {
		// TODO Auto-generated method stub
		return trainingDao.list();
	}
	@Transactional
	@Override
	public void deleteTraining(Long id) {
		// TODO Auto-generated method stub
		trainingDao.deleteTraining(id);
	}
	@Transactional
	@Override
	public void updateTraining(Training training) {
		// TODO Auto-generated method stub
		trainingDao.updateTraining(training);
		
	}

}
