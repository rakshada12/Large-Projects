package com.yash.hibernatecrud2.service;

import java.util.List;

import com.yash.hibernatecrud2.model.Training;



public interface TrainingService {
	public void addTrainings(Training training);
	public List<Training> getAllTrainings();
	public void deleteTraining(Long id);
	public void updateTraining(Training training);

}
