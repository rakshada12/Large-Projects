package com.yash.hibernatecrud2.daoImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.yash.hibernatecrud2.dao.CompetencyDao;
import com.yash.hibernatecrud2.model.Competency;

@Repository
public class CompetencyDaoImpl implements CompetencyDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Transactional
	public void save(Competency comp) {
		// TODO Auto-generated method stub
		hibernateTemplate.save(comp);
		
	}

}
