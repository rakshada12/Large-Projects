package com.yash.hibernatecrud2.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name="competency") 
public class Competency {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	private String competencyName;

	public Competency(String competencyName) {
		super();
		this.competencyName = competencyName;
	}

	public String getCompetencyName() {
		return competencyName;
	}

	public void setCompetencyName(String competencyName) {
		this.competencyName = competencyName;
	}

	public Competency() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
