module TrainingSystem {
}