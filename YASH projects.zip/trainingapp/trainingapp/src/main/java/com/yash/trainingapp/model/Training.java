package com.yash.trainingapp.model;

import java.util.Date;
import java.util.Set;



import com.fasterxml.jackson.annotation.JsonFormat;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;




@Entity
@Table(name="training") 
public class Training {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@NotBlank(message="Name cannot be blank")
	private String trainingName;
	private String requestorName;
	private String description;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date startDate;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date endDate;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date createdAt;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date updatedAt;
	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="compentency_id")
	private Competency competency;
	
//	 // Many-to-One relationship with Competency
//    @ManyToOne(cascade= CascadeType.ALL)
//    @JoinColumn(name="compentency_id")
//    private Competency competency;
 
//    // Many-to-Many relationship with User
//    @ManyToMany(mappedBy = "trainings")
//    private Set<User> users;
	public Training(String trainingName, String requestorName, String description, Date startDate, Date endDate,
			Date createdAt, Date updatedAt) {
		super();
		this.trainingName = trainingName;
		this.requestorName = requestorName;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		
	}
	public Training() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Competency getCompetency() {
		return competency;
	}
	public void setCompetency(Competency competency) {
		this.competency = competency;
	}
	public String getTrainingName() {
		return trainingName;
	}
	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}
	public String getRequestorName() {
		return requestorName;
	}
	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Long getId() {
		// TODO Auto-generated method stub
		return id;
	}
	@Override
	public String toString() {
		return "Training [id=" + id + ", trainingName=" + trainingName + ", requestorName=" + requestorName
				+ ", description=" + description + ", startDate=" + startDate + ", endDate=" + endDate + ", createdAt="
				+ createdAt + ", updatedAt=" + updatedAt + "]";
	}
	
 
}