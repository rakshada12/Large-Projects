package com.yash.trainingapp.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.trainingapp.model.Training;

@Repository
public interface TrainingRepository extends JpaRepository<Training,Long> {

}
