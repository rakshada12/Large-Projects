package com.yash.trainingapp.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.yash.trainingapp.exceptions.TrainingNotFoundException;



@ControllerAdvice
public class MyController {
    
    @ExceptionHandler(TrainingNotFoundException.class)
    public ResponseEntity<?> handleTrainingNotFoundException(TrainingNotFoundException ex, WebRequest request) {
        Map<String, String> errorDetails = new HashMap<>();
        errorDetails.put("error", ex.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }
 
  
}
