package com.yash.trainingapp.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.trainingapp.model.Training;
import com.yash.trainingapp.repository.TrainingRepository;
import com.yash.trainingapp.service.TrainingService;

@Service
public class TrainingServiceImpl implements TrainingService {
	@Autowired
	private TrainingRepository trainingRepo;
	@Override
	public Training addTraining(Training training) {
		// TODO Auto-generated method stub
		return trainingRepo.save(training);
	}

	@Override
	public List<Training> listTrainings() {
		// TODO Auto-generated method stub
		return trainingRepo.findAll();
	}

	@Override
	public Training updateTraining(Training training) {
		// TODO Auto-generated method stub
		return trainingRepo.save(training);
	}

	@Override
	public void deleteTraining(Long id) {
		// TODO Auto-generated method stub
		trainingRepo.deleteById(id);
	}

	@Override
	public Training findById(Long id) {
		// TODO Auto-generated method stub
		return trainingRepo.findById(id).orElse(null);
	}

}
