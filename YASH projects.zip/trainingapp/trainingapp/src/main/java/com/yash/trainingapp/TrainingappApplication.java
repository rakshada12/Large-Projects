package com.yash.trainingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.yash.trainingapp.model.Training;

@SpringBootApplication
public class TrainingappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingappApplication.class, args);
		Training t=new Training();
		
	}

}
