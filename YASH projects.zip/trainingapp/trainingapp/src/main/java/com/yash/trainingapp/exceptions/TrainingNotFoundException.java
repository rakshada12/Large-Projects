package com.yash.trainingapp.exceptions;

public class TrainingNotFoundException extends RuntimeException {
	public TrainingNotFoundException(String message) {
		super("Account not found");
	}

}
