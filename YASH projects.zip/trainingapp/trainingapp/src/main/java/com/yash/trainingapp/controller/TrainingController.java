package com.yash.trainingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.trainingapp.exceptions.TrainingNotFoundException;
import com.yash.trainingapp.model.Training;
import com.yash.trainingapp.service.TrainingService;
import com.yash.trainingapp.serviceImpl.MapValidationErrorService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class TrainingController {
	@Autowired
	private TrainingService trainingService;
	@Autowired
	private MapValidationErrorService mapValidationErrorService;
	
	@PostMapping("/addTraining")
	 public ResponseEntity<?> createNewTraining(@Valid @RequestBody Training training, BindingResult result) {
        ResponseEntity<?> errorMap = mapValidationErrorService.mapValidationError(result);
        if (errorMap != null) return errorMap;
 
        Training savedTraining = trainingService.addTraining(training);
        return new ResponseEntity<>(savedTraining, HttpStatus.CREATED);
	}

//	@PostMapping("addTraining")
//	public Training addTraining(@RequestBody @Valid Training training) {
//		// TODO Auto-generated method stub
//		return trainingService.addTraining(training);
//	}
	
	@GetMapping("listTraining")
	public List<Training> listTrainings() {
		// TODO Auto-generated method stub
		return trainingService.listTrainings();
	}
	
	@PutMapping("/updateTraining/{id}")
	public ResponseEntity<?> updateTraining(@PathVariable Long id, @RequestBody Training training) {
	    Training existingTraining = trainingService.findById(id);
	    if (existingTraining == null) {
	        throw new TrainingNotFoundException("Training not found with ID: " + id);
	    }
	    existingTraining.setTrainingName(training.getTrainingName());
	    existingTraining.setRequestorName(training.getRequestorName());
	    existingTraining.setDescription(training.getDescription());
	    existingTraining.setStartDate(training.getStartDate());
	    existingTraining.setEndDate(training.getEndDate());
	    existingTraining.setUpdatedAt(training.getUpdatedAt());
	 
	    Training updatedTraining = trainingService.updateTraining(existingTraining);
	    return new ResponseEntity<>(updatedTraining, HttpStatus.OK);
	}

//	@PutMapping("/updateTraining")
//	public Training updateTraining(@RequestBody Training training) {
//		// TODO Auto-generated method stub
//		return trainingService.updateTraining(training);
//	}
        
        
    

//	@DeleteMapping("/deleteTraining/{id}")
//	public void deleteTraining(@PathVariable Long id) {
//		// TODO Auto-generated method stub
//		trainingService.deleteTraining(id);
//	}
        
        @DeleteMapping("/deleteTraining/{id}")
        public ResponseEntity<?> deleteTraining(@PathVariable Long id) {
            Training existingTraining = trainingService.findById(id);
            if (existingTraining == null) {
                throw new TrainingNotFoundException("Training not found with ID: " + id);
            }
         
            trainingService.deleteTraining(id);
            return new ResponseEntity<>("Training deleted successfully", HttpStatus.OK);
        }

}
