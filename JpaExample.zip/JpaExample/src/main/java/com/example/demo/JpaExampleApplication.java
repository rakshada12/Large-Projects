package com.example.demo;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.dao.Repo;
import com.example.entite.User;

@SpringBootApplication
public class JpaExampleApplication {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		Repo userrepo = context.getBean(Repo.class);
		
		
		List<User> user = userrepo.findByName("kushal");
		System.out.println(user);

	}

}
