import "./navbar.css"

const Navbar = () => {
  return (
    <div className="navbar">
      <div className="navContainer">
        <span className="logo">YASH Hotels</span>
        <div className="navItems">
          <button className="navButton"><a href="Register.html">Register as client</a></button>
          <button className="navButton">Register as user/costumer</button>
        </div>
      </div>
    </div>
  )
}

export default Navbar