import java.time.LocalDate;
public class PlusMinusDays {
	public static void main(String[] args) {    
	    LocalDate date = LocalDate.now();
	    LocalDate tomorrow = date.plusDays(1);
	    LocalDate yesterday = date.minusDays(1);  
	    System.out.println("Today date: "+date);    
	    System.out.println("Yesterday date: "+yesterday);    
	    System.out.println("Tomorrow date: "+tomorrow);
	    LocalDate lp = LocalDate.of(2000, 9 , 12);
	    System.out.println(lp.isLeapYear()); 
	    LocalDate lp1 = LocalDate.of(2016, 12 , 2);    
	    System.out.println(lp1.isLeapYear()); 
	  }    
	}    