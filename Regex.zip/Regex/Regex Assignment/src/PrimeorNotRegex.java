import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.ArrayList;

public class PrimeorNotRegex{
	public static void main(String[] args){
		// Brute force way
		ArrayList<Integer> primeNo = new ArrayList<>();
		String str = "12 323 34 5 656  676 454 13 7";
		Pattern p = Pattern.compile("\\d+(?=\\s|)");
		Matcher m = p.matcher(str);
		while(m.find()){
			int i = Integer.parseInt(m.group());
			if(prime(i)){
				primeNo.add(i);
			}
		}
		
		System.out.println(primeNo);
	}
	
	static Boolean prime(int n){
		for(int i = 2; i < n/2; i++){
			if(n % i == 0){
				return false;
			}
		}
		return true;
	}
}
