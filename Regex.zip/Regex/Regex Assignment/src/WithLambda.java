interface Run{  
    public void run();  
}  
public class WithLambda {  
    public static void main(String[] args) {  
        int field=10;  
   
        Run d=new Run(){  
            public void run(){System.out.println("Running "+field+"Kms.");}  
        };  
        d.run();  
        
        //Lambda expression
        Run r=()->{  
            System.out.println("Running fast "+field+"Kms.");  
        };  
        r.run();  
    }  
}  
