import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Arrays;
public class SplitNewline {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    System.out.println("Enter text: ");
	    String data = sc.nextLine();
	    String lines[] = data.split("\\r?\\n");//expression to match num in string
	    System.out.println(Arrays.toString(lines));
	      }
	   }
