import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class DateFormat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    System.out.println("Enter date: ");
	    String data = sc.nextLine();
	    String regex = "^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$";
	      Pattern pattern = Pattern.compile(regex);
	      //Matching the compiled pattern in the String
	      Matcher matcher = pattern.matcher(data);
	      boolean bool = matcher.matches();
	      if(bool) {
	         System.out.println("Date is valid");
	      } 
	      else {
	         System.out.println("Date is not valid");
	      }
	}
}
