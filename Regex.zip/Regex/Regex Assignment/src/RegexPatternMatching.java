import java.util.Scanner;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexPatternMatching {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    System.out.println("Enter text: ");
	    String data = sc.nextLine();
	    String regex = ("[0-9]{10}");
	    Pattern pattern = Pattern.compile(regex);
	    Matcher matcher = pattern.matcher(data);
	      System.out.println("Mobile No: ");
	      while(matcher.find()) {
	         System.out.print(matcher.group()+" ");
	      }
	    String email = ("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]");
	    Pattern pattern1 = Pattern.compile(email);
	    Matcher matcher1 = pattern1.matcher(data);
	    System.out.println("\n Email: ");
	      while(matcher1.find()) {
	         System.out.print(matcher1.group()+" ");
	      }
	    String url = "((https?|ftp|gopher|telnet|file):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
	    Pattern pattern2 = Pattern.compile(url);
	    Matcher matcher2 = pattern2.matcher(data);
	      System.out.println("Url: ");
	      while(matcher2.find()) {
	         System.out.print(matcher2.group()+" ");
	      }

	}
}
