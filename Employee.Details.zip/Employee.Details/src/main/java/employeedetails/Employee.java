package employeedetails;

public class Employee {

	private String empfirst;

private Student student;

	
	public Employee (String empfirst, Student student)
	{
	this.empfirst= empfirst;	
	this.student=student;  
	}




	public Student getStudent() {
		return student;
	}




	public void setStudent(Student student) {
		this.student = student;
	}




	@Override
	public String toString() {
		return "Employee [empfirst=" + empfirst + ", student=" + student + "]";
	}




	public String getEmpfirst() {
		return empfirst;
	}




	public void setEmpfirst(String empfirst) {
		this.empfirst = empfirst;
	}
	
}
