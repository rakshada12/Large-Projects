package com.yash.otbs;

public class Demo<T> {
	private Object[] array;
	private int size=0;
	private static final int DEFAULT = 10;
	
	public Demo(){
		array = new Object[DEFAULT];
	}
	
	public void add(T items) {
		if(size == array.length) {
			resize();
		}
		else {
			array[size++] = items;
		}
	}
	

	private void resize() {
		// TODO Auto-generated method stub
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo<String> string1 = new Demo<String>();
		string1.add("4");
		
		
		

	}

}
