package com.yash.otbs;

public class CourseController {

}
