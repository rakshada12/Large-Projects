import java.sql.*;  
class RemoteName{  
	public static void main(String args[]){ 
		CallableStatement cs = null;
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yash", "root", "root");  
			  
			PreparedStatement ps=con.prepareStatement("select * from employee");  
			ResultSet rs=ps.executeQuery();  
			ResultSetMetaData rsmd=rs.getMetaData();  
			
			ps = con.prepareStatement("INSERT into EMPLOYEE (empID, name) "
                    + "values (?, ?) ");
			ps.setInt(1, 7); //substitute first occurrence of ? with 7
            ps.setString(2, "ankit");
            
            cs = con.prepareCall("{call MYPROC_EMPLOYEE_INSERT_IN(?,?)}");
            cs.setInt(1, 11);
            cs.setString(2, "jatin");
            cs.executeUpdate();
            System.out.println("Stored procedure executed successfully, "
                    + "data has been inserted in Employee table");
			  
			System.out.println("Total columns: "+rsmd.getColumnCount());  
			System.out.println("Column Name of 1st column: "+rsmd.getColumnName(1));  
			System.out.println("Column Name of 1st column: "+rsmd.getColumnName(2));
			System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(1));  
			  
			con.close();  
			}catch(Exception e){ System.out.println(e);
		}  
	}  
}  
