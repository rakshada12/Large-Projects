package com.yash.controller;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
 
@Controller
public class AdditionController {
 
    @RequestMapping(value = "/addNumbers", method = RequestMethod.GET)
    public String showForm() {
        return "addNumbers"; // The name of the JSP view
    }
 
    @RequestMapping(value = "/addNumbers", method = RequestMethod.POST)
    public String addNumbers(@RequestParam("num1") int num1,
                             @RequestParam("num2") int num2, Model model) {
        int sum = num1 + num2;
        model.addAttribute("sum", sum);
        return "result"; // The result JSP view
    }
}