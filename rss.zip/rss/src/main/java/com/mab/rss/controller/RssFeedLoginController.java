package com.mab.rss.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class RssFeedLoginController {

	private static final Logger logger = LogManager.getLogger(RssFeedLoginController.class);

	@GetMapping(value = { "/home" })
	public String home() {
		return "home";
	}

	@RequestMapping(value = { "/", "/login", "/rss", "rss/login" }, method = { RequestMethod.GET, RequestMethod.POST })
	public void login(final HttpServletResponse response, final HttpServletRequest request)
			throws IOException, ServletException {
		logger.info("login");
		request.getRequestDispatcher("/viewAll").forward(request, response);
	}

	@RequestMapping(value = "/login1")
	public String log() {
		return "login";
	}

}
