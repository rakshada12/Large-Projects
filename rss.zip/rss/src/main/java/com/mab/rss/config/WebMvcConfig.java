package com.mab.rss.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.mab.rss.controller.RssFeedInterceptor;
import com.mab.rss.filter.RSSFilter;

@Configuration
public class WebMvcConfig extends WebMvcConfigurerAdapter {

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new RssFeedInterceptor());
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**").allowedMethods("GET", "POST");
	}
	@Bean
	public FilterRegistrationBean<RSSFilter> loggingFilter(){
	    FilterRegistrationBean<RSSFilter> registrationBean 
	      = new FilterRegistrationBean<>();
	        
	    registrationBean.setFilter(new RSSFilter());
	    registrationBean.addUrlPatterns("/*");
	    registrationBean.addUrlPatterns("/rss");
	    registrationBean.addUrlPatterns("/rss/*");
	        
	    return registrationBean;    
	}

	
}