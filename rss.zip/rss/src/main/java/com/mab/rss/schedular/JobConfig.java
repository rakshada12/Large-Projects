package com.mab.rss.schedular;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.springframework.stereotype.Component;
import org.springframework.util.FileSystemUtils;


@Component
public class JobConfig {
	private static final Logger logger = LogManager.getLogger(JobConfig.class);
//    @Scheduled(cron = "0 */30 * ? * *") //every 30 min
  @Scheduled(cron = "0 0 0 ? * FRI") //every friday at 00:00
    public void archiveXML() {
    	String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
//    	File source = new File("D:\\CR\\rssfeed_XML.XML");
//    	File dest = new File("D:\\CR\\RSS_Copy\\rssfeed_XML"+timeStamp+".XML");
    	File source = new File("/rsstomcat/rssfeed_XML.xml");
    	File dest = new File("/rss_archive/rssfeed_XML"+timeStamp+".xml");
    	logger.info("IN JOb Config at "+timeStamp);
    	try {
    		FileSystemUtils.copyRecursively(source, dest);
    	} catch (Exception e) {
    	    e.printStackTrace();
    	    logger.error(e);
    	}
    }
}