package com.mab.rss.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(1)
public class RSSFilter implements Filter {
	 private static final String HEADER_NAME = "Strict-Transport-Security";
 	 private static final String MAX_AGE_DIRECTIVE = "max-age=%s";
 	 private static final String INCLUDE_SUB_DOMAINS_DIRECTIVE = "includeSubDomains";
 	 //Content Security Policies
 	 public static final String POLICY = "frame-src 'self';frame-ancestors 'self';"
 	 		 +"img-src 'self';connect-src 'self'; media-src 'self';"
 	 		 +"object-src 'self'; manifest-src 'self'; worker-src 'self';form-action 'self'";

 	 private final String SESSION_PATH_ATTRIBUTE = ";Path=";
 	 private final String ROOT_CONTEXT = "/";
 	 private final String SAME_SITE_ATTRIBUTE_VALUES = ";HttpOnly;Secure;";
 	 
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
		System.out.println("in Filter");
	    HttpServletRequest req = (HttpServletRequest) servletRequest;
	    Cookie[] cookies = req.getCookies();
	    HttpServletResponse resp = (HttpServletResponse) servletResponse;
//		   resp.addHeader(HEADER_NAME, this.directives);
//		   
//		   //Adding all the CSP headers
		   resp.setHeader("Content-Security-Policy", POLICY);
//		   
//		   //Cacheable SSL Page Found Resolution Implementation
//		   resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
//		   resp.setHeader("Pragma", "no-cache"); // HTTP 1.0.
//		   resp.setHeader("Expires", "0"); // Proxies.
//	    if( cookies != null && cookies.length > 0) {
//	        for (int i = 0; i < cookies.length; i++) {
//	            cookies[i].setSecure(true);
//	            cookies[i].setHttpOnly(true);
//	            resp.addCookie(cookies[i]);
//	        }
//	    }
	       if (cookies != null && cookies.length > 0) {
	           List<Cookie> cookieList = Arrays.asList(cookies);
	           //Cookie sessionCookie = cookieList.stream().filter(cookie -> SESSION_COOKIE_NAME.equals(cookie.getName())).findFirst().orElse(null);
	           Cookie sessionCookie = null;
	           for(int i = 0; i<cookieList.size(); i++ ) {
	        	   sessionCookie = cookieList.get(i);
	               String contextPath = req.getServletContext() != null && StringUtils.isNotBlank(req.getServletContext().getContextPath()) ? req.getServletContext().getContextPath() : ROOT_CONTEXT;
	               resp.setHeader("Set-Cookie", sessionCookie.getName() + "=" + sessionCookie.getValue() + SESSION_PATH_ATTRIBUTE + contextPath + SAME_SITE_ATTRIBUTE_VALUES);
//	        	   if(cookieList.get(i).getName().equals(SESSION_COOKIE_NAME)) {
//	        		   sessionCookie = cookieList.get(i);
//	        		   break;
//	        	   }
	           }
//	           if (sessionCookie != null) {
//	               String contextPath = req.getServletContext() != null && StringUtils.isNotBlank(req.getServletContext().getContextPath()) ? req.getServletContext().getContextPath() : ROOT_CONTEXT;
//	               resp.setHeader("Set-Cookie", sessionCookie.getName() + "=" + sessionCookie.getValue() + SESSION_PATH_ATTRIBUTE + contextPath + SAME_SITE_ATTRIBUTE_VALUES);
//	           }
	       }
	    filterChain.doFilter(req,resp);
	}

	@Override
	public void destroy() {

	}

}
