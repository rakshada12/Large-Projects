package com.mab.rss.service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;

import com.mab.rss.domain.RssFeedForm;
import com.mab.rss.util.RssFeedXmlUtil;

@Service
public class RssFeedService {

	private static final Logger logger = LogManager.getLogger(RssFeedService.class);

//	private static String fileName = "D:\\DR\\rssfeed_XML.xml";
	private static String fileName = "/rsstomcat/rssfeed_XML.xml";
	@Autowired
	private RssFeedXmlUtil xmlUtil;
	

	public List<RssFeedForm> viewAll() {
		try {
			logger.info("viewAll- File Path "+ fileName);
			List<RssFeedForm> rssfeeds = xmlUtil.readXMLRoot(fileName);

			logger.info("viewAll =>" + rssfeeds);
			return rssfeeds;
		} catch (Exception e) {
			logger.error("viewAll Error " + e.getMessage());
			return new ArrayList<RssFeedForm>();
		}
	}

	public void addRssFeed(RssFeedForm rssFeedForm) {
		try {
			logger.info("add => " + rssFeedForm);

			boolean flag = false;
			List<Integer> ids = new ArrayList<>();
			for (RssFeedForm rssFeedForm2 : viewAll()) {
				ids.add(rssFeedForm2.getId());
			}
			Collections.sort(ids);
			int rssId;
			if(ids.size()==0)
				rssId=1;
			else
				rssId = ids.get(ids.size()-1)+1;
			rssFeedForm.setId(rssId);

			addCDATA(rssFeedForm);
			
			logger.info("addRssFeed- File Path "+ fileName);
			
			xmlUtil.writeToXMLRoot(fileName, flag, rssFeedForm);

		} catch (Exception e) {
			logger.error("addRssFeed Error " + e.getMessage());
		}
	}
	
	private void addCDATA(RssFeedForm rssFeedForm) {
		
		rssFeedForm.setDescription("&lt;![CDATA[" +rssFeedForm.getDescription()  + "]]&gt;");
		rssFeedForm.setTitle("&lt;![CDATA[" +rssFeedForm.getTitle()+ "]]&gt;");
		rssFeedForm.setLink("&lt;![CDATA[" +rssFeedForm.getLink()+ "]]&gt;");
	}

	public void updateRssFeed(RssFeedForm rssFeedForm) {

		try {
			logger.info("update => " + rssFeedForm);
			logger.info("updateRssFeed- File Path "+ fileName);
			boolean flag = true;

			xmlUtil.writeToXMLRoot(fileName, flag, rssFeedForm);

		} catch (Exception e) {
			logger.error("updateRssFeed Error " + e.getMessage());
		}
	}

	public String getRssfeedXml() {
		
		logger.info("getRssfeedXml- File Path  => " + fileName);

		return xmlUtil.getRssfeedXml(fileName);

	}

	public String getRssfeedArdwXml() {

		// return xmlUtil.getRssfeedXml(fileName);

		return tempNew();
	}

	private String tempNew() {
		return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n" + 
				"<rss version=\"2.0\" xmlns:atom=\"http://www.w3.org/2005/Atom\">\r\n" + 
				"  <channel>\r\n" + 
				"    <title>MH ARDW news</title>\r\n" + 
				"    <link>https://3rssfeed.malaysiaairlines.com</link>\r\n" + 
				"    <description>The latest updates from MH ARDW</description>\r\n" + 
				"    <ttl>60</ttl>\r\n" + 
				"        <lastBuildDate>01 Aug 2020 23:04:19 GMT</lastBuildDate>\r\n" + 
				"    <item>\r\n" + 
				"      <title>COVID-19 Change in Refund policy</title>\r\n" + 
				"      <description>Refund permitted free of charge if only original flight shown on the ticket is cancelled. Full refund can be made free of charge for travel dates between 01-MAR-2020 until 15-JUN-2020 by issuing a voucher of equal amount to be used within one year of issue. If voucher is required to be refunded, applicable rule at time of ticket purchase shall apply. No show fee will apply at all times except when flight is cancelled involuntarily by the airline. The policy is applicable for both refundable and</description>\r\n" + 
				"      <guid isPermaLink=\"false\">40f351b88bbd4e128153f85e2e91cbb6</guid>\r\n" + 
				"      <pubDate>01 Aug 2020 02:10:42 GMT</pubDate>\r\n" + 
				"    </item>\r\n" + 
				"    <item>\r\n" + 
				"      <title>COVID-19 Change in Rebooking policy</title>\r\n" + 
				"      <description>Change fees are not applicable to tickets issued anytime for travel from 01-MAR-2020 onwards until 15-JUNE-20. If there is a difference in the airfare or applicable taxes, due to the reissue/rerouting of the ticket, the additional amount will need to be collected. Customers can change their booking to travel on/or before December 31, 2020.</description>\r\n" + 
				"      <link>https://amadeus.com/en</link>\r\n" + 
				"      <guid isPermaLink=\"false\">23da969b786046ecb4f553373a138e25</guid>\r\n" + 
				"      <pubDate>01 Aug 2020 02:09:29 GMT</pubDate>\r\n" + 
				"    </item>\r\n" + 
				"  </channel>\r\n" + 
				"</rss>\r\n" + 
				"";

	}

	private String temp() {

		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + "<rss version=\"2.0\">\r\n" + "	<channel>\r\n"
				+ "		<title>Amadeus Six Airline Messages</title>\r\n"
				+ "		<link>https://amadeus.com/en</link>\r\n" + "		<description />\r\n"
				+ "		<language>en-us</language>\r\n"
				+ "		<lastBuildDate>Fri, 24 Mar 2020 16:01:59 GMT</lastBuildDate>\r\n" + "		\r\n"
				+ "		<item>\r\n" + "			<title>COVID-19 Change in Rebooking policy</title>\r\n"
				+ "			<link>https://amadeus.com/newinstructions</link>\r\n"
				+ "			<description>Change fees are not applicable to tickets issued anytime</description>\r\n"
				+ "		</item>\r\n" + "		<item>\r\n"
				+ "			<title>COVID-19 Change in Refund policy</title>\r\n"
				+ "			<description>Refund permitted free of charge if only original flight shown on the ticket.</description>\r\n"
				+ "		</item>\r\n" + "	</channel>\r\n" + "</rss>";
	}

	public RssFeedForm getRssfeedXml(int id) {
		List<RssFeedForm> rssFeeds = viewAll();
		RssFeedForm rssFeedForm = new RssFeedForm();
		for (RssFeedForm rssFeedForm1 : rssFeeds) {
			if (rssFeedForm1.getId() == id) {
				rssFeedForm.setId(rssFeedForm1.getId());
				rssFeedForm.setTitle(rssFeedForm1.getTitle());
				rssFeedForm.setDescription(rssFeedForm1.getDescription());
				rssFeedForm.setLink(rssFeedForm1.getLink());
				rssFeedForm.setPublishedDate(rssFeedForm1.getPublishedDate());
				rssFeedForm.setStartDate(rssFeedForm1.getStartDate());
				rssFeedForm.setEndDate(rssFeedForm1.getEndDate());
				break;
			}
		}
		return rssFeedForm;
	}


	public void deleteRssFeed(RssFeedForm rssFeedForm) {

		try {
			
			logger.info("deleteRssFeed => " + rssFeedForm);

			boolean flag = true;

			logger.info("deleteRssFeed- File Path  => " + fileName);
			xmlUtil.deleteFromXMLRoot(fileName, flag, rssFeedForm);

		} catch (Exception e) {
			logger.error("deleteRssFeed Error " + e.getMessage());
		}
	}
	
}
