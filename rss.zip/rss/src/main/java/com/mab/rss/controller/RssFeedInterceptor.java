package com.mab.rss.controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.sun.mail.smtp.SMTPMessage;

public class RssFeedInterceptor extends HandlerInterceptorAdapter {
//
//	private static final Logger logger = LogManager.getLogger(RssFeedInterceptor.class);
//
//	private static final String REST_USERNAME = "02616c5c-cc0d-4dc9-ab24-855e4379710f";
//	private static final String REST_API_KEY = "@p1P@ssword3";
//
//	static String saasid = "666beabd-ff26-4aac-aab5-d2d5016ae2d4";
//	static String userId = "staffid";
//	private int pre = 0;
//	private int post = 0;
//	private int after = 0;
//
//	@Override
//	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
//			throws Exception {
//
//		boolean flag = ssoConfig(request, response);
//
//		return flag;
//	}
//
//	@Override
//	public void postHandle(HttpServletRequest request, HttpServletResponse response, //
//			Object handler, ModelAndView modelAndView) throws Exception {
//	}
//
//	@Override
//	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, //
//			Object handler, Exception ex) throws Exception {
//	}
//
//	private boolean ssoConfig(HttpServletRequest request, HttpServletResponse response) {
//
//		HttpSession session = request.getSession();
//
//		try {
//			logger.error(" UserId before Calling SSO "+ session.getAttribute(userId));
//			if (session.getAttribute(userId) == null) {
//
//				String tokenid = request.getParameter("tokenid");
//				String agentid = request.getParameter("agentid");
//				logger.debug("\n tokenid = {} and agentid = {}", tokenid, agentid);
//
//				if (tokenid != null) {
//
//					URL url = new URL("https://sso.connect.pingidentity.com/sso/TXS/2.0/2/" + tokenid);
//					HttpURLConnection conn = null;
//					try {
//						conn = (HttpURLConnection) url.openConnection();
//					} catch (IOException e) {
//						mailSend("conn error: " + e.getLocalizedMessage(), "RssFeed Error Connection");
//						logger.error("Unable to connect to pingOne server for token exchange with  URL = " + url, e);
//						response.sendError(HttpServletResponse.SC_FORBIDDEN);
//					}
//
//					String authValue = REST_USERNAME + ":" + REST_API_KEY;
//
//					String basicAuthHeader = "Basic " + new String(Base64.encodeBase64(authValue.getBytes()));
//
//					logger.info("Basic auth header : " + basicAuthHeader);
//
//					conn.setRequestProperty("Authorization", basicAuthHeader);
//					String agentidCookie = "agentid=" + agentid;
//					conn.setRequestProperty("Cookie", agentidCookie);
//					conn.setReadTimeout(10000);
//					conn.setRequestMethod("GET");
//					InputStream is = conn.getInputStream();
//					Properties properties = new Properties();
//
//					properties.load(is);
//					logger.info("\n CONNECTION established for SSO ");
//
//					String resultString = properties.getProperty("pingone.subject");
//					String idpId = properties.getProperty("pingone.idp.id");
//
//					logger.info("\n resultString:" + resultString + "\n idpid" + idpId);
//
//					String[] resultStringsplit = resultString.split(",");
//					session.setAttribute("staffid", resultStringsplit[0]);
//					session.setAttribute("emailId", resultStringsplit[1]);
//					session.setAttribute("staffName", resultStringsplit[2]);
//
//					logger.info("\n Employee ID  = {}", resultStringsplit[0]);
//					session.setAttribute(userId, resultStringsplit[0]);
//
//					mailSend((String) session.getAttribute("userId"), "RssFeed Sucess");
//					return true;
//				}
//			}
//
//		} catch (IOException e) {
//			e.printStackTrace();
//
//			logger.error("Token ID used already/ IOException occured in Token Exchange", e);
//		} catch (Exception e) {
//			mailSend(e.getMessage(), "RssFeed Error");
//			logger.error("Exception in Token Exchange", e);
//		}
//		return true;
//
//	}
//
//	private void mailSend(String bodyMessage, String subject) {
//
//		try {
//			Properties props = new Properties();
//			props.setProperty("mail.smtp.host", "mhsmtp.malaysiaairlines.com");
//			props.put("mail.smtp.socketFactory.port", "25");
//			props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFkactory");
//			props.put("mail.smtp.auth", "false");
//			props.put("mail.smtp.port", "25");
//			Session session = Session.getDefaultInstance(props, new Authenticator() {
//				protected PasswordAuthentication getPasswordAuthentication() {
//					return new PasswordAuthentication("ext736673", "xxx");
//				}
//			});
//
//			SMTPMessage message = new SMTPMessage(session);
//			MimeMultipart content = new MimeMultipart("related");
//			MimeBodyPart messageBodyPart = new MimeBodyPart();
//
//			message.setFrom(new InternetAddress("ext_palash.pandit@malaysiaairlines.com"));
//
//			message.setRecipients(Message.RecipientType.TO,
//					(Address[]) InternetAddress.parse("ext_palash.pandit@malaysiaairlines.com"));
//
//			message.setRecipients(Message.RecipientType.CC,
//					(Address[]) InternetAddress.parse("ext_rajasekharreddy.kasireddy@malaysiaairlines.com"));
//
//			message.setSubject(subject);
//
//			MimeBodyPart textPart = new MimeBodyPart();
//			textPart.setText(bodyMessage, "US-ASCII", "html");
//			content.addBodyPart(textPart);
//			Multipart multipart = new MimeMultipart("mixed");
//
//			messageBodyPart.setContent(content);
//
//			multipart.addBodyPart(messageBodyPart);
//
//			message.setContent(multipart);
//			Transport.send(message);
//		} catch (Exception e) {
//
//		}
//
//	}
//
}