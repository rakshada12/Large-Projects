package com.mab.rss.util;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.mab.rss.domain.RssFeedDomain;
import com.mab.rss.domain.RssFeedForm;
import com.mab.rss.domain.RssFeedRootDomain;

@Component
public class RssFeedXmlUtil {

	private static final Logger logger = LogManager.getLogger(RssFeedXmlUtil.class);

	public static void main(String[] args) throws ParseException {

//		RssFeedXmlUtil xmlUtil = new RssFeedXmlUtil();
//
//		String fileName = "/tmp/rssfeed/test1.xml";
//		boolean flag = false;
//
//		RssFeedForm rssFeedForm = new RssFeedForm();
//		rssFeedForm.setTitle("test title8");
//		rssFeedForm.setLink("test link7");
//		rssFeedForm.setDescription("test desc7");
//		rssFeedForm.setStartDate("10-10-2020");
//		rssFeedForm.setEndDate("11-11-2020");
//
//		RssFeedDomain rssFeedDomain = xmlUtil.mapFormToDomain(rssFeedForm);
//		RssFeedRootDomain rssFeedRootDomain = xmlUtil.readXML(fileName);
//		xmlUtil.writeToXML(rssFeedDomain, rssFeedRootDomain, fileName, flag);

		// mapDomainToForm(rssFeedDomain);

		// compareDate("2020-09-10", "30-09-2020");
//		UUID uuid = UUID.randomUUID();
//		String randomUUIDString = uuid.toString();
//		System.out.println("Random UUID String = " + randomUUIDString);
//		System.out.println("UUID version       = " + uuid.version());
//		System.out.println("UUID variant       = " + uuid.variant());

		Date currentTime = new Date();
		SimpleDateFormat mSDF = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z");
		mSDF.setTimeZone(TimeZone.getTimeZone("GMT"));
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		String pubDate = mSDF.format(formatter.parse(formatter.format(currentTime)));

		System.out.println(pubDate);

//		final Date currentTime = new Date();
//
//		final SimpleDateFormat sdf =
//		        new SimpleDateFormat("EEE, MMM d, yyyy hh:mm:ss z");
//
//		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
//		System.out.println("GMT time: " + sdf.format(currentTime));
//		 
	}

	public void writeToXMLRoot(String fileName, boolean flag, RssFeedForm rssFeedForm) {
		RssFeedDomain rssFeedDomain = mapFormToDomain(rssFeedForm);
		RssFeedRootDomain rssFeedRootDomain = readXML(fileName);
		writeToXML(rssFeedDomain, rssFeedRootDomain, fileName, flag);
	}

	public void deleteFromXMLRoot(String fileName, boolean flag, RssFeedForm rssFeedForm) {
		RssFeedDomain rssFeedDomain = mapFormToDomain(rssFeedForm);
		RssFeedRootDomain rssFeedRootDomain = readXML(fileName);
		deleteXML(rssFeedDomain, rssFeedRootDomain, fileName, flag);
	}

	public RssFeedForm mapDomainToForm(RssFeedDomain rssFeedDomain) {

		RssFeedForm rssFeedForm = new RssFeedForm();
		rssFeedForm.setId(rssFeedDomain.getId());
		rssFeedForm.setTitle(replaceCdata(rssFeedDomain.getTitle()));
		rssFeedForm.setLink(replaceCdata(rssFeedDomain.getLink()));
		rssFeedForm.setDescription(replaceCdata(rssFeedDomain.getDescription()));
		rssFeedForm.setPublishedDate(rssFeedDomain.getPublishedDate());
		rssFeedForm.setStartDate(rssFeedDomain.getStartDate());
		rssFeedForm.setEndDate(rssFeedDomain.getEndDate());
		return rssFeedForm;
	}

	private String replaceCdata(String data) {

		return data.replace("&lt;![CDATA[", "").replace("]]&gt;", "");
	}

	public RssFeedDomain mapFormToDomain(RssFeedForm rssFeedForm) {

		RssFeedDomain RssFeedDomain = new RssFeedDomain();
		RssFeedDomain.setId(rssFeedForm.getId());
		RssFeedDomain.setTitle(rssFeedForm.getTitle());
		RssFeedDomain.setLink(rssFeedForm.getLink());
		RssFeedDomain.setDescription(rssFeedForm.getDescription());
		RssFeedDomain.setPublishedDate(rssFeedForm.getPublishedDate());
		RssFeedDomain.setStartDate(rssFeedForm.getStartDate());
		RssFeedDomain.setEndDate(rssFeedForm.getEndDate());
		return RssFeedDomain;
	}

	public void writeToXML(RssFeedDomain rssFeedDomain, RssFeedRootDomain rssFeedRootDomain, String fileName,
			boolean flag) {
		try {

			addRssFeed(rssFeedDomain, rssFeedRootDomain, flag);

			JAXBContext jaxbContext = JAXBContext.newInstance(RssFeedRootDomain.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); // To format XML

			File file = new File(fileName);
			jaxbMarshaller.marshal(rssFeedRootDomain, file);

		} catch (JAXBException e) {
			logger.error("Error writeToXML " + e);
		}
	}

	public void deleteXML(RssFeedDomain rssFeedDomain, RssFeedRootDomain rssFeedRootDomain, String fileName,
			boolean flag) {
		try {

			delete(rssFeedDomain, rssFeedRootDomain, flag);

			JAXBContext jaxbContext = JAXBContext.newInstance(RssFeedRootDomain.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); // To format XML

			File file = new File(fileName);
			jaxbMarshaller.marshal(rssFeedRootDomain, file);

		} catch (JAXBException e) {
			logger.error("Error deleteXML " + e);
		}
	}

	public void addRssFeed(RssFeedDomain rssFeedDomain, RssFeedRootDomain rssFeedRootDomain, boolean flag) {

		if (flag) {

			for (RssFeedDomain temp : rssFeedRootDomain.getRssFeeds()) {
				System.out.println(temp.getId() + "," + rssFeedDomain.getId());
				if (temp.getId() == rssFeedDomain.getId()) {
					temp.setId(rssFeedDomain.getId());
					temp.setDescription(rssFeedDomain.getDescription());
					temp.setTitle(rssFeedDomain.getTitle());
					temp.setLink(rssFeedDomain.getLink());
					temp.setPublishedDate(rssFeedDomain.getPublishedDate());
					temp.setStartDate(rssFeedDomain.getStartDate());
					temp.setEndDate(rssFeedDomain.getEndDate());
				}
			}
		} else {
			rssFeedRootDomain.getRssFeeds().add(rssFeedDomain);
		}
	}

	public void delete(RssFeedDomain rssFeedDomain, RssFeedRootDomain rssFeedRootDomain, boolean flag) {

		List<RssFeedDomain> list = new ArrayList<>();

		for (RssFeedDomain temp : rssFeedRootDomain.getRssFeeds()) {

			if (temp.getId() != rssFeedDomain.getId()) {
				list.add(temp);
			}
		}
		rssFeedRootDomain.setRssFeeds(list);
	}

	public List<RssFeedForm> readXMLRoot(String fileName) {
		RssFeedRootDomain rssFeedRootDomain = readXML(fileName);
		List<RssFeedForm> rssfeeds = mapDomainToForm(rssFeedRootDomain);
		return rssfeeds;
	}

	public RssFeedRootDomain readXML(String fileName) {

		File xmlFile = new File(fileName);

		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(RssFeedRootDomain.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			RssFeedRootDomain rssFeedRootDomain = (RssFeedRootDomain) jaxbUnmarshaller.unmarshal(xmlFile);
			return rssFeedRootDomain;
		} catch (JAXBException e) {
			logger.error("Error readXML " + e);
			return new RssFeedRootDomain();
		}
	}

	public List<RssFeedForm> mapDomainToForm(RssFeedRootDomain rssFeedRootDomain) {

		List<RssFeedForm> rssfeeds = new ArrayList<>();

		for (RssFeedDomain domain : rssFeedRootDomain.getRssFeeds()) {
			RssFeedForm form = mapDomainToForm(domain);
			rssfeeds.add(form);
		}
		return rssfeeds;
	}

	public String getRssfeedXml(String fileName) {

		String header = headerMessage();
		String footer = footerMessage();
		String body = bodyMessage(fileName);

		return header.concat(body).concat(footer);
	}

	private String bodyMessage(String fileName) {
		StringBuffer body = new StringBuffer();

		RssFeedRootDomain rssFeedRootDomain = readXML(fileName);

		List<RssFeedDomain> list = activeInfo(rssFeedRootDomain);

		for (RssFeedDomain domain : list) {

			body.append("<item>");

			if (!StringUtils.isEmpty(domain.getTitle())) {

				body.append("<title>").append(filterData(domain.getTitle())).append("</title>");
			}
			if (!StringUtils.isEmpty(domain.getLink())) {

				body.append("<link>").append(filterData(domain.getLink())).append("</link>");
			}

			if (!StringUtils.isEmpty(domain.getDescription())) {
				body.append("<description>").append(filterData(domain.getDescription())).append("</description>");
			}

			body.append("<guid isPermaLink=\"false\">").append(guid()).append("</guid>");

			body.append("<pubDate>").append(pubDate(domain.getPublishedDate())).append("</pubDate>");

			body.append("</item>");
		}

		return body.toString();
	}

	private String filterData(String data) {
		// return data.replace("&", "");
		return data.replace("&lt;![CDATA[", "").replace("]]&gt;", "").replace("&", "&amp;");
		// return data.replace("&", "&amp;");
	}

	private List<RssFeedDomain> activeInfo(RssFeedRootDomain rssFeedRootDomain) {

		List<RssFeedDomain> list = new ArrayList<>();

		for (RssFeedDomain domain : rssFeedRootDomain.getRssFeeds()) {
			if (compareDate(domain.getStartDate(), domain.getEndDate())) {
				list.add(domain);
			}
		}

		Comparator<RssFeedDomain> compareByDate = new Comparator<RssFeedDomain>() {
			@Override
			public int compare(RssFeedDomain o1, RssFeedDomain o2) {
				return o1.getStartDate().compareTo(o2.getStartDate());
			}
		};

		Collections.sort(list, compareByDate);

		if (!CollectionUtils.isEmpty(list) && list.size() > 10) {
			List<RssFeedDomain> splitList = list.subList(0, 10);
			return splitList;
		} else {
			return list;
		}

	}

	private String headerMessage() {

		StringBuffer headerSb = new StringBuffer();
		headerSb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		headerSb.append("<rss version=\"2.0\" xmlns:atom=\"http://www.w3.org/2005/Atom\">");
		headerSb.append("<channel>");
		headerSb.append("<title>MH ARDW news</title>");
		headerSb.append("<link>https://3rssfeed.malaysiaairlines.com</link>");
		headerSb.append("<description>The latest updates from MH ARDW</description>");
		headerSb.append(" <ttl>60</ttl>");
		headerSb.append("<lastBuildDate>Wed, 01 Jul 2020 23:04:19 GMT</lastBuildDate>");

		return headerSb.toString();
	}

	private String footerMessage() {

		StringBuffer footer = new StringBuffer();
		footer.append("</channel>");
		footer.append("</rss>");
		return footer.toString();
	}

	private static boolean compareDate(String startDate, String endDate) {

		String format = "yyyy-MM-dd";
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		Calendar cal = Calendar.getInstance();
		String todaydateBefore = formatter.format(cal.getTime());

		try {
			Date todayDate = formatter.parse(todaydateBefore);
			Date startDateNew = formatter.parse(startDate);
			Date endDateNew = formatter.parse(endDate);

			logger.info("TodayDate " + todayDate + " startDate " + startDate + " endDate " + endDate);

			if ((startDateNew.equals(todayDate) || startDateNew.before(todayDate)) && endDateNew.after(todayDate)) {
				// logger.info("if block, TodayDate " + todayDate + " startDate " + startDate +
				// " endDate " + endDate);
				return true;
			} else {
				// logger.info("else block, TodayDate " + todayDate + " startDate " + startDate
				// + " endDate " + endDate);
			}

		} catch (Exception e) {
		}
		return false;
	}

	private String pubDate(String publisheddate) {

		try {
			SimpleDateFormat mSDF = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z");
			mSDF.setTimeZone(TimeZone.getTimeZone("GMT"));
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
			String pubDate = mSDF.format(formatter.parse(publisheddate));
			return pubDate;
		} catch (Exception e) {
			return "";
		}
	}

	private String guid() {
		UUID uuid = UUID.randomUUID();
		String randomUUIDString = uuid.toString();
		return randomUUIDString;
	}
}
