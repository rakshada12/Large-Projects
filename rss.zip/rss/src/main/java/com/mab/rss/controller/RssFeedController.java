package com.mab.rss.controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.mab.rss.domain.RssFeedForm;
import com.mab.rss.service.RssFeedService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class RssFeedController {

	private static final Logger logger = LogManager.getLogger(RssFeedController.class);

	@Autowired
	private RssFeedService rssFeedService;

	@RequestMapping(value = { "/viewAll", "rss/viewAll" }, method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView viewAll(final HttpServletRequest request) {
		List<RssFeedForm> rssfeeds = rssFeedService.viewAll();
		ModelAndView modelAndView = new ModelAndView("list");
		modelAndView.addObject("rssfeeds", (Object) rssfeeds);
		request.setAttribute("rssfeeds", rssfeeds);
		
		logger.info("viewAll "+ rssfeeds);
		return modelAndView;

	}

	@RequestMapping(value = "/add", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView add(final HttpServletRequest request) {
		return new ModelAndView("addRssFeed");
	}
	
	@RequestMapping(value = "/copyXML", method = { RequestMethod.GET, RequestMethod.POST })
	public String copyXML() {
    	String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
//    	File source = new File("D:\\DR\\rssfeed_XML.xml");
//    	File dest = new File("D:\\CR\\RSS_Copy\\rssfeed_XML"+timeStamp+".xml");
    	File source = new File("/rsstomcat/rssfeed_XML.xml");
    	File dest = new File("/rss_archive/rssfeed_XML"+timeStamp+".XML");
    	logger.info("IN copyXML Config at "+timeStamp);
    	try {
    		FileSystemUtils.copyRecursively(source, dest);
    		return "File Copied Sucessfully";
    	} catch (Exception e) {
    	    e.printStackTrace();
    	    logger.error(e);
    	}
    	return "home";
	}

	@RequestMapping(value = "/addRssFeed", method = { RequestMethod.GET, RequestMethod.POST })
	public void addRssFeed(@ModelAttribute final RssFeedForm rssFeedForm, final HttpServletResponse response,
			final HttpServletRequest request) throws IOException, ServletException {
		rssFeedService.addRssFeed(rssFeedForm);
		request.getRequestDispatcher("/viewAll").forward(request, response);
	}

	@RequestMapping(value = "/update", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView updateRssFeed(final HttpServletRequest request) {
		RssFeedForm rssfeed = rssFeedService.getRssfeedXml(Integer.parseInt(request.getParameter("id")));
		ModelAndView modelAndView = new ModelAndView("updateRssFeed");
		modelAndView.addObject("rssfeed", (Object) rssfeed);
		return modelAndView;
	}

	@RequestMapping(value = "/updateRssFeed", method = { RequestMethod.GET, RequestMethod.POST })
	public void updateCSV(@ModelAttribute final RssFeedForm rssFeedForm, final HttpServletResponse response,
			final HttpServletRequest request) throws IOException, ServletException {

		rssFeedService.updateRssFeed(rssFeedForm);
		request.getRequestDispatcher("/viewAll").forward(request, response);
	}

	@RequestMapping(value = "/deleteRssFeed", method = { RequestMethod.GET, RequestMethod.POST })
	public void deleteRssFeed(@ModelAttribute final RssFeedForm rssFeedForm, final HttpServletResponse response,
			final HttpServletRequest request) throws IOException, ServletException {
		rssFeedService.deleteRssFeed(rssFeedForm);
		request.getRequestDispatcher("/viewAll").forward(request, response);
	}

	@RequestMapping(value = "/logout", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView logout(final HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		return new ModelAndView("logout");
	}

	@RequestMapping(value = "/rssfeedXml", produces = MediaType.APPLICATION_XML_VALUE, method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody String getRssfeedXml() {

		String xmlRes = rssFeedService.getRssfeedXml();
		logger.info("rssfeedXml "+xmlRes);
		return xmlRes;
	}

	@RequestMapping(value = "/ardw.xml", produces = MediaType.APPLICATION_XML_VALUE, method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody String ardw() {

		String xmlRes = rssFeedService.getRssfeedXml();
		logger.info("ARDW XML " +xmlRes);
		return xmlRes;
	}

}
