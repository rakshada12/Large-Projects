package com.mab.rss.domain;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "RssFeedRoot")
@XmlAccessorType(XmlAccessType.FIELD)
public class RssFeedRootDomain {
	
	private List<RssFeedDomain> rssFeeds = new ArrayList<RssFeedDomain>();

	public List<RssFeedDomain> getRssFeeds() {
		return rssFeeds;
	}

	public void setRssFeeds(List<RssFeedDomain> rssFeeds) {
		this.rssFeeds = rssFeeds;
	}

	@Override
	public String toString() {
		return "RssFeedRootDomain [rssFeeds=" + rssFeeds + "]";
	}
	
}
