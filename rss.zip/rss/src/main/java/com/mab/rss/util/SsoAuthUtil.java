package com.mab.rss.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

import com.sun.mail.smtp.SMTPMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Component
public class SsoAuthUtil {

	private static final Logger logger = LogManager.getLogger(SsoAuthUtil.class);
	private static final String REST_USERNAME = "02616c5c-cc0d-4dc9-ab24-855e4379710f";
	private static final String REST_API_KEY = "@p1P@ssword3";
	static String userId = "userId";
	
	public boolean validateSSO(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		logger.info("ssoConfig****");
		HttpSession session = request.getSession();

		try {
			if (session.getAttribute("userId") == null) {

				String tokenid = request.getParameter("tokenid");
//				String tokenid = "I0e-bp7Z2kVqYfHlSWYrl31_yBMD8jI1lDZ7ogB7A93Mi2xmvHOXR02Ud2wDMd";
//				String agentid = "433bd678";
				String agentid = request.getParameter("agentid");
				logger.debug("\n tokenid = {} and agentid = {}", tokenid, agentid);
//				String[] requestPathArray = request.getRequestURL().toString().split("api");
//				String requestPath = (requestPathArray != null && requestPathArray.length > 1) ? requestPathArray[1]
//						: null;

				if (tokenid != null) {

					URL url = new URL("https://sso.connect.pingidentity.com/sso/TXS/2.0/2/" + tokenid);
					HttpURLConnection conn = null;
					try {
						conn = (HttpURLConnection) url.openConnection();
					} catch (IOException e) {
//						mailSend("conn error: " + e.getLocalizedMessage());
						logger.error("Unable to connect to pingOne server for token exchange with  URL = " + url, e);
						response.sendError(HttpServletResponse.SC_FORBIDDEN);
					}

					String authValue = REST_USERNAME + ":" + REST_API_KEY;

					String basicAuthHeader = "Basic " + new String(Base64.encodeBase64(authValue.getBytes()));

					logger.info("Basic auth header : " + basicAuthHeader);

					conn.setRequestProperty("Authorization", basicAuthHeader);
					String agentidCookie = "agentid=" + agentid;
					conn.setRequestProperty("Cookie", agentidCookie);
					conn.setReadTimeout(10000);
					conn.setRequestMethod("GET");
					InputStream is = conn.getInputStream();
					Properties properties = new Properties();

//					mailSend("Before Mail send");

					properties.load(is);
					logger.info("\n CONNECTION established for SSO ");

					String resultString = properties.getProperty("pingone.subject");
					String idpId = properties.getProperty("pingone.idp.id");

					logger.info("\n resultString:" + resultString + "\n idpid" + idpId);
					
					String[] resultStringsplit = resultString.split(",");		
					session.setAttribute("staffid", resultStringsplit[0]);
					session.setAttribute("emailId", resultStringsplit[1]);
					session.setAttribute("staffName", resultStringsplit[2]);
					mailSend(resultStringsplit[0]);
					
					logger.info("\n Employee ID  = {}", resultStringsplit[0]);
					session.setAttribute(userId, resultStringsplit[0]);

					mailSend("SSO: "+(String)session.getAttribute("userId"));
					return true;
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			mailSend(ex.getLocalizedMessage());
			return false;
		}
		return true;

	}
	
	public void mailSend(String bodyMessage) {

		try {
			Properties props = new Properties();
			props.setProperty("mail.smtp.host", "mhsmtp.malaysiaairlines.com");
			props.put("mail.smtp.socketFactory.port", "25");
			props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFkactory");
			props.put("mail.smtp.auth", "false");
			props.put("mail.smtp.port", "25");
			Session session = Session.getDefaultInstance(props, new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("ext736673", "xxx");
				}
			});

			SMTPMessage message = new SMTPMessage(session);
			MimeMultipart content = new MimeMultipart("related");
			MimeBodyPart messageBodyPart = new MimeBodyPart();

			message.setFrom(new InternetAddress("ext_palash.pandit@malaysiaairlines.com"));

			message.setRecipients(Message.RecipientType.TO,
					(Address[]) InternetAddress.parse("ext_palash.pandit@malaysiaairlines.com"));

			message.setRecipients(Message.RecipientType.CC,
					(Address[]) InternetAddress.parse("ext_palash.pandit@malaysiaairlines.com"));			
			
			String subject = "Rss Feed";
			message.setSubject(subject);

			MimeBodyPart textPart = new MimeBodyPart();
			textPart.setText(bodyMessage, "US-ASCII", "html");
			content.addBodyPart(textPart);
			Multipart multipart = new MimeMultipart("mixed");

			messageBodyPart.setContent(content);

			multipart.addBodyPart(messageBodyPart);

			message.setContent(multipart);
			Transport.send(message);
		} catch (Exception e) {

		}

	}
}