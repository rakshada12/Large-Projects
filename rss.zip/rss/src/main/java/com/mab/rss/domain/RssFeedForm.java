package com.mab.rss.domain;

public class RssFeedForm {
	
	private int id;
	private String title;
	private String link;
	private String description;
	private String publishedDate="";
	private String startDate;
	private String endDate;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(String publisheDate) {
		this.publishedDate = publisheDate;
	}
	@Override
	public String toString() {
		return "RssFeedForm [id=" + id + ", title=" + title + ", link=" + link + ", description=" + description
				+ ", publishedDate=" + publishedDate + ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
	
	
	
	
}
