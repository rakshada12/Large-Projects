package com.springcore.lifecycle;

public class Xml {

	private double price;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		System.out.println("setting price");
		this.price = price;
	}

	public Xml() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Wadapav [price=" + price + "]";
	}

	public void init() {
		System.out.println("inside init method");

	}

	public void destory() {
		System.out.println("inside destory method");
	}

}
