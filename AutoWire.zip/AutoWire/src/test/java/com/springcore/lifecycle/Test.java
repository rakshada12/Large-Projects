package com.springcore.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.auto.wire.annotation.Student;

public class Test {
	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("com/springcore/lifecycle/applicationcontext.xml");
		Xml c = context.getBean("s1", Xml.class);
	System.out.println(c);
	context.registerShutdownHook();
		
		
		System.out.println("---------------Interface----------------------");
		Interface p = context.getBean("p1", Interface.class);
		System.out.println(p);


		
	    System.out.println("---------------Annotataion----------------------");
		Annotation s = context.getBean("annotation", Annotation.class);
		System.out.println(s);

	}
}
