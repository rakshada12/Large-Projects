package com.auto.wire.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.auto.wire.Emp;

public class App {
	public static void main(String[] args) {
		System.out.println("AutoWire with annotation");

		ApplicationContext context = new  ClassPathXmlApplicationContext("com/auto/wire/annotation/applicationcontext.xml");
		Student c= context.getBean("student2", Student.class);
		System.out.println(c);
}
}

