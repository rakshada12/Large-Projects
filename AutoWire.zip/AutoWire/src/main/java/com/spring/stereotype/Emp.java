package com.spring.stereotype;


public class Emp {

		
}
