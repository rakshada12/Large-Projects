package com.spring.stereotype.annotation;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component()
public class Address
{
	@Value("kushal")
	private String empName;
	@Value("solapur")

	private String location;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "Address [empName=" + empName + ", location=" + location + "]";
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}


	
}
